/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <sound/sound.h>
#include <sound/music.h>

int Sound::globalvolume = 0;

void Sound::SetVolume(int volume)
{
  globalvolume = (int) (255.0 * (float) volume / 100.0);
}

char *sound_name[] = {"sound\\effects\\block.wav",
			 "sound\\effects\\duck_hit.wav",
       		 "sound\\effects\\elbow.wav",
             		 "sound\\effects\\hit.wav",
             		 "sound\\effects\\jump.wav",
                 	 "sound\\effects\\jump_land.wav",
                      "sound\\effects\\kick.wav",
                      "sound\\effects\\knee.wav",
                      "sound\\effects\\hit_air.wav",
			 "sound\\effects\\hit_ground.wav"};	
 
  
void Sound::init(bool _active)
{
  active = _active;   
  
  if (active == false) return;
    /////////////////////////////////////////////////////////////
  /* to achieve the max possible volume */
  set_volume_per_voice(0);

  if (install_sound(DIGI_AUTODETECT, MIDI_NONE, 0) < 0) {
    con->printf("Error installing sound.\n");
  }
  
  vol = 255;
  pan = 127;
  freq = 1000;
  loop = 0;
  
  for (int i = 0; i < NR_SOUNDS; i++) {
  	// detta betyder att sampeln inte spelas upp	
    voice[i] = -1;
   }    
}    
  

void Sound::load_samples()
{
    if (active == false) return;

    con->printf("loading samples");
    for (int i = 0; i < NR_SOUNDS; i++) {
        sample[i].load(sound_name[i]);
    }   	
         
}    



void Sound::play(Sound_type snd)
{
    if (active == false) return;
    
    // kolla s� att samma sample inte h�ller p� att spelas upp
    if (voice_get_position(voice[snd]) != -1) {
        sample[snd].stop();

    }    
    // spara voice-nr s� vi kan se om samplen redan spelar
    voice[snd] = sample[snd].play(freq, vol, pan);

}    

void Sample::load(char *filename)
{
     sample = load_sample(filename);
     if (!sample) 
      	con->printf("couldnt load sound nr %s\n", filename);
}



void Sample::play(char *filename, int soundfreq, int vol, int pan)
{
 	 load(filename);
	 play(soundfreq, vol, pan);	 
}
int Sample::play(int soundfreq, int vol, int pan)
{
     int freq = 1000;
     if (sample)
        voice = play_sample(sample, Sound::globalvolume, pan, freq, false);
     return voice;
}

void Sample::play()
{
 	 int freq = 1000;
 	 
     int vol = 255;
     int pan = 127;
     int loop = 0;	
     if (sample)	 	
       voice = play_sample(sample, Sound::globalvolume, pan, freq, false);
	 	
}
void Sample::stop()
{  
   if (sample)
     stop_sample(sample);
}
bool Sample::finnished()
{
 	 if (voice_get_position(voice) == -1)
 	 	return true;
     else return false;
}
/////////////////////////////////////////////////////////////////////
/// <pre>
/// for samples being played and loaded in a loop
/// and then destroyed (when game-speed is not concerned)
/// for talking ex.. 
/// returns true when finnished
/// </pre>
/////////////////////////////////////////////////////////////////////
bool Sample::play_loop_once(char *filename, int soundfreq, int vol, int pan)
{
 	 if (state == 0) {
     	play(filename, soundfreq, vol, pan);
     	state = 1;
     	//music.setvolume(100);
      }
      if (state == 1) {
 		//adjust_sample(sample, sound.vol, sound.pan, sound.freq, false);
	  	if ( finnished_destroy()) {
		  state = 0;	
		  //music.setvolume(255);
		  return true;
	    }
      }	
   return false;
}

bool Sample::finnished_destroy()
{
 	if (finnished()) {
	 destroy_sample(sample);
	 return true;
	 }
	 else return false;
 	   
}



