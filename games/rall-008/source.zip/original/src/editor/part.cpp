/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <editor/part.h>

// these colors are used for white and black dots
// == because white and black was no good, they were used to often in bitmaps
//int white, black;
   


/////////////////////////////////////////////////////////////////////
/// Creates a part and sets all variables to default
/////////////////////////////////////////////////////////////////////
Part::Part() {
  global = 1;
  free = false;
  bmp = 0;
  rot_point.x =  rot_point.y = rotation = 0;
  rotation_added = 0;
  min = max = 255;
  min = 255;
  max = 255;
  
  flip = false;
     
  z_index = 0;
  
  debug = false;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// Find the rotation point and all connection point and add information
/// about theese, if show_points is false, then the rotation point and
/// all connection points will be invincible
///  
/// 1. find the rotation point
/// 2. find every connection point
/// 3. for every connection point calculate the grade to the rotation point
///    and there are 4 special cases dependning on where in tho four rooms
///    the connecting point is, if the rotation point is in the middle axis
///    x and y values in the connection points are relative to the bitmap
///    ie upper left corner (and not relative to the rotation point)
/// </pre>
/////////////////////////////////////////////////////////////////////
void Part::init_points(bool show_points)
{
  // hitta rotatation vit point f�rst.. m�ste finnas d�r s� vi kan r�kna
  // ut vinkel till de svarta
  int white = PART_WHITE;
  int black = PART_BLACK;
  
  for (int i = 0; i < bmp->w; i++) {
    for (int j = 0; j < bmp->h;j++) {
      if ( getpixel(bmp, i, j) == white) {
	rot_point.x = i;
	rot_point.y = j;
	
	
	//con->printf("\nrot point is %d %d\n", i, j);
	
	// overwrite that ugly point with the left one
	if (!show_points) putpixel(bmp, i, j, getpixel(bmp, i-1, j));
	//break;
      }   
      // debug shit filling the bitmap with white
      
      //if ( getpixel(bmp, i, j) == makecol(255, 0, 255)) {
      //	  putpixel(bmp, i, j, makecol(255, 255, 255)); 
      //	  }	  
    }
  }
  ////////////////////////////////////////////////
  // hitta alla svarta punkterna 
  for (int i = 0; i < bmp->w; i++) {
    for (int j = 0; j < bmp->h;j++) {
      if ( getpixel(bmp, i, j) == black) {
      	// overwrite that ugly point with the left one
	if (!show_points) putpixel(bmp, i, j, getpixel(bmp, i-1, j));   		 
      	   		 
	Adds adds;
	//add.point &p = *newpoint;
	adds.point.x = i;
	adds.point.y = j;
                
                
	/////////////////////////////////////////////////
	// hitta vinkeln fr�n b�rjan mellan vit o svart prick
	//add.grade = fixatan();
	fixed dist = fixdiv(itofix(abs(rot_point.x - i)), itofix(abs(rot_point.y - j)));
	//con->printf("dist is  %d \n", fixtoi(dist));
	adds.grade = fixtoi(fixatan(dist));  
	
	
	int x_dist = adds.point.x - rot_point.x;
   	int y_dist = adds.point.y - rot_point.y;
 	adds.hyp = fixhypot(itofix(x_dist), itofix(y_dist));
	
	// h�r �r specialfall f�r de olika 4 rummen
	// om vit �r under svart
	
	// room 1
	if (rot_point.y > j && rot_point.x > i) {
	  adds.room = 1;
	}
	// room 2
	else if (rot_point.y > j && rot_point.x < i) {
	  adds.room = 2;
                   
	}
	// room 3
	else if (rot_point.y < j && rot_point.x > i) {
	  adds.room = 3;
	}
	// room 4
	else if (rot_point.y < j && rot_point.x < i) {
	  adds.room = 4;    
	} 
                
	/////////////////////////////////////////////////
	add.push_back(adds);
	// skapa �ven en tom part som vi sedan kan fylla med n�t
	Part p;
	parts.push_back(p);
	//con->printf("angle is  %d \n", adds.grade);
	//con->printf("add point is %d %d\n", i, j);
	//con->printf("---------------------------------\n", i, j);
                
      }   
              
    }
  } 
     
}


//////////////////////////////////////////////////////////////////////
/// gets an rotation and returns it in the intervall 0 - 256
//////////////////////////////////////////////////////////////////////
int norm_rotation(int rotation)
{
  if (rotation < 0) 
    return 255 + rotation;
  else if (rotation > 255) 
    return rotation - 255;
  else 
    return rotation;
}

//////////////////////////////////////////////////////////////////////
/// finds if distance of test is closer to min or max and returns the value
/// it was closest to
//////////////////////////////////////////////////////////////////////
int closest(int test, int min, int max)
{
  if (abs(test-min) < abs(test-max))
    return min;
  else return max;   
}
//////////////////////////////////////////////////////////////////////
/// <pre>
/// Adds rotation on all parts in a part-tree.. all parts in subtrees
/// will also be rotatated. This is done by calculating new positions for all
/// points in the parts. Also checks that rotation is between min - max
/// section of part.
/// 1. if this part is not free, then we set its position to the value
///    of its fathers connecting point
/// 2. make sure the rotation and added rotation is between 0-255 (like degrees)
/// 3. pick out one connecting point in the list and pick out the corresponding
///    subpart
/// 4. Calculate the new position of connecting point, ie the rotation point
///    may have been moved and rotated and so also affecting connection points
/// 5. Update the subpart, at the connecting point, and place it on the
///    new position (x y) and add the extra rotation
/// </pre>
//////////////////////////////////////////////////////////////////////
void Part::update_points(Point p, int inc, bool reverse)
{
  if (!free) {
    pos.x = p.x;
    pos.y = p.y;
  }
  if (global) {
    rotation_added = inc;
  }
    
  // om delen inte �r free m�ste vi se att den inte roterar p� f�rbjudet omr�de
  // kanske ej n�dv�ndigt test d� den end� aldrig ska rotera d�r...

  // A part should not be able to rotate bewteen min-max vales if its not
  // free.. but the animator should make sure that this never happens
  // anyway.. still its used by the editor, when rotating with the mouse
  if (!free) {
    if ( min < rotation && rotation < max) {
      rotation = closest(rotation, min, max);
    }	
    else if (min < rotation + 255 && rotation + 255 < max ) {
      //con->printf("rotation %d, min %d, max %d\n", rotation+255, min, max);
      rotation = closest(rotation + 255, min, max); 
    }
          
  }
  
  ///////////////////////////////////////////////////////////////////// 
  // depending on direction, the rotation of the part has to be fipped
  // vertically
  if (reverse == true && flip == false) {
     flip = true;
     update_points_flip();
  }
  else if (reverse == false && flip == true) {
       flip = false;
       update_points_flip();
  }
  /////////////////////////////////////////////////////////////////////  
  // normalisera rotation
  rotation = norm_rotation(rotation);
  rotation_added = norm_rotation(rotation_added);
    
  // hitta fler parts o skriv ut dem
  list<Adds>::iterator i;
  list<Part>::iterator h;
    
  for(i=add.begin(), h=parts.begin();i != add.end() || h != parts.end(); i++, h++) {
    // r�kna ut nya positioner
    p = get_black_coord(i, reverse);  
    p = (*i).current_point = pos + p;
    (*h).update_points(p, rotation + rotation_added, reverse);
    
  }
  UpdateBoundingBox();
    
}

void Part::UpdateBoundingBox()
{
 // hitta fler parts o skriv ut dem
  list<Adds>::iterator i;
  int left, right, up, down;
  left = right = pos.x;
  up = down = pos.y;
  
    
  for(i=add.begin();i != add.end(); i++) {
    if (left > (*i).current_point.x)
       left = (*i).current_point.x;
    if (right < (*i).current_point.x)
       right = (*i).current_point.x;
    if (up > (*i).current_point.y)
       up = (*i).current_point.y;
    if (down < (*i).current_point.y)
       down = (*i).current_point.y;
  
  }
  
  box.upper_left.x = left;
  box.upper_left.y = up;
  
  box.lower_right.x = right;
  box.lower_right.y = down;

}

//////////////////////////////////////////////////////////////////////
/// find out if b collides with this part or sub-part to it
//////////////////////////////////////////////////////////////////////
void Part::Collide(BoundingBox b, bool &result, int &id_)
{
  list<Part>::iterator h;
  
  if (box.Collide(b) == true)
  {
       result = true;
       id_ = id;
       return;
    }
     
  
  for(h=parts.begin();h != parts.end(); h++) {
    (*h).Collide(b, result, id_);
  }

}

//////////////////////////////////////////////////////////////////////
/// find out if part collides with this part or sub-part to it
//////////////////////////////////////////////////////////////////////
void Part::Collide(Part p, bool &result, int &id1, int &id2)
{
  list<Part>::iterator h;
  p.Collide(box, result, id2);
  if (result == true) {
       id1 = id;
       return;
       
    }
  
  for(h=parts.begin();h != parts.end(); h++) {
    (*h).Collide(p, result, id1, id2);
  }

}

void Part::update_points_flip()
{
     rotation = flip_rotation(rotation);
       
     min = flip_rotation(min);
     if (max > 255) max -= 255;
     max = flip_rotation(max);
     
     int tmp = min;
     min = max;
     max = tmp;
     if (max < min) max += 255;
}



int flip_rooms_rules[] = {0, 2, 1, 4, 3};

int FlipRooms(int i)
{
  if (i < 0 || i > 4) {
     //allegro_message("flip rooms out of bound %d", i);
     //exit(1);
     i = 0;
     }            
  return flip_rooms_rules[i];
}

void Room(int room, int &grade, int &special_x, int &special_y) {
     special_x = 0;
     special_y = 0;
     // room 1
	if (room == 1) {
	  special_y = 128; 
	}
	// room 2
	else if (room == 2) {
	  special_y = 128;
	  grade = - grade;
	}
	// room 3
	else if (room == 3) {
	  special_x = 128;
	  grade = - grade; 
	  }
	// room 4
	else if (room == 4) {
	  special_x = -128;  
	} 
}

//////////////////////////////////////////////////////////////////////
/// <pre>
/// Calculate the new position for the connecting point, relatively the
/// rotation point. Maybe it has been change since last, if the rotation 
/// point has been changed
/// 1. We already have the length of the line from rotation point to 
/// connection point, ie hyp. and we know the new rotation which is
/// the addition of several constant rotations (grade, special_case) and
/// rotation and rotation_added.
/// </pre>
//////////////////////////////////////////////////////////////////////
Point Part::get_black_coord(list<Adds>::iterator add, bool reverse)
{
  Point right_point = (*add).point;
  fixed m = (*add).hyp;
  
  int tmp_grade = (*add).grade;  
  
  int special_case_x_extra;
  int special_case_y_extra;
  
  int room = (*add).room;
  if (reverse) {
     room = FlipRooms(room);
     
  }
  
  Room(room, tmp_grade, special_case_x_extra, special_case_y_extra);
  fixed grade = tmp_grade;
  		    
  
  Point p;
  p.x = fixtoi( fixmul( fixsin( itofix((rotation + rotation_added - grade + special_case_x_extra))), m));
  p.y = fixtoi( fixmul( fixcos( itofix(rotation  + rotation_added- grade + special_case_y_extra)), m));
  return p;
}


/////////////////////////////////////////////////////////////////////
/// If rotation point collides with any connecting points then the 
/// associated Part will be returned
/////////////////////////////////////////////////////////////////////

Part * Part::CollisionWhite(Point point, int size)
{
  // om den inte �r initierad �r vill vi inte ha vit punkt
  if (bmp == 0)
    return 0;
  // alla svarta
  list<Part>::iterator p;
  if (
      point.x > pos.x - size &&
      point.x < pos.x + size &&
      point.y > pos.y - size &&
      point.y < pos.y + size) {
    return this;
  }
    
  for(p=parts.begin();p != parts.end(); p++) {
    // kolla om en underliggande del har connectin
    Part * t = (*p).CollisionWhite(point, size);
    if (t != 0) return t;
  }
  return 0;
}


/////////////////////////////////////////////////////////////////////
/// If Part collides with any of the connecting points (with a slightly bigger
/// "size"), then this part will be returned. (maybe you wanna replace this part
/// or something) Recursively calls itself for every part in Part.
/////////////////////////////////////////////////////////////////////

list<Part>::iterator Part::Collision(Point point, int size)
{
  // alla svarta
  list<Part>::iterator p;
    
  for(p=parts.begin();p != parts.end(); p++) {
    Point bp = (*p).pos; 
    if (    
	point.x > bp.x - size &&
	point.x < bp.x + size &&
	point.y > bp.y - size &&
	point.y < bp.y + size) {
         
      // s�tt ihop den vita till den svarta
      return p;
    }
      
    // kolla om en underliggande del har connectin
    list<Part>::iterator ret = (*p).Collision(point, size);
    if (ret != 0)
      return ret;
  }
  return 0;                  
}

bool Part::connect_to(Part w)
{
  // alla svarta
  list<Adds>::iterator b;
  list<Part>::iterator p;
    
  bool ret;
    
  for(b=add.begin(),p=parts.begin();b != add.end(); b++,p++) {
    Point bp = (*p).pos; 
    if (    
	w.pos.x > bp.x - MOUSE_BOX_SIZE &&
	w.pos.x < bp.x + MOUSE_BOX_SIZE &&
	w.pos.y > bp.y - MOUSE_BOX_SIZE &&
	w.pos.y < bp.y + MOUSE_BOX_SIZE) {
         
      // s�tt ihop den vita till den svarta
      (*p) = w; 
      return true;
    }
    // kolla om en underliggande del har connectin
    (*p).connect_to(w);
    
  }
  return false;  
}


/////////////////////////////////////////////////////////////////////
/// Traverses all parts in part and adds them to list part_list 
/// It will be easier to traverse the list compared to the input tree
/////////////////////////////////////////////////////////////////////

void Part::tree_to_list(list<Part *> *part_list){
  // rita bara ut om bitmappen e laddad
  if (!bmp)
    return; 
    
  Part *part_ptr;
  part_ptr = this;
    
  part_list->push_back(part_ptr);
    
  // hitta fler parts o skriv ut dem
  list<Part>::iterator h;
  //con->printf("nr is %d\n", tmp);
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).tree_to_list(part_list);
  }
    
    
}

//////////////////////////////////////////////////////////////////////
/// Tree to list conversion really... ie ..
/// Iterate through all parts in the character and add all the parts in
/// the tree to a simple list, 
//////////////////////////////////////////////////////////////////////
void Part::insert_draw_objects(int tmp, list<Draw_orders> *lista)
{    
  // rita bara ut om bitmappen e laddad
  if (!bmp)
    return; 
  Draw_orders new_obj;
  new_obj.part_ptr = this;
  new_obj.index = z_index;
    
  lista->push_back(new_obj);
    
  // hitta fler parts o skriv ut dem
  list<Part>::iterator h;
  //con->printf("nr is %d\n", tmp);
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).insert_draw_objects(tmp+1, lista);
  }
    
    
}

//////////////////////////////////////////////////////////////////////
/// sets rotation to 0 for this part and all sub-parts connecting to it
//////////////////////////////////////////////////////////////////////
void Part::default_rotation()
{
  rotation = 0;
  rotation_added = 0;
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).default_rotation();
  }
}

//////////////////////////////////////////////////////////////////////
/// sets rotation to 0 for this part and all sub-parts connecting to it
//////////////////////////////////////////////////////////////////////
void Part::default_global()
{
  global = true;
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).default_global();
  }
}


//////////////////////////////////////////////////////////////////////
/// Draw a graph representation of the character parts connected
//////////////////////////////////////////////////////////////////////
void Part::Draw_tree(BITMAP *bitmap, int x, int y)
{
  //con->printf("list size is %d\n", parts.size());
  if (!bmp)
    return; 
  rectfill(bitmap, x, y, x+10, y+10, makecol(0, 255, 0));
    
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++, y += 20) {
    // r�kna ut nya positioner
    (*h).Draw_tree(bitmap, x+20, y);
  }
}
 
//////////////////////////////////////////////////////////////////////
/// <pre>
/// Draws all the parts connected to eachother with the correct
/// rotation by
/// 1. first add all parts in the tree - representation to a simple list
/// 2. sort this list according to the z-index of each part
/// 3. iterate the list and draw everything
/// </pre>
//////////////////////////////////////////////////////////////////////

void Part::Draw(BITMAP *bitmap, bool reverse, int y_physics, int y_offset, int xoffset)
{
  draw_order.clear();
  insert_draw_objects(0, &draw_order);
  draw_order.sort();
    
  list<Draw_orders>::iterator h;
  
  for(h=draw_order.begin();h != draw_order.end(); h++) {
     if (reverse) {
        int extra_y = 0;
     	extra_y = (*h).part_ptr->rot_point.y - ((*h).part_ptr->bmp->h - (*h).part_ptr->rot_point.y);
	pivot_sprite_v_flip(bitmap, (*h).part_ptr->bmp, (*h).part_ptr->pos.x + xoffset, (*h).part_ptr->pos.y + y_physics + y_offset, 
		 (*h).part_ptr->rot_point.x, (*h).part_ptr->rot_point.y - extra_y, itofix((*h).part_ptr->rotation + (*h).part_ptr->rotation_added+ ((reverse == true)? 128:0)));  
		 }
     
    /// changed for left-direction
      else pivot_sprite(bitmap, (*h).part_ptr->bmp, (*h).part_ptr->pos.x + xoffset, (*h).part_ptr->pos.y + y_physics + y_offset, 
		 (*h).part_ptr->rot_point.x, (*h).part_ptr->rot_point.y, itofix((*h).part_ptr->rotation + (*h).part_ptr->rotation_added+ ((reverse == true)? 128:0)));  
		 
      if (debug)
      	 (*h).part_ptr->box.Draw(bitmap);
 	  
  	     
  } 
       
}

//////////////////////////////////////////////////////////////////////
/// Return an iterator to the part with id
//////////////////////////////////////////////////////////////////////

void Part::getPart(int _id, Part &part)
{
  if (!bmp)
    return; 
  if (_id == id) {
     part = *this;
     return;
     }
     
  // hitta fler parts o skriv ut dem
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).getPart(_id, part);
  }
}

//recurse
void Part::draw_ypos()
{
  // rita bara ut om bitmappen e laddad
  if (!bmp)
    return; 
  con->printf("y: %d\n", this->pos.y); 
  // hitta fler parts o skriv ut dem
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).draw_ypos();
  }
}


/////////////////////////////////////////////////////////////////////
/// Recursively save a part
/////////////////////////////////////////////////////////////////////
void Part::save(int *nr)
{
  char string1[1000]; 
  char string2[1000]; 
    
     
  if (bmp != 0){
    set_config_string("structure", strcat(strcpy(string1, "path"), itoa(*nr, string2, 10)), file.c_str());
    set_config_int("structure", strcat(strcpy(string1, "zvalue"), itoa(*nr, string2, 10)), z_index);
    set_config_int("structure", strcat(strcpy(string1, "id"), itoa(*nr, string2, 10)), id);
    set_config_int("structure", strcat(strcpy(string1, "rotation"), itoa(*nr, string2, 10)), rotation);
    set_config_int("structure", strcat(strcpy(string1, "min"), itoa(*nr, string2, 10)), min);
    set_config_int("structure", strcat(strcpy(string1, "max"), itoa(*nr, string2, 10)), max);
    set_config_int("structure", strcat(strcpy(string1, "free"), itoa(*nr, string2, 10)), free);
  }
  (*nr)++;
     
  con->printf("list size is %d\n", parts.size());
  // g� igenom alla svarta punkter o spara dem
  list<Part>::iterator p;
  for(p=parts.begin();p != parts.end(); p++) {
    (*p).save(nr);
  }
  return;
}

/////////////////////////////////////////////////////////////////////
/// Load this Part from a .str file
/////////////////////////////////////////////////////////////////////
void Part::LoadPart(char *file, bool show_points) {
  
  int white = PART_WHITE;
  int black = PART_BLACK;   
     
  int nr = 0;
  set_config_file(file);
  if (!exists(file)) {
     allegro_message("couldnt find file %s\n", file);
     exit(1);
  } 
     
  loadpart(&nr, show_points, white, black);
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// Creates a part-tree structure from a data-file and sets all values 
/// for the parts
/// 1. sets all values of the part.
/// 2. if there really was no values in the file, we cam see this when
///    trying to load the file. Then we just return
/// 3. find and initiate the rotation point and all connecting points
///    with corresponding parts
/// 4. iterate all corresponding parts and set load them as point 1.
/// </pre>
/////////////////////////////////////////////////////////////////////
void Part::loadpart(int *nr, bool show_points, int white, int black)
{
  char string1[1000]; 
  char string2[1000]; 
  
  
     
  file = get_config_string("structure", strcat(strcpy(string1, "path"), itoa(*nr, string2, 10)), "empty");    
  // ladda all �vrig data
  z_index = get_config_int("structure", strcat(strcpy(string1, "zvalue"), itoa(*nr, string2, 10)), 0);
  id = get_config_int("structure", strcat(strcpy(string1, "id"), itoa(*nr, string2, 10)), 0);
  rotation = get_config_int("structure", strcat(strcpy(string1, "rotation"), itoa(*nr, string2, 10)), 0);
  min = get_config_int("structure", strcat(strcpy(string1, "min"), itoa(*nr, string2, 10)), 0);
  max = get_config_int("structure", strcat(strcpy(string1, "max"), itoa(*nr, string2, 10)), 0);
  free = get_config_int("structure", strcat(strcpy(string1, "free"), itoa(*nr, string2, 10)), 0);
  rotation_added = 0;
  (*nr)++;
  
  
    
  // there was no more part here.. return
  // means that bmp = NULL
  if ((bmp = LoadBitmap(file.c_str()))== NULL) {
    //con->printf("couldnt load %s\n", file.c_str()); 
    return;
  }
   	
  // hitta alla vita o svarta punkter o vinklear
  init_points(show_points);   
  //con->printf("size is %d\n", parts.size());
      
  // g� igenom alla svarta punkter o spara dem
  list<Part>::iterator p;
  for(p=parts.begin();p != parts.end(); p++) {
    (*p).loadpart(nr, show_points, white, black);
  }
    
  return;   
}
