/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <editor/anim.h>
#include <editor/part.h>
#include <editor/editor.h>
#include <fighter/fighter_states.h>
#include <global/timer.h>

// om nr_left = 0 s� �r animationen klar



// BUGG animation fastnar och hittar aldrig ut?
// verkar va fel p� �verg�ng fr�n 255 till 0 d� direction sedan returnerar
// 255 ist�llet f�r 1 efter den blivit 0
// testa med tex walk, o s�tt hands_low_right till n�t annat �n 0.. cp
// g�r ett enklare exempel o testa

// fortfarande att ingen rotation f�r ha v�rdet 0 ????
// + att de verkar som om min och max m�ste ligga mellan 0-255
// om de blir tex 3 och 450 ere k�rt
  
/////////////////////////////////////////////////////////////////////
/// sets all variables to default
/////////////////////////////////////////////////////////////////////
Anim::Anim()
{
  id = 0;
  rotation = 0;
  speed = 0;
  end = false; 
  global = 1;
  speed_count = 0;
  x = y = 0;
  count_x = count_y = 0;
};


MultiAnim::MultiAnim() {
  for (int i = 0; i < NR_ACTIONS; i++)
    action.index[i] = -1;
    
  action.counter = 0;
  one_timer = false;  
}

/////////////////////////////////////////////////////////////////////
/// The next sub animation to play is the first one, ie playing from
/// the beginning
/////////////////////////////////////////////////////////////////////
void MultiAnim::Init()
{
  index = anims.begin();  
  state = 0;
  loop = false;
  
  action.counter = 0;
  
}
/////////////////////////////////////////////////////////////////////
/// Returns true if the animation has looped once and resets the
/// loop variable so one can check for a loop again
/////////////////////////////////////////////////////////////////////
bool MultiAnim::End()
{
     if (loop == true) {
     	loop = false;
     	return true;
     }
     else return false;
          		     
}

// plockar ut f�rsta delanimationen o animerar den animation
// f�r animtion. Om inget mer animeras s� �r delanimationen klar
// och s� �kas ett index s� att n�sta delanimation kan k�ras
// n�r vi har kommit till slutet p� listan med delanimationer
// �r hela animationen slut. 
// N�r animationen �r klar f�rsta g�ngen s�tts loop... o sen
// forts�tter animationen loopa

/////////////////////////////////////////////////////////////////////
/// <pre>
/// 1. gets the first sub-animation and animate all its animations in 
///    parallell.
/// 2. when all the animations in the sub-animation is done we increase
///    index so we know that its time to animate next sub-animtion 
/// 3. when all sub-animations have been played loop will be set to true
///    and the animation is set up for a restart 
/// 4. returns the action nr of an finnished subanimation, otherwise 0 
/// </pre>
/////////////////////////////////////////////////////////////////////

int Part::animateMulti(MultiAnim *anim, bool reverse)
{
      // om vi har spelat upp alla animationer �r allt klart
  if (anim->index == anim->anims.end()) {
// efter en loop k�rs aldrig f�rsta animationen igen.. den �r en starter
    anim->index = anim->anims.begin();  
    if (anim->anims.size() > 1) {
        anim->index++;  
    	anim->action.counter = 1;
    }
    else 
    	 anim->action.counter = 0;
    anim->loop = true;
    default_global();
    anim->state = 0;
    
    
  }   
    
    // if only to play once 
  if (anim->one_timer == true && anim->loop == true) {
     //con->printf("no more of thjis\n");
     return 0;     
  }

  // start of animation
  if (anim->state == 0) {
     // no animations
     if (anim->anims.empty()) {
        //con->printf("no animation to run\n");
        return 0;				  
     }
     //anim->Init();
     anim->state = 1; 
     anim->DefaultMove(); 
      
  }
  int ret = 0;
  if (anim->state == 1)
  {
      list<Anim>::iterator p;
        
      int nr_left = 0;
      
      
      for(p=(*anim->index).begin();p != (*anim->index).end(); p++) {  
    	 animate(&(*p), &nr_left, reverse);
      }
       //con->printf("nr_left = %d\n",  nr_left); 
      // h�r �r en delanimation klar s� �ka index till n�sta
      if (nr_left == 0) {
        // check if this subanimation triggers an action.. ie hit 
        if (anim->action.index[0] == anim->action.counter) {
           ret = 1;
           
        }
        if (anim->action.index[1] == anim->action.counter) {
           ret = 2;
        }	      
         	      
        anim->index++;
        anim->action.counter++;
        //con->printf("animation done %d\n", anim->action.counter);
        
      }
 }
 return ret;
}




/////////////////////////////////////////////////////////////////////
/// <pre>
/// 1. Checks if this animation should be applied to this part 
/// 2. Checks if the speed doubles, triples etc or halves, halves by 3 etc 
/// 3. rotate one step at a time and check if the rotation is done, if
///    so "end" is set to true, else "ne_left" will be increased 
/// 4. Recursively do this for all sub-parts
/// </pre>
/////////////////////////////////////////////////////////////////////
void Part::animate(Anim *anim, int *nr_left, bool reverse)
{
   
  if (!bmp)
    return; 
    
  // set the global rotation for this animation
  global = (*anim).global;
    
  // animera kanske den h�r delen
  if (id == (*anim).id) {
    /// BUGG!!!! raden nedan g�r att man inte kan rotera till 0 grader f�r en del
    //if ((*anim).rotation != 0)
       rotate(anim, nr_left, reverse);
    /*
    else if ((*anim).y != 0)
       move(anim, nr_left, (*anim).count_y, (*anim).y, pos.y);
    else if ((*anim).x != 0)
       move(anim, nr_left, (*anim).count_x, (*anim).x, pos.x);  
       */ 
  }
  /////////////////////////////////////////////////////////////////////
   
  list<Part>::iterator h;
  for(h=parts.begin();h != parts.end(); h++) {
    // r�kna ut nya positioner
    (*h).animate(anim, nr_left, reverse);
  }  
}

void Part::move(Anim *anim, int *nr_left, int &count, int new_pos, int &pos)
{
 
    ///////////////////////////////////////////////////////////////////// 	    
    /// high speed
    if ((*anim).speed >= 0) {	       
      
      for ( int i = 0; i < (*anim).speed; i++) {
	// om vi inte har kommit till m�let �n s�
	// g� ett steg n�rmare
	if (count != new_pos) {
 	   // increase or decrease pos
	  if (count < new_pos){
	     pos++;
	    count++;
	  }
	  else {
   	     pos--;
	    count--;
   	  }
	  (*nr_left)++;
	}
	else {
          (*anim).end = true;
          
	  break;
	}
      }
    }
    
    /////////////////////////////////////////////////////////////////////
    /// slow speed
    else if ((*anim).speed < 0) {	       
      if ((*anim).speed_count >= (-1*(*anim).speed)) {
        
	// om vi inte har kommit till m�let �n s�
	// g� ett steg n�rmare
	(*anim).speed_count = 0;
	if (count != new_pos) {
	   // increase or decrease pos
	  if (count < new_pos){
	     pos++;
	    count++;
	  }
	  else {
   	     pos--;
	    count--;
   	  }  
	}
	else {
       	  (*anim).end = true;
       	}
          
      }
      // this animation is not finnished
      if (count != new_pos) {
         (*nr_left)++;
      }
      (*anim).speed_count++;
    }
}

void Part::rotate(Anim *anim, int *nr_left, bool reverse)
{
    int rotation_end = (reverse == false)? (*anim).rotation: flip_rotation((*anim).rotation);
    ///////////////////////////////////////////////////////////////////// 	    
    /// high speed
    if ((*anim).speed >= 0) {	       
      
      for ( int i = 0; i < (*anim).speed; i++) {
	// om vi inte har kommit till m�let �n s�
	// g� ett steg n�rmare
	// m�ste normalisera
	
	if (rotation != rotation_end) {
          //con->printf("start %d,  end %d, nr_left %d\n", rotation, rotation_end, *nr_left);
          int temp = direction(rotation_end);
          rotation += temp;
          //rotation = norm_rotation(rotation);
          
	      (*nr_left)++;
	      
	      
	  
	}
	else {
	  (*anim).end = true;
	  break;
	}
      }
    }
    /////////////////////////////////////////////////////////////////////
    /// slow speed
    if ((*anim).speed < 0) {	       
      if ((*anim).speed_count >= (-1*(*anim).speed)) {
        
	// om vi inte har kommit till m�let �n s�
	// g� ett steg n�rmare
	(*anim).speed_count = 0;
	if (rotation != rotation_end) {
	  rotation += direction(rotation_end);
	  //rotation = norm_rotation(rotation);
                
	}
	
	else {
       		 
	  (*anim).end = true;
	}
          
      }
      
      // this animation is not finnished
      if (rotation != rotation_end) {
         (*nr_left)++;
      }
      (*anim).speed_count++;
    }
     		       
}


/////////////////////////////////////////////////////////////////////
/// <pre>
/// Finds the way we should rotate up/down, depending on were the gap is set
/// in the rotation domain, ie cant rotate between min and max. 
/// 1. If the part doesnt have an min/max gap (free) then we just take  
///    the fastest way 
/// 2. dont remember...
/// </pre>
/////////////////////////////////////////////////////////////////////
int Part::direction(int end_rotation)
{
  // om delen ligger fritt och inte har n�got h�l s� ska vi bara hitta den
  // snabbaste v�gen fr�n start till m�l
  if (free) {
    if (end_rotation >= rotation) {
      if (abs(end_rotation - rotation) < 128)
	return 1;
      else return -1;
    }
    else if (end_rotation < rotation) {
      if (abs(end_rotation - rotation) < 128)
	return -1;
      else return 1;
    }
  }
    
  //  kolla om start och m�l ligger p� samma sida om h�let..
  // i s� fall blir det enkelt att g� fr�n start till m�l d�
  // inte m�let ligger emellan.
  if ( (rotation <= min) && (end_rotation <= min) ||
       (rotation >= max) && (end_rotation >= max) ) {
    if (rotation < end_rotation) return 1;
    if (rotation > end_rotation) return -1;
  }
  // om h�let ligger emellan start och m�l m�ste vi kolla om
  // start ligger mer till v�nster (el h�ger) �n h�let. Om det �r s�
  // m�ste vi minska s� vi g�r bakl�nges runt h�let.
  else {
    if (rotation <= min) return -1;
    if (rotation >= max) return 1;
  }
  return 0;
}

// hur de editerbara blocken.. ett f�r varje animtion
// storlek o mellanrum

static int block_size_x = 10;
static int block_size_y = 10;
static int block_space_x = 20;
static int block_space_y = 20;


/////////////////////////////////////////////////////////////////////
/// Draw the graph-tree representing animation
/// with highlights of selected subanimation and animation
/////////////////////////////////////////////////////////////////////
void MultiAnim::Draw_tree(BITMAP *bitmap, int x, int y, 
     list< list<Anim> >::iterator sel_subanim, list<Anim>::iterator sel_anim)
{
  int start_x = x;  
  list< list<Anim> >::iterator h;
  for(h=anims.begin();h != anims.end(); h++, y += block_space_y) {
    x = start_x;
    // print sub-animation
    int sub_color = makecol(255, 150, 0);
    if (h == sel_subanim) sub_color = makecol(255, 255, 0);
    rectfill(bitmap, x, y-5, x+block_size_x, y+block_size_y, sub_color);
    // skriv ut varje del f�r sig
    list<Anim>::iterator t;
        
    for(t=(*h).begin();t != (*h).end(); t++, x += block_space_x) {
      // r�kna ut nya positioner
      
      int color = makecol(0, 150, 0);
      if (t == sel_anim) color = makecol(0, 255, 0);
      rectfill(bitmap, x, y, x+block_size_x, y+block_size_y, color);
    }
  }
}

void MultiAnim::DefaultMove()
{
  list< list<Anim> >::iterator h;
  for(h=anims.begin();h != anims.end(); h++) {
    
    list<Anim>::iterator t;
        
    for(t=(*h).begin();t != (*h).end(); t++) {
    	(*t).count_x =  (*t).count_y = 0;
    }
  }
}


/*
  ser vilken animation som �r markerad och returnerar denna
  annars null, ges ocks� en delanimations pekare s� att vi sedan
  kan veta vilken lista den kom ifr�n, tex om vi vill ta bort anim senare
*/

/////////////////////////////////////////////////////////////////////
/// Looks in the graph-tree representing the animation structure and sets
/// what sub-animation (delanim) is marked by the mouse, if its not marked
/// it is set to NULL. Then sees if any animation is marked and returns an
/// iterator to that mark, otherwise NULL
/////////////////////////////////////////////////////////////////////
list<Anim>::iterator MultiAnim::EditBlocks(int x, int y, list< list<Anim> >::iterator *delanim)
{
  int start_x = x;  
  //*delanim = NULL;
  list< list<Anim> >::iterator h;
  for(h=anims.begin();h != anims.end(); h++, y += block_space_y) {
    x = start_x;
    // kolla om delanimationen markeras o uppdatera d� delanim                 
    if (mouse_x >= x && mouse_x <= x+block_size_x &&
	mouse_y >= y-5 && mouse_y <= y+block_size_y) { 
      *delanim = h;        
    }                             
    // skriv ut varje del f�r sig
    list<Anim>::iterator t;
        
    for(t=(*h).begin();t != (*h).end(); t++, x += block_space_x) {
      // r�kna ut nya positioner
      // om musen ligger p� n�gon av blocken i tr�det
      if (mouse_x >= x && mouse_x <= x+block_size_x &&
	  mouse_y >= y && mouse_y <= y+block_size_y) {
	// visa info om animationen
	*delanim = h;
	return t;   
      }
                  
    }
  }
  
  return NULL;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// Looks at the current selected part (node) of the tree-graph representing all
/// animations. This method should only be called if an part is selected
/// Then certain actions can be performed on this part: 
/// 1. deletion with DELETE key 
/// 2. animation speed change with left shift 
/// 3. deletion of all sub-animations (deletion of one row in the tree) 
/// 4. insertions of an animation with right mouse button 
/// </pre>
/////////////////////////////////////////////////////////////////////
bool Editor::EditAnimation()
{
  // if no subanimation marked then do nothing
  if (del_animation_mark == 0) {
	 
	 return true;
	 }
  
  // om du h�ller in kontrol s� ta bort hela delanimationen.. grenen 
  if (key[KEY_LCONTROL] && key[KEY_DEL]) { 
    while (key[KEY_LCONTROL] && key[KEY_DEL]);
      anim.anims.erase(del_animation_mark);     
      del_animation_mark = NULL;
      animation_mark = NULL;                
  }  
  // k�r dessa om du markerat just en animation
  else if (animation_mark != NULL) {
    if (Key(KEY_DEL)) {
      (*del_animation_mark).erase(animation_mark);
      // unmark everything
      //del_animation_mark = -1;
      animation_mark = NULL;
    }
     
    // editera v�rdena rotation eller speed
    if (old_mouse_z != mouse_z) {
      if (old_mouse_z < mouse_z) {
	if (key[KEY_LSHIFT]) {
	  (*animation_mark).global++;
	}
	else if (key[KEY_LCONTROL]) {
	    (*animation_mark).rotation++;
	}
	else if (key[KEY_A]) {
	    (*animation_mark).x++;
	}
	else if (key[KEY_Z]) {
	    (*animation_mark).y++;
	}
	else 
	  
	  (*animation_mark).speed++;
      }
      else {
	if (key[KEY_LSHIFT]) {
	   (*animation_mark).global--;
	}
	else if (key[KEY_LCONTROL]) {
	    (*animation_mark).rotation-- ;
	}
	else if (key[KEY_A]) {
	    (*animation_mark).x--;
	}
	else if (key[KEY_Z]) {
	    (*animation_mark).y--;
	}
	else
	  
	  (*animation_mark).speed--;
      }
      old_mouse_z = mouse_z;
    }
    //norm_rotation((*animation_mark).rotation);
  }
  
           
  ///////////////////////////////////////////////////////////
  // skapar en ny animaion o l�gger den til listan av animationer
  // om musen h�lls �ver n�gon fyrkant s� ska den insertas efter denna
     
  if ((mouse_b & 2) && (right_mouse_hold == false) && marked != NULL) {
    Anim anim;
    anim.id = marked->id;
    anim.rotation = marked->rotation;
    anim.speed = 1;
    // om  man markerat n�t i tr�det inserta
            
    // if the subanimation is empty then just push it back
    if ((*del_animation_mark).empty()) {
       (*del_animation_mark).push_back(anim);
        con->printf("sub-anim, size %d\n", (*del_animation_mark).size());
    }
    
            
    else if (animation_mark != NULL) {
      (*del_animation_mark).insert(animation_mark, anim); 
    }
            
    // annars om grenen �r tom l�gg till den i slutet
    else {
      (*del_animation_mark).push_back(anim);
      //con->printf("sub-anim, size %d\n", (*del_animation_mark).size());
//      exit(1);
    }
            
    right_mouse_hold = true;
  }
  // om du inte h�ller in n�h�ger musknapp l�ngre
  else if (!(mouse_b & 2)) {
    right_mouse_hold = false;
  }
  return true;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// Prints info about
/// 1.the marked part (part on screen)
/// 2.the marked animation (node) in the graph-tree of animations
/// 3.the marked animation-set, ie all animations that should be made in parallell
///   and is located in the same row
/// 4.animation status ie running, type of animation made ie STAND, Help info
/// </pre>
/////////////////////////////////////////////////////////////////////
void Editor::AnimInfo(BITMAP *bitmap)
{
  if (animation_mark != NULL) {
    Anim a = *animation_mark;  
    
    static string menu1[] = 	{"name",
    	   	  	  	"id",
    	   		 	 "rotation", 
     			    	 "speed",
     			      	 "global",
				 "x",
				 "y",
				 "action1",
				 "action2"
				 }; 
   static string menu2[9];
   char buff[100];
   menu2[0] = (a.id < P_NR_OF && a.id >= 0)? Part_Name[a.id]: "UKNOWN";
   menu2[1] = itoa(a.id, buff, 10);
   menu2[2] = itoa(a.rotation, buff, 10);
   menu2[3] = itoa(a.speed, buff, 10);
   menu2[4] = itoa(a.global, buff, 10);
   menu2[5] = itoa(a.x, buff, 10);
   menu2[6] = itoa(a.y, buff, 10);
   menu2[7] = itoa(anim.action.index[0], buff, 10);
   menu2[8] = itoa(anim.action.index[1], buff, 10);
    
   PrintTable(bitmap, menu1, menu2, 
  		     makecol(0,100,255), makecol(0,200,255),
		     120, 55, 70, 10, 9 );
   }
       
  if (del_animation_mark != 0) {
    ;
  }
     
     
  // om animationen k�rs
  if (animation_run == true) {
    textprintf_ex(bitmap,font,SCREEN_W/2,SCREEN_H - SCREEN_H/8, -1, makecol(255,255,255),
	       "Running animation");
  }
      
  // h�r visas vilken sorts animation det �r fr�gan om.. stand , jump osv
  textprintf_ex(bitmap,font,SCREEN_W - SCREEN_W/3,SCREEN_H/6,makecol(0,255,0), -1,
	     "Anim-type: %s", movement_state_name[animation_type]);
          
  // hj�lp text
  
  static string left_help_menu[] = {"left mouse", 
       			    "right mouse",
  			    "space",
  			    "up/down",
  			    "key 1",
	 		    "key 2",
  			    "key F",
  			    "key P",
  			    "click add + ctrl",
  			    "Tree Edit: ",
  			    "wheel",
  			    "wheel + ctrl",
  			    "wheel + shift",
  			    "del",
  			    "del + ctrl"
  			    };
  static string right_help_menu[] = {"set rotation", 
       			    "add animation",
  			    "play animation",
  			    "change type",
  			    "set action1",
  			    "set action2",
  			    "Flip character",
  			    "Physics on/off",
  			    "insert before selected",
  			    "---------------",
  			    "change speed",
  			    "change rotation",
  			    "change global",
  			    "delete animation",
  			    "delete subanimation (row)"
  			    };
			      
  PrintTable(bitmap, left_help_menu, right_help_menu, 
  		     makecol(255,255,100), makecol(255,255,255),
		     5, SCREEN_H-157, 115, 10, 15 );
		     

}


/////////////////////////////////////////////////////////////////////
/// Saves all information about the animation to file, by iterating
/// all animations
/////////////////////////////////////////////////////////////////////
void Editor::SaveAnimation(char *file)
{
  char path[80*6];
  path[0] = 0;
    
  if (file_select_ex("Save Animation:", path, EXT_ANIM, 80*6, 0, 0) == 0) {
     con->printf("cancel save...\n");
     return;
  }
  
  if (strcmp(get_extension(path), EXT_ANIM) != 0)
    strcat(path, EXT_ANIM);
    
    
  file = path;      				
  set_config_file(file);
  int x, y;
  x = 0;
  string temp; 
  char string2[1000]; 
  
  set_config_int(movement_state_name[animation_type], "oneTimer", anim.one_timer);
  set_config_int(movement_state_name[animation_type], "action1", anim.action.index[0]); 
  set_config_int(movement_state_name[animation_type], "action2", anim.action.index[1]); 
    
  list<list<Anim> >::iterator h;
  for(h=anim.anims.begin();h != anim.anims.end(); h++, x++) {
        
    // skriv ut varje del f�r sig
    list<Anim>::iterator t;
    y = 0;
    for(t=(*h).begin();t != (*h).end(); t++, y++) {
      Anim a = (*t);
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_id"; 
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.id); 

      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_rotation"; 
       // BUGG solves the mystera 0-value rotation bugg :) ..perhaps
        if (a.rotation == 0) {a.rotation = 1;}
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.rotation); 
           
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_speed"; 
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.speed); 
           
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_global"; 
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.global); 
           
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_x"; 
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.x); 
      
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_y"; 
      set_config_int(movement_state_name[animation_type], temp.c_str(), a.y); 
    }
  }
  flush_config_file();
}


/////////////////////////////////////////////////////////////////////
/// <pre>
/// Loads an Multi Animation from a file, with the specified type, ie
/// STAND, WALK...
/// 1. clears old animation tree
/// 2. tries to find the id value for the first animation in a 
///    subanimation, from the file, if id was set to -1 we assume there 
///    are no more subanimations to load
/// 3. otherwise iterate all subanimations and set the corresponding values
///    from the file to the animation.
/// 4. go to next subanimation as described in point 1.
/// </pre>
/////////////////////////////////////////////////////////////////////
void MultiAnim::Open(char *file, int type)
{
   if (!exists(file)) {
     allegro_message("couldnt find file %s\n", file);
     exit(1);
  } 
  
     // nullst�ll animation
  anims.clear();
     
  set_config_file(file);
  int x, y;
  x = y = 0;
  string temp; 
  char string2[1000]; 
    
  one_timer = get_config_int(movement_state_name[type], "oneTimer", 0);   
  action.index[0] = get_config_int(movement_state_name[type], "action1", -1); 
  action.index[1] = get_config_int(movement_state_name[type], "action2", -1); 
         
  for(; true; x++) {
    y = 0;
    // hittar vi inte b�rjan p� en sub-animation s� �r vi klara
    temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_id";
    int test = get_config_int(movement_state_name[type], temp.c_str(), -1);
    if (test == -1) {
      break;
    }
       
    list<Anim> danim;
    bool more = true;
       
    for(;true; y++) {
      Anim a;
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_id";
      a.id = get_config_int(movement_state_name[type], temp.c_str(), -1); 
          
      // betyder att vi inte har fler animationer att ladda
      if (a.id == -1) {
	break;
      }
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_rotation"; 
      a.rotation = get_config_int(movement_state_name[type], temp.c_str(), 0); 
           
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_speed"; 
      a.speed = get_config_int(movement_state_name[type], temp.c_str(), 0); 
          
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_global"; 
      a.global = get_config_int(movement_state_name[type], temp.c_str(), 0); 
          
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_x"; 
      a.x = get_config_int(movement_state_name[type], temp.c_str(), 0);   
      
      temp = string(itoa(x, string2, 10)) + "_" + string(itoa(y, string2, 10)) + "_y"; 
      a.y = get_config_int(movement_state_name[type], temp.c_str(), 0);     
        
      // BUGG solves the mystera 0-value rotation bugg :) ..perhaps
      if (a.rotation == 0) {a.rotation = 1;}
    
          
      // skapa en lista av delanimationer
      danim.push_back(a);
       
    }
    if (more == false)
      break;
    anims.push_back(danim);
    Init();
  }
  
}
         


/* DONE (#1#): animateMulti ska byta del-animationer... just nu k�r den bara front */

/* DONE (#2#): kunna markera en fyrkant i draw_tree o se information om den */
/* DONE (#2#): kunna ta bort, �ndra l�gga till en fyrkant i draw_tree*/
/* DONE (#1#): ctrl-delete funkar ej f�r delanimationer...*/
/* TODO (#1#): kunna specificera vilken sorts animation det �r...HIT, KICK, JUMP osv*/
/* TODO (#2#): l�gga till fakta om varje animation tex action1-action4 som s�ger att h�r i
   animationen h�nder n�t speciellt*/
/* TODO (#3#): kunna spara o �ppna animationer beroende p� typ dvs HIT, KICK osv..*/


/* TODO (#1#): anv�nd float i speed ist�llet.. f�r att kunna animarea 
   saktare */
