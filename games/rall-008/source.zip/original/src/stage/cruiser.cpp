/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <stage\cruiser.h>
#include <global/global.h>

void Cruiser::Load()
{
  cruiser_water_speed.delay = 10;
  cruiser_water_scroller = 4;
  
  water_tile[0] = LoadBitmap("graph//stage//cruiser//water1.jpg");
  water_tile[1] = LoadBitmap("graph//stage//cruiser//water2.jpg");
  water_tile[2] = LoadBitmap("graph//stage//cruiser//water3.jpg");

  small_boat = LoadBitmap("graph//stage//cruiser//boat.bmp");
  deck =       LoadBitmap("graph//stage//cruiser//deck.bmp");
  inzoom =     LoadBitmap("graph//stage//cruiser//inzoom.bmp");
    
  for (int i = 0; i < WATER_SIZE; i++) {
    water_pic[i] = create_bitmap(water_tile[0]->w * 4, water_tile[0]->h * 4);
  }

  // fyll den
  for (int i = 0; i < WATER_SIZE; i++)
    for (int x = 0; x < water_tile[i]->w * 4; x += water_tile[i]->w) 
      for (int y = 0; y < water_tile[i]->h * 4; y += water_tile[i]->h) 
	draw_sprite(water_pic[i], water_tile[i], x, y);
  
  vscr = create_bitmap(SCREEN_W, SCREEN_H);
  
  x1 = 0;
  x2 = water_pic[0]->w;
  water_picture = water_pic[0];
  
  deck_x = DECK_X;
  deck_y = DECK_Y;
  global_counter = 0;
  
  sounds[0].load ("sound//stage//engine.wav");
  sounds[1].load ("sound//stage//horn.wav");

  sound_state = 0;
}

Cruiser::Cruiser() {
  ground = 452;
}

BITMAP *Cruiser::ShowDeck(){
       
  
   // skaka lite p� b�ten
  global_counter++;
  if (global_counter > 30) {
    deck_y += rand() % 2;
    deck_y -= rand() % 2;
    if (deck_y > DECK_Y + 30)deck_y = DECK_Y + 30;
    if (deck_y < DECK_Y - 30)deck_y = DECK_Y - 30;
    global_counter = 0;
    // alla karakt�rer ska h�nga med 
    y_variation = deck_y - DECK_Y;
  }
  
  
  // spela kanske upp ljud
  if (sound_state == 0) {
     for (int i = 0; i < 2; i++)                
       sounds[i].play();
     sound_state = 1;
     sound_delay.delay = sec_to_fps((rand() % 30) + 20);
  }
  // v�nta ett tag innan du spelar upp ljud igen
  if (sound_state == 1) {
     if (sound_delay.Check())
        sound_state = 0;
  }

  return deck;  
  //draw_sprite(vscr, deck, deck_x, deck_y);
}

void Cruiser::ShowWater()
{
    // byt vatten bild
    if (cruiser_water_speed.Check()) {
      water_picture = water_pic[rand() % WATER_SIZE];
    }
    draw_sprite(vscr, water_picture, x1, 0);
    draw_sprite(vscr, water_picture, x2, 0);
    
    
    // scrollning AV vatten
    for (int i = 0; i < cruiser_water_scroller; i++) {
      x1--;
      x2--;
      // byt plats p� bilderna
      if ((x1 + water_pic[0]->w)  <= 0) x1 = water_pic[0]->w;
      if ((x2 + water_pic[0]->w)  <= 0) x2 = water_pic[0]->w;
      
      
    }
}  

