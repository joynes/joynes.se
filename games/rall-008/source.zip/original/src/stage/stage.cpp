/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <stage/stage.h>

#include <global/global.h>
#include <console/conalleg.h>
void Stage::Init(char *stage)
{
  
    
    cruiser.Load();
    camera_x = SCREEN_W / 2; 
    bitmap = 0; 
    
    length = cruiser.deck->w;
    
    Sample sounds[2];
    int sound_state;
    timing sound_delay;
}    

BITMAP *Stage::Foreground()
{
    
}    

BITMAP *Stage::Background()
{
   cruiser.ShowWater();
   
   BITMAP *deck = cruiser.ShowDeck();
   
   pivot_sprite(cruiser.vscr, deck, SCREEN_W/2, SCREEN_H/2 + cruiser.deck_y - 40, camera_x, deck->h/2, itofix(0));
   
   return cruiser.vscr;
   
}   

void Stage::UpdateCamera(int x)
{
  
       // om spelare �r f�r l�ngt till v�nster
     if (x <= (SCREEN_W / 2)) {
         camera_x = (SCREEN_W / 2);
     } 
       // om spelare �r f�r l�ngt till h�ger
     else if (x >= (length - SCREEN_W / 2)) {
          camera_x = (length - SCREEN_W / 2);
     }
       // annars scrolla
     else {
          camera_x = x;
     }
     
} 

void Stage::Draw(BITMAP *world_bitmap)
{
     BITMAP *deck = cruiser.ShowDeck();
     //draw_sprite(deck, deck, 0, 0);
     //draw_sprite(world_bitmap, deck, 0, cruiser.deck_y);
     
     pivot_sprite(world_bitmap, deck, SCREEN_W/2, SCREEN_H/2, camera_x, cruiser.deck_y-100, itofix(0));     
}

void Stage::DrawBackground(BITMAP *background_bitmap)
{
     cruiser.ShowWater();
     
     draw_sprite(background_bitmap, cruiser.vscr, 0, 0); 
}


int Stage::GetYOffset()
{
    return cruiser.y_variation;
}

