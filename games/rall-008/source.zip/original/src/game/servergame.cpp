#include <network\server.h>

void Server::Init(FileData _filedata, Stage *stage)
{
  this->filedata = _filedata;
  this->stage = stage;
  
  bot_energy = 25;
   nr_bots = 0;
   bot_max = 4;
   bot_min_delay = sec_to_fps(15);
   bot_max_delay = sec_to_fps(35);
   
   bot_delay.delay = sec_to_fps(10);
	  // max nr of bots
}

//////////////////////////////////////////////////////////////////////////////
/// If player is outside the World-bound, the returned pos will be corrected
//////////////////////////////////////////////////////////////////////////////

int Server::worldCollision(int leftbound, int rightbound, int x)
{
    
  if (x > rightbound)
    x = rightbound;
      
  if (x < leftbound)
    x = leftbound;
   
  return x;
}

void Server::worldCollision(int length)
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
         
	fighter->SetX( worldCollision(30, length - 30, fighter->GetX()));
      }
  }
}

void Server::setGround(int ground)
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
	fighter->physics.ground = ground;
      }
  }
}

//////////////////////////////////////////////////////////////////////////////
/// Sets new positions of player i if player i collides with any other players
//////////////////////////////////////////////////////////////////////////////
void Server::updateBodyCollision(int i)
{
     
  // enkel kollision-detection med kropparna
  for (int j = 0; j < OBJ_MAX; j++) {
          
    Fighter *us = fighters[i];
    Fighter *enemy = fighters[j];
          
    if (enemy != NULL && enemy != us && enemy->isReady()) {
	  
      // om fienden kolliderar med oss och om b�da har ett kolliderande
      // state
      if (us->data.bodybox.Collide(enemy->data.bodybox) && 
	  isCollide(us->data.movement_state)&& isCollide(enemy->data.movement_state)) {
	//con->printf("bodycoll\n");	
      	     
	// om fienden st�r till h�ger
	if (us->GetX() < enemy->GetX()) {
	  int new_x = enemy->data.bodybox.upper_left.x -  
	    max(us->GetX() - us->data.bodybox.upper_left.x,
    	        us->data.bodybox.lower_right.x - us->GetX());
	      		
	  us->SetX(new_x);
	}
	// om han st�r till v�nster
	else {
	  int new_x = enemy->data.bodybox.lower_right.x +  
	    max(us->GetX() - us->data.bodybox.upper_left.x,
		us->data.bodybox.lower_right.x - us->GetX());		
        	     
	  us->SetX(new_x);
	        
	}
            
      }
	  
    }
  } 				  
}


//////////////////////////////////////////////////////////////////////////////
/// Sets new positions of player i if player i collides with any other players
//////////////////////////////////////////////////////////////////////////////
void Server::updateHITCollision(int i)
{
  // enkel kollision-detection med kropparna
  Part our_body;
  fighters[i]->part.getPart(P_ARM_LOWER_RIGHT, our_body);
  for (int j = 0; j < OBJ_MAX; j++) {
    Part enemy_body;
    if (fighters[j] != NULL && fighters[j] != fighters[i]) {
      fighters[j]->part.getPart(P_BODY, enemy_body);
 	  
      if (our_body.box.Collide(enemy_body.box)) {
	con->printf("hitcoll\n");	
      	     
	// om fienden st�r till h�ger
	if (fighters[i]->GetX() < fighters[j]->GetX()) {
	  ;
	}
	// om han st�r till v�nster
	else {
	  ;
	}
            
      }
	  
    }
  } 				  
}

//////////////////////////////////////////////////////////////////////////////
/// Finds out if opp_fighter gets hit by our_fighter
/// if so it reeturns true
/// this function should return true 
/// direction should be retunred from another function
//////////////////////////////////////////////////////////////////////////////
bool Server::Collide(Fighter *our_fighter, Fighter *opp_fighter, int our_part, int opp_part)
{
  // enkel kollision-detection med kropparna
  Part our_body;
  our_fighter->part.getPart(our_part, our_body);
      
  Part enemy_body;
  //	  if (fighters[j] != NULL && fighters[j] != fighters[i]) {
	
  opp_fighter->part.getPart(opp_part, enemy_body);
 	  
  if (our_body.box.Collide(enemy_body.box)) {
    con->printf("hitcoll\n");	
    return true;

      	     
      	     
    // om fienden st�r till h�ger
    if (our_fighter->GetX() < opp_fighter->GetX()) {
      ;
    }
    // om han st�r till v�nster
    else {
      ;
    }
            
  }
  else 
    return false;
	  
      
       				  
}

/////////////////////////////////////////////////////////////////////
/// find out whom to attack (dependingin on points of the human fighters)
/// and returns data for this victim
/////////////////////////////////////////////////////////////////////
ChangableData botAttackData(Fighter *fighters[])
{
  int points = 0;
  ChangableData data;
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i] && fighters[i]->data.ai == false && fighters[i]->isReady()) {
      if (fighters[i]->data.points >= points) {
	data = fighters[i]->data;   
	points = fighters[i]->data.points;        
      }      
    }
  }
  return data;
}

/////////////////////////////////////////////////////////////////////
/// update input of all bots
/////////////////////////////////////////////////////////////////////
void Server::updateBot(Fighter *fighter)
{
  // om det �r en bot
  if (fighter && fighter->data.ai == true && fighter->isReady()) {
    // hitta den spelare som har minst energi och returnera honom
    Fighter *bot = fighter;
    ChangableData enemy = botAttackData(fighters);
    // avst�nd till motst�ndare.. om -x s� �r han till v�nster
    int distance = bot->data.pos.x - enemy.pos.x;
    Movement_State state = enemy.movement_state;
    Movement_State whish_state = bot->updateBotState(distance, state);
    ControlNetwork control = bot->updateBotInput(distance, whish_state);
               
    bot->control_net =  control;
               
    ;
        
  }
}

void Server::update()
{
     
  // spawn a player on a random position
  if (WaitingFighter()) {
    Point p;
    p.x = rand() % (filedata.stage_length - SCREEN_W/2 - 10);
    p.y = 100;
    SpawnFighter(filedata.SpawnTime, p);
  }
  
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
	// some network shit
	fighters[i]->update();
      
	// check if he is going out from spawn-state
	fighter->data.game_state = fighter->SpawnNext();
	
	////////////////////////////////////////
	  // mayby spawn bots
	if (filedata.MaxBots > 0) {
        // might spawn a bot
      if (bot_delay.Check()) {
           if ( nr_bots < filedata.MaxBots) {
           Addbot();
           nr_bots++;
           bot_delay.delay = bot_min_delay + (rand() % bot_max_delay);
           }
        }
      }
      
      worldCollision(filedata.stage_length);
    ////////////////////////////////////////
	// if player is not playing, try to initiate him
	if (fighters[i]->isReady() == false) {
          // try to init an uninitiated fighter                        
	  fighter->data.game_state = fighter->TryInit();
	    // om bot s� minska energy
         if (fighter->data.ai) {
            fighter->data.energy = 32;
         }
              
	}
	else
	  {
	    // update input if it was a bot
	    updateBot(fighter);
	    ///////////////////////////////////////
	    // update controls and states 
            // chooses which of the keys will be used
	    fighter->GetControls(); 
	    // updates state depending on control pressed
	    // everything except x,y movement
	    fighter->UpdateControls();
                
            // updates state depending on time-depending states that
            // means a state may be finnsihed after animation is done
            // does not affect x,y
        
	    fighter->UpdateStates();
        
	    // updates position of character
	    Velocity vel;
	    vel = fighter->UpdateVelocity(fighter->data.movement_state, fighter->data.direction_state, vel);
	    Point pos;
	    pos = fighter->UpdatePosition(pos, vel);
	    fighter->SetX(pos.x + fighter->GetX());
	    fighter->SetY(pos.y + fighter->GetY());
	    ///////////////////////////////////////
        
	    int action;
	    action = fighters[i]->Run();
	    fighters[i]->updateBoxes();
     
     
	    updateBodyCollision(i);
     
	    // n�r han har d�tt och animationen �r klar
	    // f�rsvinner han och hamnar i v�ntel�ge
	    if (fighters[i]->data.movement_state == M_DEAD) {
	      if (fighters[i]->anim[M_DEAD].End()) {
		fighters[i]->Reinit();
		// s�tt honoom i v�ntade state s� han kan spanas
		fighters[i]->data.game_state = PG_WAITING;
            
	      }
	    }
	    // kolla om n�gon har vunnit
     
     
	    // kolla om man sl�r n�gon annan
	    if (action == 1) {
	      for (int j = 0; j < OBJ_MAX; j++) {
		if (fighters[j] != NULL && fighters[j] != fighters[i] && 
		    fighters[j]->isReady() == true) {
		  Fighter *enemy = fighters[i];
		  Fighter *victim = fighters[j];
		  Interaction(enemy, victim);
             
		}
            
        
	      }
	    }
     
	  }
    
     
      }
  }
     
}


bool Server::CollideHit(Fighter *hitfighter, Fighter *fighter)
{
  return hitfighter->data.hitbox.Collide(fighter->data.bodybox);
     
}
bool Server::CollideKick(Fighter *hitfighter, Fighter *fighter)
{
  return hitfighter->data.kickbox.Collide(fighter->data.bodybox);
     
}


/////////////////////////////////////////////////////////////////////
/// returns true if there is some fighter waiting to be spawned
/////////////////////////////////////////////////////////////////////
bool Server::WaitingFighter()
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	if ( fighters[i]->data.game_state == PG_WAITING)
	  return true;           
      }
  }
  return false;
}
///////////////////////////////////////////////////////////////////// 
/// a message to spawn a fighter in server
/////////////////////////////////////////////////////////////////////
void Server::SpawnFighter(int time, Point pos)
{
  con->printf("SPAAAAAAAAAAWWN\n");
  // spawn the first waiting fighter
     
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	if ( fighters[i]->data.game_state == PG_WAITING) {
	  fighters[i]->data.game_state = PG_SPAWN;
	  fighters[i]->data.spawn_timer = time;
	  fighters[i]->SetX(pos.x);
	  con->printf("his x pos is %d\n", pos.x);
	  fighters[i]->SetY(pos.y);
	}
      }
  }
}
/////////////////////////////////////////////////////////////////////
/// checks if fighter has won.. in that case he sets his state to winning
/// When the winning animation is finnished the function returns true
/// else false
/////////////////////////////////////////////////////////////////////
bool Server::FighterWins(int points_to_win)
{
  for (int i = 0; i < OBJ_MAX; i++) {
    // en bot kan inte vinna
    if (fighters[i] && fighters[i]->data.ai == false && fighters[i]->isReady() )
      {
	if (fighters[i]->data.points >= points_to_win) {
	  fighters[i]->data.movement_state = M_WIN;
	  con->printf("maybe error when fighter won.. points is %d >= %d\n", fighters[i]->data.points, points_to_win);
	}
	
          
	// om han vinner och animationen �r avslutad returnera true
	if (fighters[i]->data.movement_state == M_WIN) {
	  if (fighters[i]->anim[M_WIN].End()) {
	    return true;    
	  }
	}
          
      }
  }
  return false;
}

/////////////////////////////////////////////////////////////////////
/// Find out if this fighter is interacting with another and do the
/// correct state-changes and other
/////////////////////////////////////////////////////////////////////
void Server::Interaction(Fighter *enemy, Fighter *victim)
{
  Movement_State enemy_state = enemy->data.movement_state;
  Movement_State victim_state = victim->data.movement_state;
  int energy = 0;
  int enemy_points = 0;
  int victim_points = 0;
             
  const Movement_State org_victim_state = victim->data.movement_state;
             
             
  // kolla om ett slaget eller en spark tr�ffar (reglerna �r samma sen)
  // eller om det �r ett kast
  if (isHit(enemy_state) &&  enemy->data.hitbox.Collide(victim->data.bodybox) ||
      isKick(enemy_state) &&  enemy->data.kickbox.Collide(victim->data.bodybox) ||
      isThrow(enemy_state) &&  enemy->data.throwbox.Collide(victim->data.bodybox)) {
    Direction_State victimdir_temp;
    // kolla vad victim hamnar i f�r ny state
    victim_state = FightingRulesVictim(victim->data.movement_state, enemy_state);
    // om victim har blivit tr�ffad
    if (victim_state != M_NONE) {
                  
      // kolla om victim blockerar
      Movement_State temp = FightingRulesBlock(victim_state, org_victim_state, 
					       enemy_state);
      // om det blev en block
      if (temp != M_NONE) {
	victim_state = temp;
	victim_points = FightingRulesPointsVictim(victim_state);
                        
      }
      // annars dra av energy fr�n victim
      else {
	energy = FightingRulesEnergy(enemy_state, victim_state);
	enemy_points = FightingRulesPointsEnemy(enemy_state,victim_state);
                     
      }
      // kolla om han blir slagen i ryggen
                   
      if ( enemy->directionSign() == victim->directionSign()) {
	victim_state = fightingBackRules(victim_state);
      }
      // kolla om victim ska byta h�ll
      victimdir_temp = FightingRulesDir(victim_state, victim->data.direction_state,
					enemy->data.direction_state);
                                    
      // kanske �ndrar state p� enemy beroende p� vilken state victim hamna i
      enemy_state = FightingRulesEnemy(enemy_state);
                   
                   
      //------------------------------------------------
      // tilldela slutligen de nya states
      victim->data.movement_state = victim_state;
      victim->data.direction_state = victimdir_temp;
      victim->data.energy -= energy;
                   
      enemy->data.movement_state = enemy_state;
                   
                   
      //------------------------------------------------
      // kolla om victim dog o l�gg till lite po�ng i s� fall
      if (victim->data.energy <= 0) {
	victim->data.movement_state = M_DEAD;
	// ge enemy points o en kill
	enemy_points += 100;
	enemy->data.kills++;
      }
      //------------------------------------------------
      // l�gg till po�ng.. men bara om inte en bot var inblandad
      if (enemy->data.ai == false && victim->data.ai == false) {
                    
	victim->data.points += victim_points;
	enemy->data.points += enemy_points;
      }
                   
      // kolla hur l�ngt l�ngt han ska flyga
      Move_Data md;
      md = FightingRulesMove(victim_state);
      // om victim ska r�ra sig �t n�t h�ll
      if (md.length != -1) {
	// s� att han r�r sig �t r�tt h�ll
	int dir = enemy->directionSign();
	victim->data.x_move.init(victim->GetX(), md.length * dir, md.speed);   
	// NETWORK ENHANCE
	// l�t clienter sj�lva uppdatera x... ta bort om deblir konstigt
	// smoothar allt   
	// nedan skickar allts� information om move till klient
	victim->data.shared_move_counter++;
	victim->data.move_length = md.length * dir;
	victim->data.move_speed = md.speed;           
      }
    }
  }

}


