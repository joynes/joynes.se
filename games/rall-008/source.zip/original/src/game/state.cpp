/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <fighter/fighter.h>


// Some of the states will only last until the animation is over
// or the jump or movement is finnished. That is done here..
Point Fighter::UpdateStates()
{
   Point p;    
   Movement_State state = data.movement_state; 
        
 
  if (state == M_HIT) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
    }
   
   } 
   if (state == M_HIT_CROUCH) {
     			  
     if (anim[state].End()) {
     	state = M_CROUCH;	
    }
   
   } 
   if (state == M_KICK) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
    }
   
   } 
   if (state == M_KICK_CROUCH) {
     			  
     if (anim[state].End()) {
     	state = M_CROUCH;	
    }
   
   } 
   
   if (state == M_GRAB) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
     	con->printf("ending grab\n");
	}
   
   } 
   if (state == M_THROW) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
     	con->printf("ending throw\n");
	}
   
   } 
   if (state == M_RAISE_FRONT) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
     	con->printf("ending throw\n");
	}
   
   } 
    if (state == M_RAISE_BACK) {
     			  
     if (anim[state].End()) {
     	state = M_STAND;	
     	con->printf("ending throw\n");
	}
   
   } 
   
   
   
   // avsluta ett hopp-slag:
   // om slaget �r utf�rt.. �terg� till hoppet
   // om hoppet �r utf�rt innan slaget �r klart s� g� till stand	
   if (state == M_HIT_JUMP || state == M_HIT_JUMP_FORWARD ||
       state == M_KICK_JUMP || state == M_KICK_JUMP_FORWARD) {
     			  
     if (anim[state].End()) {
     	state = M_JUMP_UP;	
  	 }
  	 if (data.jump_data.check()) {
   	    //con->printf("ending jump\n");
        state = M_STAND; 
            
       	} 
   
   } 
   
   // check if jump is finnsihed
  if (state == M_JUMP_UP || state == M_JUMP_FORWARD || state == M_BLOCK_JUMP) {
  	if (data.jump_data.check()) {
   	        state = M_STAND; 
            
       	} 
  }
  // wait until jump is finnished
  if (state == M_BEAT_THROW) {
     			  
     if (data.jump_data.check()) {
   	        state = M_RAISE_FRONT; 
       	} 
   } 
  
  // all states that finnished when the move() is finnished
  if (state == M_BEAT_BODY || state == M_BEAT_BODY_BACK ||
      state == M_BEAT_LEGS ||
      state == M_HIT_WALK || state == M_KICK_WALK) {
   if (data.x_move.End()) {
          state = M_STAND;
       }
  }
  // block -states that finnished when move is finnished
  if (state == M_BLOCK_STAND_HIT) {
   if (data.x_move.End()) {
          state = M_BLOCK_STAND;
       }
  }
  if (state == M_BLOCK_CROUCH_HIT) {
   if (data.x_move.End()) {
          state = M_BLOCK_CROUCH;
       }
  }
  
  if (state == M_BLOCK_JUMP_HIT) {
   if (data.x_move.End()) {
      //�terg� till hoppet
      state = M_JUMP_UP;
   }
   // �r hoppet klart?
   if (data.jump_data.check()) {
          state = M_STAND;
     }
  }
  
  
  if (state == M_BEAT_CROUCH) {
   if (data.x_move.End()) {
        // �terg� till hoppet
          state = M_CROUCH;
       }
    // �r hoppet klart?
   
   if (data.jump_data.check()) {
          state = M_STAND;
     }
  }
  
  // depends on what is first finnished
  // if jump is finnished
  if (state == M_BEAT_JUMP) {
   if (data.x_move.End()) {
      // �terg� till hoppet
        state = M_RAISE_BACK;
   }
     // �r hoppet klart?
   if (data.jump_data.check()) {
          state = M_RAISE_BACK;
     }
 }
 
   
  data.movement_state = state;		    
  return p;
}

// k�rs av b�de client o server f�r x,y f�rflyttningar
Velocity Fighter::UpdateVelocity(Movement_State state, Direction_State dir, Velocity vel)
{
   if (state == M_WALK) {
      vel.x = ((dir == D_RIGHT)? 4: -4);
       //con->printf("vel is %d\n", vel.x);
    } 
    
    if (state == M_JUMP_UP || state == M_JUMP_FORWARD || 
        state == M_HIT_JUMP || state == M_HIT_JUMP_FORWARD ||
        state == M_KICK_JUMP || state == M_KICK_JUMP_FORWARD ||
        state == M_BEAT_JUMP || state == M_BLOCK_JUMP ||
        state == M_BLOCK_JUMP_HIT
        ) {
       
       
       int jump_dir = (state == M_JUMP_UP)? 0:1; 
       if (jump_dir == 1) jump_dir = ((dir == D_RIGHT)? 5: -5);
	     			
	physics.use = false;
	vel = jump(data.jump_data, 5, jump_dir); 
  	
    }
    // beat throw blir automatiskt samma som ett jump_forward.. vilket
    // �r �nskv�rt
    else if (state == M_BEAT_THROW) {
         int jump_dir = 6;
         jump_dir = (dir == D_RIGHT)? jump_dir * 1: jump_dir * -1;
         //con->printf("jump_ddir is %d, dir is %d\n", jump_dir, dir);
         
         physics.use = false;
	     vel = jump(data.jump_data, 5, jump_dir, 14, 2);
    }
    else {
         // om du inte hoppar ska fysik anv�ndas
         physics.use = true;
         SetY(data.initial_pos.y);
         
         // resetta hoppet
         data.jump_data.reset();
         // nollst�ll positionen
    }
    // alla states som k�r move
    if (state == M_BEAT_BODY || state == M_BEAT_BODY_BACK || state == M_BEAT_JUMP ||
        state == M_BEAT_CROUCH || state == M_BEAT_LEGS ||
        state == M_BLOCK_STAND_HIT || state == M_BLOCK_CROUCH_HIT ||
        state == M_BLOCK_JUMP_HIT ||
        state == M_HIT_WALK || state == M_KICK_WALK 
       ) {
       vel.x = data.x_move.move(); 
               
    } 
        
    return vel;
}

// s�tter en ny position f�r x och returnerar den
Point Fighter::UpdatePosition(Point pos, Velocity vel) {
   
    pos.x += vel.x;
	pos.y += vel.y;
	
    return pos;
}
      	  
      	  
