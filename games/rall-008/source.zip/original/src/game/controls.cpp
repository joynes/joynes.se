/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <fighter/fighter.h>

int rules_control_state[2][3] =  
{
//			state0	state1	state2
/*no push*/{0,		2,		0},
/*push*/   {1, 		2, 		2}
};

/////////////////////////////////////////////////////////////////////
/// mapps control-press to state
/////////////////////////////////////////////////////////////////////

void Fighter::UpdateControls()
{
  // kolla vilken state du �r i
  // om du har tryckt p� n�gon knapp
  int temp = data.movement_state;
  
  data.movement_state = movementRules(data.movement_state, push_movement);// movement_rules[push_movement][data.movement_state]; 
  
  
  // �ndra kanske direction
  Direction_State DS_tmp;
  //if ((DS_tmp = direction_rules[push_movement][data.movement_state]) != D_NONE) {
  if ((DS_tmp = directionRules(data.movement_state, push_movement)) != D_NONE) {     
     data.direction_state = DS_tmp;
  }
  
  
  // vissa states innefattar r�relser med hj�lp av move()..vilka d� m�ste 
  // initieras:
  if (temp != data.movement_state) {
    // vid ett slag ska han r�ra sig fram�t
    if (data.movement_state == M_HIT_WALK) {
       data.x_move.init(GetX(), 50*directionSign(), 1);
    }
    if (data.movement_state == M_KICK_WALK) {
       data.x_move.init(GetX(), 50*directionSign(), 1);
    }
 }
  
}

static int test = 0;    
static int test2 = 0; 
static bool test3 = 0; 
    
void Fighter::SetControlsNet() {

      

      if (key[control.a])
      	 control_net.a = true;
     
      else
      	  control_net.a = false;
      	  
   	  if (key[control.b])
      	 control_net.b = true;
     
      else
      	  control_net.b = false;
      	  
   	  if (key[control.c])
      	 control_net.c = true;
     
      else
      	  control_net.c = false;
      	  
   	  if (key[control.d]) {
      	 control_net.d = true;
       }
     
      else
      	  control_net.d = false;
      	  
      if (key[control.down])
      	 control_net.down = true;
      else  {
      	 control_net.down = false;
      }
  
      if (key[control.right]) {
      	 control_net.right = true;
      }
      else 
      	 control_net.right = false;	 
  
      if (key[control.left])
      	 control_net.left = true;
      else 
      	 control_net.left = false;
      	 
      if (key[control.up]) {
      	 control_net.up = true;
      	 
        }
      else 
      	 control_net.up = false;
      	 
	 /*
	 if (key[KEY_T])
         test = 1;
     if (test) { control_net.b = true;  };
        
     
     if (key[KEY_Y])
         test2 = 1;
     if (test2) { control_net.down = true; };
     
     
     
     if (key[KEY_Y])
         test2 = 1;
     if (test2) {test3 = !test3;
                if (test3)
                   control_net.up = 1;
                 con->printf("up %d", control_net.up);}
                 */
                 
                 
}
/////////////////////////////////////////////////////////////////////
/// choose one button
/////////////////////////////////////////////////////////////////////
void Fighter::GetControls()
{
    push_movement = C_NONE;
    
       // knappar som man inte ska kunna h�lla in s�d�r
    if ((control_state.a = rules_control_state[abs(control_net.a)][control_state.a])
    	== 1) push_movement = C_A;
   	else if (control_net.b) {
       push_movement = C_B; 
       }
   	else if ((control_state.c = rules_control_state[abs(control_net.c)][control_state.c])
    	== 1) push_movement = C_C;
   	else if ((control_state.d = rules_control_state[abs(control_net.d)][control_state.d])
    	== 1) {push_movement = C_D;
               }
  
    else if (control_net.down)
       push_movement = C_DOWN; 
        // knappar som man inte ska kunna h�lla in s�d�r
    else if ((control_state.up = rules_control_state[abs(control_net.up)][control_state.up])
    	== 1) push_movement = C_UP;
	      
    else if (control_net.left) {
       push_movement = C_LEFT;
       }
    else if (control_net.right)
       push_movement = C_RIGHT;
    
  
} 

void Fighter::SetKeyboard
(int left, int right, int up, int down, int a, int b, int c, int d)
{
  control.left = left;   
  control.right = right;
  control.up = up;
  control.down = down;
  control.a = a;
  control.b = b;
  control.c = c;
  control.d = d;
  input_type = I_KEYBOARD;
}  

void Fighter::SetBot()
{
   input_type = I_BOT;
}  		      
