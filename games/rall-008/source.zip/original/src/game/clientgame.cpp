#include <network\client.h>
#include <vector>

void Client::Init(FileData _filedata, Sound *sound, Music *music, Stage *stage)
{
  this->filedata = _filedata;
  this->sound = sound;
  this->music = music;
  this->stage = stage;
  
  music_playing = false;
}


void Client::update()
{
  
   int active_players = 0;
   // k�r ig�ng musiken om fler �n 1 spelare
   
   if (( active_players = ActivePlayers()) > 1 && music_playing == false) {
        music_playing = true;
        //---------------------------------------------------------
       /// look after mp3-files from music-dir and choose a random one
       
       {
          struct al_ffblk info;
          vector<string> file_names;
          if (al_findfirst("music/*.mp3", &info, FA_ALL) != 0) {
             con->printf("found no mp3-files\n");
          }
          else {
          do {
              file_names.push_back(info.name);
          } while (al_findnext(&info) == 0);
          
          al_findclose(&info);
          
          for (int i = 0; i < file_names.size(); i++) {
              con->printf("found song %s\n", file_names[i].c_str());
              
           }
           int choose = rand() % file_names.size();
           string path = "music/" + file_names[choose];
           con->printf("Random choose of %s\n", path.c_str());
           music->Load((char *)path.c_str(), true, filedata.MusicVolume); 
            
          }
      }
      //---------------------------------------------------------

      
   }
  
  playSound(sound);                   
                     
  // update objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
	// update objects (actually, update only 'our' object by applying arrow key movement)
	// and check for node events
	fighters[i]->update();
      
      
	// NETWORK ENHANCE
	// l�t clienter sj�lva uppdatera x... ta bort om deblir konstigt
	// smoothar allt 
	// if player is not playing.. do nothing more
	if (fighters[i]->isReady() == false) {
           // set the name of the owner, nessecarry for initiating the fighter                         
         setPlayerName(filedata.name);
	  // try to init an uninitiated fighter                        
	  Player_Game_State state = fighter->TryInit();
	  // if he was initiated and he is the owner. then set keyb
	  if (state == PG_WAITING && fighter->local == true) {
            fighter->SetKeyboard(KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN, KEY_E, KEY_S, KEY_A, KEY_D);        
	  }
	}
	else 
	  {
	    // if it is our player   
	    // send our control to the server
	    if (fighter->local == true) {
	      fighter->SendControl();
	        // update the camera
	      stage->UpdateCamera(fighter->GetX());
	    }
	    // updates position of character only for y (jump)
           
	    Velocity vel;
	    vel = fighter->UpdateVelocity(fighter->data.movement_state, fighter->data.direction_state, vel);
	    Point pos;
	    pos = fighter->UpdatePosition(pos, vel);
	    // NETWORK ENHANCE
	    // l�t clienter sj�lva uppdatera x... ta bort om deblir konstigt
	    // smoothar allt
	    //SetX(pos.x + GetX());
	    fighter->SetY(pos.y + fighter->GetY());
	    // uppdatera oss
	    fighters[i]->Run();
	    /////////////////////////////////////////////////////     
      
	  }
	// object wants to be deleted
	if (fighters[i]->data.deleteme)
	  {
	    sys_print("Client: deleting node in slot %d", i);
	    delete fighters[i];
	    fighters[i] = NULL;
	  }
      }
  }

}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// checks if fighter has won.. in that case he sets his state to winning
/// When the winning animation is finnished the function returns true
/// else false
/// </pre>
/////////////////////////////////////////////////////////////////////

bool Client::FighterWins()
{
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i] && fighters[i]->isReady())
      {
	// om han vinner och animationen �r avslutad returnera true
	if (fighters[i]->data.movement_state == M_WIN) {
	  if (fighters[i]->anim[M_WIN].End()) {
	    return true;    
	  }
	}
          
      }
  }
  return false;
}
/////////////////////////////////////////////////////////////////////
/// gets the x-position of the local fighter from client
/// if server we get a fixed pos
/////////////////////////////////////////////////////////////////////
int Client::GetLocalX()
{

  if (fighters[m_localnode] && fighters[m_localnode]->isReady()) {
    int x = fighters[m_localnode]->GetX();
    return x;
  }
  else
    return 0;
}

void Client::setGround(int ground)
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
	fighter->physics.ground = ground;
      }
  }
}

void Client::playSound(Sound *sound)
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
	Movement_State state = M_NONE;
	Movement_State old_state = M_NONE;
	int energy = 0;
	// om vi har hamnat i ny state
	if ((state = fighter->getNewState(old_state)) != M_NONE) {
	  // spela upp ljud
	  Sound_type snd = FightingRulesSound(state, old_state);
            
	  if (snd != S_NONE) {
	    sound->play(snd);
	  }
	}
	else if ((energy = fighter->getNewEnergy()) != 0) {
	  Sound_type snd = FightingRulesSoundEnergy(energy);
            
                
	  if (snd != S_NONE) {
	    sound->play(snd);
	  }
	}
            
               
      }
  }
}

int Client::ActivePlayers()
{
  int players = 0;
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	players++;
      }
  }
  return players;
}

//////////////////////////////////////////////////////////////////////////////
/// If player is outside the World-bound, the returned pos will be corrected
//////////////////////////////////////////////////////////////////////////////

int Client::worldCollision(int leftbound, int rightbound, int x)
{
    
  if (x > rightbound)
    x = rightbound;
      
  if (x < leftbound)
    x = leftbound;
   
  return x;
}

void Client::worldCollision(int length)
{
  // update the objects and their physics
  for (int i = 0; i < OBJ_MAX; i++) {
    if (fighters[i])
      {
	Fighter *fighter = fighters[i];
         
	fighter->SetX( worldCollision(30, length - 30, fighter->GetX()));
      }
  }
}


//////////////////////////////////////////////////////////////////////////////
/// Sets new positions of player i if player i collides with any other players
//////////////////////////////////////////////////////////////////////////////
void Client::updateBodyCollision(int i)
{
     
  // enkel kollision-detection med kropparna
  for (int j = 0; j < OBJ_MAX; j++) {
          
    Fighter *us = fighters[i];
    Fighter *enemy = fighters[j];
          
    if (enemy != NULL && enemy != us) {
	  
      // om fienden kolliderar med oss och om b�da har ett kolliderande
      // state
      if (us->data.bodybox.Collide(enemy->data.bodybox) && 
	  isCollide(us->data.movement_state)&& isCollide(enemy->data.movement_state)) {
	//con->printf("bodycoll\n");	
      	     
	// om fienden st�r till h�ger
	if (us->GetX() < enemy->GetX()) {
	  int new_x = enemy->data.bodybox.upper_left.x -  
	    max(us->GetX() - us->data.bodybox.upper_left.x,
    	        us->data.bodybox.lower_right.x - us->GetX());
	      		
	  us->SetX(new_x);
	}
	// om han st�r till v�nster
	else {
	  int new_x = enemy->data.bodybox.lower_right.x +  
	    max(us->GetX() - us->data.bodybox.upper_left.x,
		us->data.bodybox.lower_right.x - us->GetX());		
        	     
	  us->SetX(new_x);
	        
	}
            
      }
	  
    }
  } 				  
}

/////////////////////////////////////////////////////////////////////
/// sets the name of the client if it has not already been initiated
/////////////////////////////////////////////////////////////////////
void Client::setPlayerName(string fighter_name)
{
    if (fighters[m_localnode]) {
       if (fighters[m_localnode]->is_init == false) {
        con->printf("set name of player to %s\n",  fighter_name.c_str());
        strcpy(fighters[m_localnode]->data.name, fighter_name.c_str());
        }
    }
}

