/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// timer.cc

#define TIMER_BPS 1193181 // how often coiunter will be updated

#include <global/timer.h>

#include <stdio.h>
#include <stdarg.h>
#include <allegro.h>

// timer variable and function. The volatile keyword is needed for variables
// incremented in a timer (otherwise the program WILL crash). Likewise, for
// functions used for timing, the END_OF_FUNCTION() macro is essential too.
volatile int game_time = 0;

void Timer(void)
{
  game_time++;
}
END_OF_FUNCTION(Timer); // end Timer()

// in game-loop insert: frame_counter++

volatile unsigned int frame_counter, fps, update_counter, ups;

// frame rate function
void fps_proc()
{
  fps = frame_counter;
	frame_counter = 0;
  
	// hastighet av spelet (input o update/sec)
	ups = update_counter;
  update_counter = 0;
}
END_OF_FUNCTION(fps_proc);

void init_timer()
{ 
    // install the timer. We will use this to regulate game speed
  install_timer();	
  
  LOCK_VARIABLE(game_time);
  LOCK_FUNCTION((void*)Timer);
  install_int_ex(Timer, BPS_TO_TIMER(UPDATE_RATE));
    
  LOCK_VARIABLE(frame_counter);
  LOCK_VARIABLE(fps);
  LOCK_FUNCTION(fps_proc);
  
  LOCK_VARIABLE(update_counter);
  LOCK_VARIABLE(ups);
  
  if (install_int(fps_proc, 1000) != 0) {
    printf("exit due to no more timers\n");
    exit(1);
  }
    
}

timing::timing() {
  timer = 0;
  delay = 0;
}

int timing::Check() {
	if (timer >= delay ) {
      // nollst�ll timer
      timer = 0;
      return 1;
    }
  else 
  	timer++;
  
  return 0;
}  
// nollst�ll timer
void timing::reset()
{
   timer = 0;   
}

int If_timed(struct timing &tm) {
	if (tm.timer >= tm.delay ) {
      // nollst�ll timer
      tm.timer = 0;
      return 1;
    }
  else 
  	tm.timer++;
  
  return 0;
}  

// returns the nr of frames that input seconds will last
int sec_to_fps(int seconds)
{
    return seconds * UPDATE_RATE;
}

