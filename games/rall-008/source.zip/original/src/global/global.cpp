/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <global/global.h>
#include <stdio.h>
#include <global/timer.h>
#include <console/conalleg.h>

char *Part_Name[] = {"ARM UPPER RIGHT", "ARM LOWER RIGHT", "HAND RIGHT", "BODY", 
     		 "LEG UPPER RIGHT", "LEG LOWER RIGHT", "FOOT RIGHT", "HEAD",
     		 "LEG UPPER LEFT", "LEG LOWER LEFT", "FOOT LEFT", 
		 "ARM UPPER LEFT", "ARM LOWER LEFT", "HAND LEFT" 
		 };


//BITMAP *bitmapGLOBAL = NULL;

BITMAP *LoadBitmap(const char *path) 
{
   BITMAP *bitmap;
   if ((bitmap = load_bitmap(path, NULL))== NULL) {
    con->printf("couldnt load bimtap %s\n", path); 
   }
   return bitmap;
}

/////////////////////////////////////////////////////////////////////
/// checks if key is pressed and waits until the key is released 
/// if key is pressed true, else false, when holding key the
/// programmed is blocked
/////////////////////////////////////////////////////////////////////
//bool Key_block(int KEY) {
 bool Key(int KEY) {
     if (key[KEY]) {
        while (key[KEY]);
          return true;
     }
     return false;
}
// 60 = 1 sec
bool Delay(int nr) {
     if ((frame_counter % nr) == 0)
     	return true;
     else 
     	  return false;
}




/////////////////////////////////////////////////////////////////////
/// checks if key is pressed and returns true. If the same key is hold
/// it will return false until the key is released, otherwise true
/// ie returns true only once for a certain keypress (perhaps you dont
/// want to do an action several times, only once, ex create a file
///
///   doesnt work right now
/////////////////////////////////////////////////////////////////////
static int last_key;
static int key_state = 0;
bool Key_block(int KEY) {
     if (key_state == 0) {
        if (key[KEY]) {
	   last_key = KEY;
	   key_state = 1;
	  return true;
        }
	}
     if (key_state == 1) {
        if (keypressed()) {
 	   exit(1);
           return false;
	   }
	else {
 	   key_state = 0;
 	   return false;
       }
   }
    return false;
}

bool Network_add_player = false;
int Network_player_id = 0;
bool Network_player_is_us = false;

Point::Point(int x, int y) { this->x = x; this->y = y; };

Point Point::operator+(Point p) {
             Point f;
             f.x = x + p.x;
             f.y = y + p.y;
             return f;
       }
             

Point::Point() { x  = 0; y = 0;};

int flip_rotation(int rotation)
{
     return 128 - (rotation - 128);		    
}

void PrintTable(BITMAP *bitmap, string menu1[], string menu2[], int color1, int color2, int x, int y, int distance_x,
     			 int distance_y, int size )
{
  int color_left = makecol(255,255,255);
  int x_left = 5;
  int y_left = SCREEN_H-80;
  
  int color_right = makecol(255,255,100);
  int x_right = 120;
  int y_right = y_left;
  
  for (int i = 0; i < size; i++) {
      textprintf_ex(bitmap,font,x             ,y + i*distance_y, color1, -1, menu1[i].c_str());
      textprintf_ex(bitmap,font,x + distance_x,y + i*distance_y, color2, -1, menu2[i].c_str());  
  }   
 			 
}

void BoundingBox::Draw(BITMAP *bitmap)
{
  rect(bitmap, upper_left.x, upper_left.y, lower_right.x, lower_right.y, makecol(0,0,0)); 
}

// my box, opponent box
bool BoundingBox::Collide(BoundingBox b) {
 	int x0, x1, y0, y1;
 	x0 = upper_left.x;
 	x1 = lower_right.x;
 	y0 = upper_left.y;
 	y1 = lower_right.y;
 	
 	int x0p, x1p, y0p, y1p;
 	
 	x0p = b.upper_left.x;
 	x1p = b.lower_right.x;
 	y0p = b.upper_left.y;
 	y1p = b.lower_right.y;
   	
   	if (
    	((x1p > x0) && (x0p < x1)) &&
         ((y1p > y0) && (y0p < y1))					
         ) {
	     return true;  
	     }	 
    else
    	return false;
}  

BoundingBox::BoundingBox(int x1, int y1, int x2, int y2)
{
  upper_left.x = x1;
  upper_left.y = y1;
  lower_right.x = x2;
  lower_right.y = y2;
}

void BoundingBox::Set(int x1, int y1, int x2, int y2)
{
  upper_left.x = x1;
  upper_left.y = y1;
  lower_right.x = x2;
  lower_right.y = y2;
}



KeyPress::KeyPress()
{
    state = RELEASE;
    our_key = delay.delay = 0;                  
}

void KeyPress::init(int our_key, int speed)
{
    this->our_key = our_key;
    delay.delay = speed; 
}

// returns true if a keypress has been made and when holding down the key
// it returns true periodically with a delay 
bool KeyPress::press() {
    
    int ret = false;
    if (state == RELEASE) {
        if (key[our_key]) {
    	   state = HOLD;
    	   ret = true;
    	   // nollst�ll timer s� att den inte hoppar tv� g�gner
    	   delay.reset();
        }
	}
	// if button is hold
    else if (state == HOLD) {
          // button is hold.. return true periodically
         if (key[our_key]) {
           if (delay.Check()) {
              ret = true;
           }
        }
          // button is released
        else {
             state = RELEASE;
        }
           
    }    
    
    return ret;
}


void alfont_text(BITMAP *bmp, ALFONT_FONT *f, const char *s, int x, int y, int color, bool aa, int shadow)
{
        if (aa) {
           if (shadow)
             alfont_textout_aa(bmp, f, s, x + shadow, y + shadow, makecol(0,0,0));
           alfont_textout_aa(bmp, f, s, x, y, color);
           con->printf("aa\n");
        }
        else {
           if (shadow)
             alfont_textout_aa(bmp, f, s, x + shadow, y + shadow, makecol(0,0,0)); 
           alfont_textout(bmp, f, s, x, y, color);
           
        }
}

void alfont_text_centre(BITMAP *bmp, ALFONT_FONT *f, const char *s, int x, int y, int color, bool aa, int shadow)
{
        if (aa) {
           if (shadow)
             alfont_textout_centre_aa(bmp, f, s, x + shadow, y + shadow, makecol(0,0,0));
           alfont_textout_centre_aa(bmp, f, s, x, y, color); 
        }
        else {
           if (shadow)
             alfont_textout_centre(bmp, f, s, x + shadow, y + shadow, makecol(0,0,0));
           alfont_textout_centre(bmp, f, s, x, y, color);                 
        }
}
