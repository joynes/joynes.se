/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <fighter/fighter.h>

Physics::Physics()
{
   Part *ground_part = 0;
   // the change in y depending on physics
   y_extra = 0;
       
   ground = 0;	
   use = true;	  
}

void Physics::SetPart(int id, Part &p)
{
    list <Part *> list_part;
    p.tree_to_list(&list_part);
    
    list<Part *>::iterator h;
    Part *foot = 0;
    // hitta fot
    for(h=list_part.begin();h != list_part.end(); h++) {
      // some part is on the ground
      foot = (*h);
      
      if (foot->id == id) {
      	 ground_part = foot;
      	 break;
   	 }
   }
   if (foot == 0) {
   	 con->printf("error finding ground_part\n");
      return;
     }
}


void Physics::update()
{  
   // om funktionen �r avst�ngd
  if (use != true) {
     y_extra = 0;
     return;   	
     }	      
     		      
  int y_jump;
  
  // om avst�nd �r l�ngt ska man n�rma sig ground fortare
  if (  abs(ground_part->pos.y - ground ) > 5) y_jump = 5;
  else y_jump = 1;
     
  //y_extra = 0;
     
     
  for (int i = 0; i < y_jump;i++) { 	
      if (ground_part->pos.y + y_extra == ground)
	break;
	
    	// no part was on the ground
    	if (ground_part->pos.y + y_extra > ground)
      	   y_extra--;
    	else
      	   y_extra++; 
  }
    	    

}

void Part::physic(int ground)
{
    list <Part *> list_part;
    tree_to_list(&list_part);
    
    list<Part *>::iterator h;
    Part *foot = 0;
    // hitta fot
    for(h=list_part.begin();h != list_part.end(); h++) {
      // some part is on the ground
      foot = (*h);
      
      if (foot->id == P_FOOT_LEFT)
      	 break; // || p->id == P_FOOT_RIGHT) {
      
  }
  if (foot == 0) {
     con->printf("error finding foot\n");
     return;
     }
     
  int y_jump;
  
  // om avst�nd �r l�ngt ska man n�rma sig ground fortare
  if (  abs(foot->pos.y - ground ) > 5) y_jump = 5;
  else y_jump = 1;
     
  for (int i = 0; i < y_jump;i++) { 	
      if (foot->pos.y == ground)
	return;
	
    	// no part was on the ground
    	if (foot->pos.y > ground)
      	   pos.y--;
    	else
      	    pos.y++; 
  }
  
}

