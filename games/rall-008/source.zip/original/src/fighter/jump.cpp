/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <fighter/fighter.h>

// h�gre JUMP_SKIP ger snabbare fart upp och ner i ett hopp
// jumpdec ska va en multipel av jump_skip (ju h�gre dessto snabbare
// men ryckigare)
int JUMP_SKIP;
int JUMP_DEC;

Jump_data::Jump_data()
{
    
     reset();
}

void Jump_data::reset()
{
     state = J_START;
 
     counter = JUMP_SKIP;
     update = 0;
     start_dir = 0;    
     end = 0;
     
     restarts_jump = 0;		       
}


// kolla om ett hopp �r klart
bool Jump_data::check()
{
    if (state == J_END) {
 	    // startar om hoppet n�stan g�ng
        state = J_START; 
        return true;
    }
    return false;    
}    

// �ndrar positioner direkt

int tesetdel = 0;

/////////////////////////////////////////////////////////////////////
/// <pre>
/// speed_up: how often to increase height with JUMP_DEC
/// speed_right: direction and speed of jump (ie. -3, 0 , 5) in x-axis
/// JUMP_SKIP: gives higher velocity up and down in a jump
/// JUMP_DEC: must be a multiple of  JUMP_SKIP (the higher the faster)
/// </pre>
/////////////////////////////////////////////////////////////////////
 
Velocity Fighter::jump(Jump_data &j, int speed_up, int speed_right, 
         int _JUMP_SKIP, int _JUMP_DEC)
{
   Velocity vel;
   
   if (j.state == J_START) {
      JUMP_SKIP = _JUMP_SKIP;
      JUMP_DEC = _JUMP_DEC;	       
      	       
      j.state = J_UP;
      j.counter = JUMP_SKIP;
      j.update = 0;
      j.start_dir = speed_right;
      
      //�terst�ll y-pos
      //int newy = phys.ground;// - (abs(GetY() - phys.ground_part->pos.y));
      //SetY(newy);
      //con->printf("ground %d\n", newy);
      
    }  
    
    else if(j.state == J_UP) {
         if (j.counter == 0) {
      	  j.state = J_DOWN;
      	  //con->printf("up");
	  }
      //y-=j.counter;
      //x += j.start_dir;
      vel.y = -j.counter;
      vel.x = j.start_dir;
      //vel.y = -1;
      //con->printf("up j.counter %d\n", j.counter);
      
      j.update++;
      if ((j.update % speed_up) == 0) {
      	j.counter-=JUMP_DEC;
   	  } 	  
      if (j.counter == 0) {
	      j.update = 0;
	  }  
      
    }
    
  
    if(j.state == J_DOWN) {
      //con->printf("down");
      
      if ((j.update % speed_up) == 0) {
               	j.counter+=JUMP_DEC;
        	} 
		 
      if (j.counter == (JUMP_SKIP + JUMP_DEC)) {
      	   	      
      //if (phys.ground_part->pos.y >= phys.ground) {
          //y = phys.ground - (abs(y - phys.ground_part->pos.y));
      	  
      	  //phys.use = true;
          j.state = J_END;
          // nu kan du g�ra en restart_jump igen
          j.restarts_jump = 0;
	  }
      else { 
	       	   
        	  j.update++;
        	  
        	  vel.y = j.counter;
		  vel.x = j.start_dir;
		 // vel.y = 1;
		  
        	  //y+=j.counter;
        	  //x += j.start_dir;
        	  
       } 	  
    } 
    //con->printf("END j.counter %d (JUMP_SKIP + JUMP_DEC) %d\n", j.counter, (JUMP_SKIP + JUMP_DEC));
    //con->printf("vel %d\n", vel.y);	  

    return vel;
}    

/////////////////////////////////////////////////////////////////////
/// <pre>
/// can only make "one" new jump from a current jump
/// should only be used once from a current jump and can be used for
/// being hit in air 
/// </pre>
/////////////////////////////////////////////////////////////////////
void Fighter::restart_jump(Jump_data &j, int speed_up, int speed_right, int &x, int &y, Physics phys)
{
	if (j.restarts_jump == 0) {
		j.state = J_START;
		j.restarts_jump = 1;
	}
 	jump(j, speed_up, speed_right, 500);		
} 
