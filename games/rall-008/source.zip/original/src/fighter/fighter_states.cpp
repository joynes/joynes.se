/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <fighter/fighter_states.h>
#include <allegro.h>
#include <console/conalleg.h>
#include <fighter/fighter.h>

char *movement_state_name[] =  {
     "STAND", "WALK", "HIT", "HIT_CROUCH", "HIT_JUMP", "HIT_JUMP_FORWARD", 
     "HIT_WALK", "KICK" , "KICK_CROUCH", "KICK_JUMP", "KICK_JUMP_FORWARD", 
     "KICK_WALK", "CROUCH", "JUMP_UP", "JUMP_FORWARD", "BEAT_BODY", "BEAT_JUMP",
     "BEAT_LEGS", "BEAT_CROUCH", "DEAD", "BEAT_BODY_BACK", "BLOCK_STAND", 
     "BLOCK_CROUCH", "BLOCK_JUMP", "BLOCK_STAND_HIT", "BLOCK_CROUCH_HIT", 
     "BLOCK_JUMP_HIT", "GRAB", "THROW", "BEAT_THROW", "RAISE_FRONT", 
     "RAISE_BACK", "WIN"};
     
char *direction_state_name[] =  {"D_NONE", "D_LEFT", "D_RIGHT"};

char *player_game_state_name[] = {"INIT", "PG_WAITING", "PG_SPAWN", "PG_PLAYING"};

Direction_State directionRules(Movement_State state, Movement_Control_types control)
{
  Direction_State dir = D_NONE;              
  
  if (state == M_WALK) {
     if      (control == C_LEFT)
        dir = D_LEFT;
     else if (control == C_RIGHT)
        dir = D_RIGHT;
  }                             
  return dir;
}

Movement_State movementRules(Movement_State state, Movement_Control_types control)
{
  if (state == M_STAND) {
            
     if      (control == C_UP)
        state = M_JUMP_UP;
     else if (control == C_DOWN)
        state = M_CROUCH;
     else if (control == C_LEFT)
        state = M_WALK;
     else if (control == C_RIGHT)
        state = M_WALK;
     else if (control == C_A)
        state = M_HIT;
     else if (control == C_B)
        state = M_BLOCK_STAND;
     else if (control == C_C)
        state = M_GRAB;
     else if (control == C_D)
        state = M_KICK;
     
        
  }
  else if (state == M_WALK) {
     if      (control == C_NONE)
        state = M_STAND;       
     else if (control == C_UP)
        state = M_JUMP_FORWARD;
     else if (control == C_DOWN)
        state = M_CROUCH;
     else if (control == C_A) 
        state = M_HIT_WALK;
     else if (control == C_B)
        state = M_BLOCK_STAND;
     else if (control == C_C)
        state = M_GRAB;
     else if (control == C_D)
        state = M_KICK_WALK;
  }

  
  else if (state == M_CROUCH) {
     if      (control == C_NONE)
        state = M_STAND;       
     else if (control == C_UP)
        state = M_STAND;
     else if (control == C_LEFT)
        state = M_WALK;
     else if (control == C_RIGHT)
        state = M_WALK;
     else if (control == C_A)
        state = M_HIT_CROUCH;
     else if (control == C_B)
        state = M_BLOCK_CROUCH;
     else if (control == C_D)
        state = M_KICK_CROUCH;
  }
  
  else if (state == M_JUMP_UP) {
     if (control == C_A)
        state = M_HIT_JUMP;
     else if (control == C_B)
        state = M_BLOCK_JUMP;
     else if (control == C_D)
        state = M_KICK_JUMP;
  }
  
  
  else if (state == M_JUMP_FORWARD) {
     if (control == C_A)
        state = M_HIT_JUMP_FORWARD;
     else if (control == C_B)
        state = M_BLOCK_JUMP;
     else if (control == C_D)
        state = M_KICK_JUMP;
  }
  
  else if (state == M_BLOCK_STAND) {
     if (control != C_B)
        state = M_STAND;
  }
  else if (state == M_BLOCK_CROUCH) {
     if (control != C_B)
        state = M_CROUCH;
  }
  
          
   return state;    
       
}


/////////////////////////////////////////////////////////////////////
/// if fighter was hit from backside
/////////////////////////////////////////////////////////////////////
Movement_State fightingBackRules(Movement_State state)
{
  if (state == M_BEAT_BODY) {
     state = M_BEAT_BODY_BACK;
  }  
  return state;      
}


/////////////////////////////////////////////////////////////////////
/// <pre>
/// Assumes that victim has been hit by enemy (with collision detection)
/// returns the new state of the victim or M_NONE
/// if he was not hit
/// </pre>
/////////////////////////////////////////////////////////////////////
Movement_State FightingRulesVictim(Movement_State victim, Movement_State enemy)
{
  Movement_State state = M_NONE;
  
  //------------------------------------------------
   // om motst�ndaren utf�r ett kast har vi andra regler
  if (isThrow(enemy)) {
     // if victim is standing or crouching
     if (isStand(victim) || isCrouch(victim)) {
        state = M_BEAT_THROW;
        
      }
     
  }
  //------------------------------------------------
  
    // slag eller spark
  else {
  
      // if victim is standing
      if (isStand(victim)) {
        // enemy is standing or jumping
        if (isStand(enemy) || isJump(enemy) ) {
            state = M_BEAT_BODY;
        }
        
        // hitter is crouching
        if (isCrouch(enemy)) {
           // if crouching from hit
          state = M_BEAT_LEGS;
        }
        
     }
     // if victim is crouching
     else if (isCrouch(victim)) {
          // hitter crouch 
          if (isCrouch(enemy)) {
             state = M_BEAT_CROUCH;
          }
          // hitter kicks
          if (enemy == M_KICK || enemy == M_KICK_WALK) {
             state = M_BEAT_CROUCH;
          }
          // if hitter is jumping he always hits
          else if (isJump(enemy)) {
             state = M_BEAT_CROUCH;
          }
     }
     // if victim is jumping
     else if (isJump(victim)) {
         // always get hit
        state = M_BEAT_JUMP;
     }
 }
  return state;
}

bool isHit(Movement_State state)
{
     if (state == M_HIT || state == M_HIT_WALK || state == M_HIT_CROUCH || 
         state == M_HIT_JUMP || state == M_HIT_JUMP_FORWARD
         ) {
       return true;    
     }
     return false;
}

bool isKick(Movement_State state)
{
     if (state == M_KICK || state == M_KICK_WALK || state == M_KICK_CROUCH || 
         state == M_KICK_JUMP || state == M_KICK_JUMP_FORWARD
         ) {
       return true;    
     }
     return false;
}

bool isThrow(Movement_State state)
{
     if (state == M_GRAB) {
       return true;    
     }
     return false;
}

bool isStand(Movement_State state)
{
     if (state == M_STAND || state == M_WALK  || 
         state == M_HIT || state == M_HIT_WALK ||
         state == M_KICK || state == M_KICK_WALK ||
         state == M_BLOCK_STAND || state == M_GRAB) {
     return true;    
     }
     return false;
}


bool isCrouch(Movement_State state)
{
     if (state == M_CROUCH || state == M_HIT_CROUCH || 
         state == M_KICK_CROUCH || state == M_BLOCK_CROUCH) {
     return true;    
     }
     return false;
}

bool isJump(Movement_State state)
{
     if (state == M_JUMP_UP  || state == M_JUMP_FORWARD ||
         state == M_HIT_JUMP || state == M_HIT_JUMP_FORWARD ||
         state == M_KICK_JUMP || state == M_KICK_JUMP_FORWARD ||
         state == M_BLOCK_JUMP
        ) {
      return true;    
     }
     return false;
}

bool isJumpAll(Movement_State state)
{
   return (isJump(state) || state == M_BLOCK_JUMP_HIT);
}

bool isCollide(Movement_State state)
{
     if (state == M_JUMP_UP  || state == M_JUMP_FORWARD ||
         state == M_HIT_JUMP || state == M_HIT_JUMP_FORWARD ||
         state == M_KICK_JUMP || state == M_KICK_JUMP_FORWARD ||
         state == M_BLOCK_JUMP || state == M_BEAT_THROW ||
         state == M_THROW
        ) {
      return false;    
     }
     return true;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// Assumes that fighter in this state has been hit
/// returns the length and speed of his movement made by the force
/// of the enemys hit
/// returns a length of -1 if he shouldnt move
/// </pre>
/////////////////////////////////////////////////////////////////////

Move_Data FightingRulesMove(Movement_State state)
{
      int length = -1;
      int speed  = 0;
      
      if (state == M_BEAT_BODY || state == M_BEAT_BODY_BACK ||
          state == M_BEAT_LEGS) {
         length = 70;
         speed = 3;
      }
      else if (state == M_BEAT_CROUCH) {
         length = 40;
         speed = 3;
      }
      else if (state == M_BEAT_JUMP) {
         length = 50;
         speed = 2;
      }
      else if (state == M_BLOCK_STAND_HIT || state == M_BLOCK_CROUCH_HIT ||
               state == M_BLOCK_JUMP_HIT ) {
         length = 50;
         speed = 2;
      }
      
      
      Move_Data move_data;
      move_data.length = length;   
      move_data.speed = speed; 
      
      return move_data;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that victim has been hit and his new state is newvictim and old
/// state is oldvictim and enemy state is enemy.
/// checks if newvictim state was wrong because that victim is blocking and returns
/// his state (might be a blocking state or old state)
/// if not blocking retunrs M_NONE
/// </pre>
/////////////////////////////////////////////////////////////////////
Movement_State FightingRulesBlock(Movement_State newvictim, Movement_State oldvictim, 
               Movement_State enemy)
{
    Movement_State state = M_NONE;
             
      // if we were standing and blocking          
    if (oldvictim == M_BLOCK_STAND) {
      // we always get out of a BEAT_BODY
       if (newvictim == M_BEAT_BODY) {
         state = M_BLOCK_STAND_HIT;
      }  
    }
    
      // if we were crouching and blocking          
    if (oldvictim == M_BLOCK_CROUCH) {
      // we always get out of a BEAT_CROUCH if enemy wasnt jumping
       if (newvictim == M_BEAT_CROUCH && !isJump(enemy)) {
         state = M_BLOCK_CROUCH_HIT;
      }  
    }
    
      // if we were jumping and blocking          
    if (oldvictim == M_BLOCK_JUMP) {
      // we always can block
      state = M_BLOCK_JUMP_HIT;
        
    }
    
    return state;      
}
 
/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that victim is blocking or is beaten by enemy
/// if he was facing wrong direction he will be turned (with
/// some exception-states)
/// </pre>
/////////////////////////////////////////////////////////////////////
Direction_State FightingRulesDir(Movement_State victimstate, Direction_State victimdir,
                Direction_State enemydir)
{
    Direction_State dir = victimdir;
    
    if (victimstate != M_BEAT_BODY_BACK) {
         // kolla om victim ska byta h�ll: G�R TIL FUNKTION
       if ( enemydir == victimdir) {
              dir = (victimdir == D_RIGHT) ? D_LEFT: D_RIGHT;
       }
    }
    
    return dir;
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that victim has not blocked the enemy
/// calculates the energy that will be taken from victim and
/// returns it
/// </pre>
/////////////////////////////////////////////////////////////////////
int FightingRulesEnergy(Movement_State enemystate, Movement_State victimstate)
{
    int energy = 0;
   
    switch(enemystate) {
      case M_HIT:
        energy = 20;
        break;   
      case M_HIT_CROUCH:
        energy = 8;
        break;  
      case M_HIT_JUMP:
        energy = 15;
        break;  
      case M_HIT_JUMP_FORWARD:
        energy = 15;
        break;  
      case M_HIT_WALK:
        energy = 20;
        break;  
      case M_KICK:
        energy = 30;
        break;  
      case M_KICK_CROUCH:
        energy = 10;
        break;  
      case M_KICK_JUMP:
        energy = 22;
        break;  
      case M_KICK_JUMP_FORWARD:
        energy = 22;
        break;  
      case M_KICK_WALK:
        energy = 30;
        break; 
      case M_GRAB:
        energy = 40;
        break;  
        }
        
    // special cases from back
    switch(victimstate) {
      case M_BEAT_BODY_BACK:
        energy = 40;
    }
        
    return energy;
  
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that victim has not blocked the enemy
/// calculates the points enemy will gain and returns it
/// </pre>
/////////////////////////////////////////////////////////////////////
int FightingRulesPointsEnemy(Movement_State enemystate, Movement_State victimstate)
{
    int points = 0;
   
    switch(enemystate) {
      case M_HIT:
        points = 20;
        break;   
      case M_HIT_CROUCH:
        points = 8;
        break;  
      case M_HIT_JUMP:
        points = 15;
        break;  
      case M_HIT_JUMP_FORWARD:
        points = 15;
        break;  
      case M_HIT_WALK:
        points = 20;
        break;  
      case M_KICK:
        points = 30;
        break;  
      case M_KICK_CROUCH:
        points = 10;
        break;  
      case M_KICK_JUMP:
        points = 22;
        break;  
      case M_KICK_JUMP_FORWARD:
        points = 22;
        break;  
      case M_KICK_WALK:
        points = 30;
        break; 
      case M_GRAB:
        points = 40;
        break;  
        }
        
    // special cases from back
    switch(victimstate) {
      case M_BEAT_BODY_BACK:
        points = 40;
    }
        
    return points;
  
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that victim blocked the enemy and
/// calculates the points victim will gain and returns it
/// </pre>
/////////////////////////////////////////////////////////////////////


int FightingRulesPointsVictim(Movement_State enemystate)
{
    int points = 0;
   
    switch(enemystate) {
      case M_BLOCK_STAND:
        points = 20;
        break;   
      case M_BLOCK_CROUCH:
        points = 8;
        break;  
      case M_BLOCK_JUMP:
        points = 15;
        break;  
      case M_BLOCK_STAND_HIT:
        points = 15;
        break;  
      case M_BLOCK_CROUCH_HIT:
        points = 20;
        break;  
      case M_BLOCK_JUMP_HIT:
        points = 30;
        break;  
       }
        
    return points;
  
}

/////////////////////////////////////////////////////////////////////
/// <pre>
/// assumes that enemy has beaten the enemy someway
/// changes the state of the enemy
/// </pre>
/////////////////////////////////////////////////////////////////////


Movement_State FightingRulesEnemy(Movement_State state)
{
  if (state == M_GRAB) {
     state = M_THROW;
  }  
  return state;            
}
/////////////////////////////////////////////////////////////////////
/// <pre>
/// returns the sound to be played.. otherwise S_NONE
/// </pre>
/////////////////////////////////////////////////////////////////////

Sound_type FightingRulesSound(Movement_State new_state, Movement_State old_state)
{
    Sound_type sound = S_NONE;
   
    switch(new_state) {
      case M_HIT:
        sound = S_HIT_AIR;
        break;   
      case M_HIT_CROUCH:
        sound = S_HIT_AIR;
        break;  
      case M_HIT_JUMP:
        sound = S_HIT_AIR;
        break;  
      case M_HIT_JUMP_FORWARD:
        sound = S_HIT_AIR;
        break;  
      case M_HIT_WALK:
        sound = S_HIT_AIR;
        break;  
      case M_KICK:
        sound = S_HIT_AIR;
        break;  
      case M_KICK_CROUCH:
        sound = S_HIT_AIR;
        break;  
      case M_KICK_JUMP:
        sound = S_HIT_AIR;
        break;  
      case M_KICK_JUMP_FORWARD:
        sound = S_HIT_AIR;
        break;  
      case M_KICK_WALK:
        sound = S_HIT_AIR;
        break; 
      case M_GRAB:
        sound = S_HIT_AIR;
        break; 
      case M_THROW:
        sound = S_HIT_AIR;
        break; 
        
      case M_BLOCK_STAND:
        sound = S_HIT_AIR;
        break;   
      case M_BLOCK_CROUCH:
        sound = S_HIT_AIR;
        break;  
      case M_BLOCK_JUMP:
        sound = S_HIT_AIR;
        break;  
      case M_BLOCK_STAND_HIT:
        sound = S_BLOCK;
        break;  
      case M_BLOCK_CROUCH_HIT:
        sound = S_BLOCK;
        break;  
      case M_BLOCK_JUMP_HIT:
        sound = S_BLOCK;
        break;    
     
      case M_DEAD:
        //sound = S_ELBOW;
        break; 
      case M_WIN:
        //sound = S_HIT_GROUND;
        break; 
        
      case M_JUMP_UP:
        sound = S_JUMP;
        break; 
      case M_JUMP_FORWARD:
        sound = S_JUMP;
        break; 
      case M_RAISE_BACK:  
        sound = S_HIT_GROUND;
        break;
        } 
    // specialfall
    // om gamla state �r ett hopp och nya inte �r det
    if (isJumpAll(old_state) && !isJumpAll(new_state))
       sound = S_JUMP_LAND;
       
    // efter han har blivit kastad
    if (old_state == M_BEAT_THROW && new_state != M_BEAT_THROW)
       sound = S_HIT_GROUND;
 
 
    return sound;  
}

Sound_type FightingRulesSoundEnergy(int energy)
{
    Sound_type sound = S_NONE;   
    if (energy > 0 && energy <= 10)
       sound = S_DUCK_HIT;
    else if (energy > 10 && energy <= 20)
       sound = S_HIT; 
    else if (energy > 20)
       sound = S_KICK; 
       
    return sound;
}
