/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// timer.h

#ifndef _TIMER_H_
#define _TIMER_H_

#define UPDATE_RATE 50                              // hz
#define SIMULATION_TIME_PER_UPDATE 1000/UPDATE_RATE // msecs per update

#include <allegro.h>

extern volatile int game_time;

extern volatile unsigned int frame_counter, fps, update_counter, ups;

void init_timer();

#define CLOCK_UPDATE 1193181
#define NO_VELOCITY 1
#define MAX_DELAY fps_to_delay(1)

int delay_to_fps(int delay);
int fps_to_delay(int delay);

float scale_to_radians(int scale); 
int radians_to_scale(int radians);

int sec_to_fps(int seconds);

struct timing {
	unsigned int timer;	// ska initieras till counter innan den anv�nds
	unsigned int delay;	// delay, ju h�gre dessto st�rre delay (l�ngre tid mellan funktionsanropen)
	
	timing();
	int Check();
	// Check resets timer after delay has reached timer.
	// sometimes you want to reset delay before Check has
    // ie if Check is not always called, we are in another state and will
    // reach the state with the check() again
	void reset();
};


int If_timed(struct timing &tm); 

// funktion som returnerar ett sant v�rde om delayen till�ter det. Detta v�rde anger hur m�nga
// ggr kodbiten ska k�ras (tex animation). Vanligtvis 0 eller 1 g�ng, men kan bli fler om datorn
// haft mycket annat att utf�ra och detta bidrar till att tex animationen hinner ikapp och k�rs
// och alltid med ett best�mt regelbundet intervall. Ex: (som k�r en kodbit med ett givet intervall)

// for (int i = 0, t = If_timed(Timing); i < t; i++) { kod }

// om du inte vill att funktionen ska kunna k�ra kodbiten fler �n en g�ng s� anv�nd:

// if (If_timed(Timing) { kod }

// du kan �ven st�nga av funktionen som g�r att den tid som blir �ver minskar tiden till n�sta
// g�ng kod-biten f�r k�ras. (Allts� k�rs d� inte kodbiten regelbundet, men n�stan.) Detta
// f�rhindrar att kodbiten �r tvungen att k�ras flera g�nger om tex det var l�nge sen sist som
// funktionen testades. Ex:

// Timing.active = false;


			


	

// Allts�, g�r s� att en kodbit k�rs efter samma tidsintervall i en loop,
								  // tex med en delay p� 5 msec
								
								  // returnerar antalet ggr som kodbiten ska k�ras

#endif
