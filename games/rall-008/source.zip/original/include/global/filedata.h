#ifndef _FILE_DATA_H_
#define _FILE_DATA_H_
#include <string>
using namespace std;
/////////////////////////////////////////////////////////////////////
/// data loaded from file
/////////////////////////////////////////////////////////////////////
struct FileData {
        // data loaded from file
        bool PageFlipping;
        bool Debug;
        
        bool ConsoleShowing;
        int ConsoleHeight;
        int ConsoleYOffset;
        bool FullScreen;
        int MaxBots;
        int ColorMode;
        bool Release;
        int LoadDummy;
        bool TextAA;
        
        int ShowFps;
        string Ip;
        string Port;
        int PointsToWin;
        
        int ServerDraw;
        int ServerIsClient;
        int PlayersPerClient; 
        int SpawnTime;
        
        bool MusicOn;
        int MusicVolume;
        bool SoundOn;
        int SoundVolume;
        
        enum GAME_TYPE {CLIENT, SERVER, EDITOR, CONSOLE, EXIT};
        GAME_TYPE game_type;
        
        
        // other useful data
        string name;
        int stage_length;
        
        bool load(char *file); 
        bool save(char *file);  
        
        
   
}; 

#endif
