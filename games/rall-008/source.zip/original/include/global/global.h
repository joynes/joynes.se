/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// global.h
#include <allegro.h>

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <string>
#include <global/timer.h>
#include <alfont.h>
using namespace std;

enum ScreenType {DOUBLE_BUFFERING,PAGE_FLIPPING,UNDECIDED};

bool highcolor_fade_in(BITMAP *bmp_orig, int speed, int &a, BITMAP *bmp_buff);
bool highcolor_fade_out(BITMAP *bmp_orig, int speed, int &a, BITMAP *bmp_buff);

extern char *Part_Name[];
enum Part_Value {P_ARM_UPPER_RIGHT, P_ARM_LOWER_RIGHT, P_HAND_RIGHT, P_BODY, 
     		 P_LEG_UPPER_RIGHT, P_LEG_LOWER_RIGHT, P_FOOT_RIGHT, P_HEAD,
     		 P_LEG_UPPER_LEFT, P_LEG_LOWER_LEFT, P_FOOT_LEFT, 
		 P_ARM_UPPER_LEFT, P_ARM_LOWER_LEFT, P_HAND_LEFT, P_NR_OF
		 };
enum General_Part_Value {GP_ARMS, GP_LEGS, GP_BODY, GP_HEAD};

bool Key_block(int KEY);
bool Key(int KEY);

bool Delay(int nr);

struct Point {
       int x, y;
       
       
       Point(int x, int y);
       Point operator+(Point p);
       Point();
};
typedef Point Velocity;

///////////////////////////////////////////////////////////////////////////////
/// network things
///////////////////////////////////////////////////////////////////////////////
/// Nr of players that can connect
#define OBJ_MAX 16

int flip_rotation(int rotation);

void PrintTable(BITMAP *bitmap, string menu1[], string menu2[], int color1, int color2, int x, int y, int distance_x,
     			 int distance_y, int size);
     			 
// used if a fighter hits another
struct BoundingBox {
    Point upper_left;
    Point lower_right;
    
    BoundingBox() {};
    BoundingBox(int x1, int y1, int x2, int y2);
    
    void Set(int x1, int y1, int x2, int y2);
    bool Collide(BoundingBox b);
    void Draw(BITMAP *bitmap);
}; 
BITMAP *LoadBitmap(const char *path);

struct KeyPress
{
       enum {HOLD, RELEASE};
       int state;
       int our_key;
       timing delay;
       
       KeyPress();
       void init(int our_key, int speed);
       bool press();
};
void alfont_text(BITMAP *bmp, ALFONT_FONT *f, const char *s, int x, int y, int color, bool aa, int shadow);
void alfont_text_centre(BITMAP *bmp, ALFONT_FONT *f, const char *s, int x, int y, int color, bool aa, int shadow);

#endif
