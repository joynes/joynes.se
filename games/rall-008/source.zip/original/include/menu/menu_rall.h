/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef MENU_RALL_H_
#define MENU_RALL_H_

#include <allegro.h>
#include <alfont.h>
#include <sound/sound.h>
#include <global/global.h>
#include <vector>
#include <string>

using namespace std;

///////////////////////////////////////////////////////////////////////////////
/// The return-value from MenuRall:
/// The attribute and the associated value
///////////////////////////////////////////////////////////////////////////////
struct MenuReturn
{
  string attribute;
  string value;  
  
  MenuReturn( string _attribute, string _value) {
      attribute = _attribute;
      value =_value;        
  }
};

///////////////////////////////////////////////////////////////////////////////
/// A general menu object which other menu-objects inherits 
///////////////////////////////////////////////////////////////////////////////
class MenuObject
{
protected:
  Point pos;
  
public:
  string attribute;
  MenuObject() {};
  void SetPos(Point _pos) { pos = _pos; }
  virtual void Draw(BITMAP *bitmap, ALFONT_FONT *font, int color_attribute, int color_value, int space, bool AA, int shadow); 
  virtual bool Update(KeyPress &left, KeyPress &right, KeyPress &enter, Sample &snd_change_value, Sample &snd_change_percent, 
                   Sample &snd_change_input_add, Sample &snd_change_input_del) {};
  virtual MenuReturn Get() {return MenuReturn(string("null"), string("null"));};
          
};

///////////////////////////////////////////////////////////////////////////////
/// Fixed: An item that may get the value of a fixed nr of values
///    ie "music" = {"on", "off", "auto"};
///////////////////////////////////////////////////////////////////////////////
class MenuFixed : public MenuObject
{
private:
  vector<string> values;
  int index; 
public:
  MenuFixed(string attribute, vector<string> values, int index);
  void Draw(BITMAP *bitmap, ALFONT_FONT *font, int color_attribute, int color_value, int space, bool AA, int shadow);
  bool Update(KeyPress &left, KeyPress &right, KeyPress &enter, Sample &snd_change_value, Sample &snd_change_percent, 
                   Sample &snd_change_input_add, Sample &snd_change_input_del);
  MenuReturn Get();
};

///////////////////////////////////////////////////////////////////////////////
/// Percent: An item may get a value within the range 0-100
///    ie "music volume" = { 1 - 10 } which draws a bar
///////////////////////////////////////////////////////////////////////////////
class MenuPercent : public MenuObject
{
private:
  int index; 
  int size;
  timing sound_timer;
public:  
  MenuPercent(string attribute, int percent);
  void Draw(BITMAP *bitmap, ALFONT_FONT *font, int color_attribute, int color_value, int space, bool AA, int shadow);
  bool Update(KeyPress &left, KeyPress &right, KeyPress &enter, Sample &snd_change_value, Sample &snd_change_percent, 
                   Sample &snd_change_input_add, Sample &snd_change_input_del);
  MenuReturn Get();
};

///////////////////////////////////////////////////////////////////////////////
/// Input: An item gets the value of an input string
///    ie "ip adress" = "120.0.0.1"
///////////////////////////////////////////////////////////////////////////////
class MenuInput : public MenuObject
{
private:
  string input; 
public:  
  MenuInput(string attribute, string start);
  void Draw(BITMAP *bitmap, ALFONT_FONT *font, int color_attribute, int color_value, int space, bool AA, int shadow);
  bool Update(KeyPress &left, KeyPress &right, KeyPress &enter, Sample &snd_change_value, Sample &snd_change_percent, 
                   Sample &snd_change_input_add, Sample &snd_change_input_del);
  MenuReturn Get();
};

///////////////////////////////////////////////////////////////////////////////
/// Exit: An item that dont get any value but returns true if it is pressed
///    ie "exit" which should exit the menu or "single player" that exits menu
///    and starts a new one
///////////////////////////////////////////////////////////////////////////////
class MenuExit : public MenuObject
{
public:
  MenuExit(string attribute);
  void Draw(BITMAP *bitmap, ALFONT_FONT *font, int color_attribute, int color_value, int space, bool AA, int shadow);
  bool Update(KeyPress &left, KeyPress &right, KeyPress &enter, Sample &snd_change_value, Sample &snd_change_percent, 
                   Sample &snd_change_input_add, Sample &snd_change_input_del);
  MenuReturn Get();
};


///////////////////////////////////////////////////////////////////////////////
/// A general menu that consists of 4 types of different menu-objects, 
/// 1. Fixed: An item that may get the value of a fixed nr of values
///    ie "music" = {"on", "off", "auto"};
/// 2. Percent: An item may get a value within the range 0-100
///    ie "music volume" = { 1 - 100 } which draws a bar
/// 3. Input: An item gets the value of an input string
///    ie "ip adress" = "120.0.0.1"
/// 4. Exit: An item that dont get any value but returns true if it is pressed
///    ie "exit" which should exit the menu or "single player" that exits menu
///    and starts a new one
///////////////////////////////////////////////////////////////////////////////
class MenuRall
{
private:
  vector<MenuObject *> menuobjects;
  int index;
  Point pos;
  Point space;
  int font_size;
  int color_attribute, color_value;
  int color_attribute_highlight, color_value_highlight;
  KeyPress up, down, left, right;
  KeyPress *keyenter, *keyesc;
  int key_left, key_right, key_enter;        
  Sample snd_select, snd_change_value, snd_change_percent, snd_change_input_add,
         snd_change_input_del; 
  ALFONT_FONT *font;
  ALFONT_FONT *header_font;
  int max_horizontal_space;
  
  string name;
public:  
  MenuRall() {};
  MenuRall(Point _pos, Point _space, int _font_size, int _color_attribute, 
                   int _color_value, int color_attribute_highlight, int color_value_highlight,
                   int _key_up, int _key_down, int _key_left, int _key_right, KeyPress *keyenter, KeyPress *keyesc,
                   char *_snd_select, char * _snd_change_value, char * _snd_change_percent, 
                   char * _snd_change_input_add, char * _snd_change_input_del, char * _font, 
                   string name);
  MenuReturn Get();
  void Draw(BITMAP *bitmap, bool AA, int shadow);
  bool Update();
  void Add(MenuObject *obj);
};

#endif
