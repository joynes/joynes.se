/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef INTRO_H_
#define INTRO_H_

#include <allegro.h>
#include <global/timer.h>
#include <global/global.h>
#include <global/filedata.h>
#include <sound/sound.h>
#include <sound/music.h>
///  A test class. 
///
///  A more elaborate class description.
///

struct Intro
{
  BITMAP *intro_bmp[3];
  Sample jqp;
  int fade_timer;
  int intro_state;
  KeyPress *keyesc;
  Music *music;
  timing delay_before_next_screen;
  
  int fade_counter;
  BITMAP *bmp_buff;
    // anv�nds f�r att k�ra n�sta bild andra g�ngen
  int intro_counter;
  
  Intro();
  void Init(KeyPress *keyesc, Music *music, FileData _filedata);
  bool run(int color_mode);
  void draw(BITMAP *bitmap);  
  
  FileData filedata;
};  

#endif  
