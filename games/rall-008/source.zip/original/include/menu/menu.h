/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _MENU_H_
#define _MENU_H_
#include <allegro.h>
#include <sound/sound.h>
#include <global/timer.h>
#include <vector>
#include <string>
#include <global/global.h>
#include <alfont.h>
#include <global/filedata.h>
#include <menu/menu_rall.h>

using namespace std;

class IconsMenu
{
private:
   vector<string> texts;
   int index;
   Point pos;
   int space;
   int color_selected;
   int color;
   
   int font_size;
   string font_path;
   ALFONT_FONT *user_font;
   
   KeyPress keydown;
   KeyPress keyup;
   KeyPress *keyenter;
   
   Sample select_snd;
   Sample select_intro;
   
   
           
public:
   void init(KeyPress *keyenter);
   string run();
   void draw(BITMAP *bitmap, bool text_aa);

};

class SelectCharMenu
{
private:
   enum { v_width = 3, v_height = 2};
   struct obj 
   {
        BITMAP *bmp;
        string name;
   };    
   // 6 spelare
   obj pics[v_height][v_width]; 
   
   string name[v_height][v_width]; 
   
   BITMAP *bmp_select;
        
   Point index;
   Point pos;
   Point space;
   
   KeyPress keydown;
   KeyPress keyup;
   KeyPress keyleft;
   KeyPress keyright;
   
   KeyPress *keyenter;
   
   Sample select_snd;
   Sample select_intro;
     // select char
   ALFONT_FONT *user_font;
   
      // vilken gubbe man valt
   ALFONT_FONT *char_font;
   // peter, johannes osv..
   Sample menu_names[6];
   
   Sample sel_fighters_sound;
   
        
           
public:
       int state;
   void init(KeyPress *keyenter);
   string run();
   void draw(BITMAP *bitmap, bool text_aa);

};
       


class VersionMenu
{
       // borde inte va h�r
      Sample cheer;
      
      
public:
    timing version_timer_y;
    timing version_timer_x;
    
    // anv�nds till olika delayer mellan staten.. vanligtvis flera sekunder
    timing version_timer;
    int version_x;
    int version_y;
    int version_state;  

    
    void init();
    void run();
    void draw(BITMAP *bitmap);
    
};

class BackgroundMenu
{
      struct Player_b {
             int index;
             BITMAP *bitmap[2];
             Point pos;
      };
      Player_b players[6];       
      
      enum {ZOOM_IN, ZOOM_OUT, DELAY};
      
      BITMAP *bitmap;
      BITMAP *background;
      BITMAP *vscr;
      
      float max_scale;
      float min_scale;
      float scale;
      
      float scale_speed;
      int state;
      
      timing delay;
public:      
      void init();
        void run();
        void draw(BITMAP *bitmap);
};

class Menu
{
private:
        enum Menu_State { MAIN_MENU, CHOOSE_FIGHTER, SERVER_MENU, CLIENT_MENU,
                          HELP, NO_MENU, OPTIONS_MENU};
        
        KeyPress keyenter;
        KeyPress *keyesc;
        Menu_State state;
        BITMAP *help_bitmap;
        
        BackgroundMenu bm;
        VersionMenu vm;
        IconsMenu im;
        SelectCharMenu select_char;
        
        FileData filedata;
        
        bool init;
        
        BITMAP *bitmap;
        BITMAP *vscr;
        
        Sample stages_sound[3];
        
        
        // make thees samples for they can be played multiple times
        
        
        Sample icons_sound;
        
        Sample options_robot;
        Sample game_robot;
        
        
        Sample cling;
        Sample sel_playground_sound;
        Sample not_avail;
        Sample rotate_effect;
        Sample down_effect;
        
        Sample cheer;
          // how long time before the menu text appears if you dont
          // press any key
        timing time_before_menu;
        
          // used for client and server menu
        DIALOG_PLAYER *player;
        char target_port[256];
        char target[256];
        
        BITMAP *bitmap_dialog;
        MenuRall optionsmenu;
        MenuRall clientmenu;
        MenuRall servermenu;
        
        void serverMenu();
        bool clientMenu(BITMAP *bitmap);
        
        void init_clientMenu();
        

  
public:
       enum GAME_TYPE {EXIT, CLIENT, SERVER, EDITOR, CONSOLE, OPTIONS};
       GAME_TYPE game_type;
       
       Menu();
       bool Init(BITMAP *bitmap, FileData values, KeyPress *keyesc);
       bool Run();
       void Draw();
       
       FileData GetValues() { return filedata; }
       GAME_TYPE getChoice();
       MenuReturn getOptions();
   	  
};
#endif
