/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _ANIM_H_
#define _ANIM_H_
/*
  Name: joynes
  Copyright: J.Q.P
  Author: joynes
  Date: 10-10-05 23:50
  Description: A structure for an animation
*/

#include <allegro.h>
#include <list>
#include <string>
#include <console/conalleg.h>
#include <fighter/fighter_states.h>


using namespace std;

/////////////////////////////////////////////////////////////////////
/// an animation containts its rototation, and speed of animation and
/// a unique id that is meant to be used for the corresponding part of the
/// the character being animated
/////////////////////////////////////////////////////////////////////
struct Anim
{
private:
      
public:
      int id;
      int rotation;
      int speed;
      
      // movement for free parts
      int x, y;
      int count_x, count_y;
      
      int speed_count;
      
      // if rotation of the part means that all subparts automatically will
      // be rotated as well
      int global;
      
      // 1 is faster the higher speed value and 0 is slower the higher speed
      // value
      bool end; 
      
      Anim();
};

#define NR_ACTIONS 2
//////////////////////////////////////////////////////////////////////
/// defines an action that will be alerted if the current sub-animation
/// is related to index... if index == -1 then its not an action
/// counter is just following the iterator::index, cause you cant use
/// an iterator for checking against our index.
//////////////////////////////////////////////////////////////////////
struct Action {
       int index[NR_ACTIONS];
       
       int counter;
};

// h�r finns en lista med alla (1) delanimationer som sker efter varandra
// allts� n�r f�rsta list-elementet har animerat �r det dags f�r n�sta. 
// varje delanimation best�r av en (2) lista med paralella animationer f�r olika
// delar som d� kan r�ra sig samtidigt

/////////////////////////////////////////////////////////////////////
/// Defines multiple animations for a specific state of a character
/// Ex a moving figure. It conatains a list of all "sub-animations" that will
/// be executed serially. Every subanimation contains a list of animations 
/// that will be executed in parallell.
/////////////////////////////////////////////////////////////////////
class MultiAnim {
private:
	// different states in animation
	
      //
public:
       	
       	Action action;
       	int state;
       	list <list<Anim> >::iterator index;
       	 bool loop;
       	 
      	 // if animation should be played only once
       bool one_timer;
       	    
       list< list<Anim> > anims;

       MultiAnim();
       void Init();
       void add(Anim);
       void Draw_tree(BITMAP *bitmap, int x, int y, 
         list< list<Anim> >::iterator sel_subanim, list<Anim>::iterator sel_anim);
       list<Anim>::iterator EditBlocks(int x, int y, list< list<Anim> >::iterator *delanim);
       
       void Open(char *file, int type);
       void DefaultMove();
       
       bool End();
};

//typedef list<MultipleAnim> MultiAnim;

#endif
