/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// game.h

#ifndef _PART_H_
#define _PART_H_

#include <allegro.h>
#include <list>
#include <string>
#include <console/conalleg.h>
#include <global/global.h>
#include "anim.h"

#define MOUSE_BOX_SIZE 10

#define PART_WHITE makecol(255, 255, 0)
#define PART_BLACK makecol(0, 255, 255)  

using namespace std;

//////////////////////////////////////////////////////////////////////
/// A tree of bitmap-parts connected to eachother. A leaf node is Part
/// with the BITMAP bmp set to NULL, and it contains no data
/////////////////////////////////////////////////////////////////////
struct Part {
       BITMAP *bmp;
       
       // the bounding box for this part
       BoundingBox box;
       
       // delar som l�ggs till
       struct Adds {
   	      // the original point in bitmap where the connection point lies
              Point point; 
              // the most recent value of the connection point
              Point current_point;
              // the original degree from rotation point to connection point
	      int grade; 
              // length of the line from rotation point to connection point
	      fixed hyp;
	      
	      // which of the four rooms is the connection point in, if 
	      // rotation point is the x, y axis cross
	      int room;
              Adds() {
                 grade = 0;
              }   
              };
       list<Adds> add;
       // borde ligga i strukten oven men funka inte
       list<Part> parts; // ska vara lika stor som add
       
       // relative position of rotation point in bitmap
       Point rot_point;
       // the absolute position of the rotation point in the world
       Point pos;
       // current value
       int rotation;
       // rotation som ber�r de underliggande parterna
       int global;
       
       bool flip;
       
       // hur mycket rotation extra vi f�tt globalt
       int rotation_added;
       
       string file;
       
       
       // in what order to draw it .. 0 is first
       int z_index;
       
       // unique id of that part.. associates later with animations
       int id;
       
       // s�ger om delen inte �r beroende av sin far positionsm�ssigt
       int free;
       // om du inte �r free s� f�r du inte rotera 360 grader 0-255 utan
       // ett parti �r ogiltigt som rotation. 
       // avst�nd du inte f�r vara i �r min <= x <= max
       int min, max;
       
       bool debug;
       
       // i den h�r sorteras de grafiska delarna efter z-index
       // vilken senare kan skrivas ut
       
       struct Draw_orders {
              Part * part_ptr;
              int index;
              
              int operator<(Draw_orders other) {
                  if (index <= other.index) return 1;
                  else return 0;
              }
              
              
              
       };
       list<Draw_orders> draw_order;
       void print_order_list() {
          list<Draw_orders>::iterator h;
          con->printf("list ");int i = 0;
          for(h=draw_order.begin();h != draw_order.end(); h++, i++) {
             con->printf("%d = %d, ", i , (*h).index);
          }
       }
       
       Part();
       // find all points in bitmap
       void init_points(bool show_points);
       //void draw();
       //void draw_old();
       // inserts all parts in the draw_order list
       void insert_draw_objects(int tmp, list<Draw_orders> *lista);
       void init();
       Point get_black_coord(list<Adds>::iterator i, bool reverse);
       // returns true if part connects to this
       bool connect_to(Part part);
       
       
       list<Part>::iterator Collision(Point p, int size);
       Part * CollisionWhite(Point point, int size);
       void Draw_tree(BITMAP *bitmap, int x, int y);
       // nr = int 0
       void save(int *nr);
       //Part load(int *nr);
       
       void loadpart(int *nr, bool show_points, int white, int black);
       void default_rotation();
       ////////////////////////////////////////////////////////////////////////
       // ANIMATION
       void animate(Anim *anim, int *nr_left, bool reverse);
       int animateMulti(MultiAnim *anim, bool reverse);
       int direction(int end_rotation);
       void rotate(Anim *anim, int *nr_left, bool reverse);
       void move(Anim *anim, int *nr_left, int &count, int new_pos, int &pos);
       ////////////////////////////////////////////////////////////////////////
       
       void update_points_flip();

public:
       void draw_ypos();
       void physic(int ground);
       void tree_to_list(list<Part *> *part_list);
       void default_global();
       void LoadPart(char *file, bool show_points);
       void Draw(BITMAP *bitmap, bool reverse, int y_physics, int y_offset, int xoffset);
       void update_points(Point p, int global_rotation, bool reverse);
       void UpdateBoundingBox();
       
       void Collide(BoundingBox b, bool &result, int &id);
       void Collide(Part p, bool &result, int &id1, int &id2);
       
       void getPart(int _id, Part &part);
};

int norm_rotation(int rotation);
// returns the closest of min and max to test;
int closest(int test, int min, int max);

#endif
