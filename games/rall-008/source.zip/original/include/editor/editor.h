/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// game.h

#ifndef _EDITOR_H_
#define _EDITOR_H_

#include <allegro.h>
#include <list>
#include <string>
#include <console/conalleg.h>
#include <editor/part.h>
#include <editor/anim.h>
#include <fighter/fighter.h>

struct button {
       int x, y;
       string name;
};

#define NR_OF_PARTS 10

enum editor_state { CREATE_FIGURE, ANIMATION };

#define EXT_CHAR "str"
#define EXT_ANIM "ani"

//////////////////////////////////////////////////////////////////////
/// An editor for creating a character from bitmaps and for animation
/// of a created characters
/////////////////////////////////////////////////////////////////////
class Editor {
private:
	// bitmap to draw to
	bool flip;
	bool physics;
	BoundingBox box;
	KeyPress *keyesc;
public:       
       MultiAnim anim;
       
       editor_state state;
       // l�st sammankopplade delar.. ska s�ttas ihop senare
       list<Part> parts;
       
       // markerad part
       Part *marked;
       list<Part>::iterator black_marked;
       
       //list < list<Anim> >::iterator anim_marked;
       
       
       // om musen �r aktiv mot n�gon del eller inte
       bool mouse_active;
       bool black_active;
       // the old z value of mouse
       int old_mouse_z;
       int current_id;
       
       bool right_mouse_hold;
       
       // var p� sk�rm draw_trees ska vara 
       int draw_tree_x;
       int draw_tree_y;
       
       BITMAP *custom_cursor; //mouse cursor
       
       // where an opened bitmap will land on screen
       Point Start_position;
       // menyn
       list<button> buttons;
       
       // is an animation running?
       bool animation_run;
       // typ av animation.. tex STAND, JUMP osv..
       int animation_type;
       
       Editor();
       bool Init(KeyPress *keyesc);
       Part add_part();
       void reinit();
       bool run();
       void draw(BITMAP *bitmap);
       
       
      
        
       void clear_parts();
       // set all values to default
       void default_rotation();
       void change_mode();
       
       void add_animation_list();
       
       // what animation in the animation-tree is marked, otherwise NULL
       list<Anim>::iterator animation_mark;
       // what sub-animation in the animation-tree is marked, otherwise NULL
       list< list<Anim> >::iterator del_animation_mark;
       
       void AnimInfo(BITMAP *bitmap);
       
       
       
private:
       bool UpdateParts();
       bool update_createfigure();
       bool Connect();
       bool update_animator();
       bool EditAnimation();
       bool update_menu();
       void create_character_info(BITMAP *bitmap);
       void clear_animations();
       
       void OpenCharacter(char *file);
       void SaveCharacter(char *file); 
       void SaveAnimation(char *file);
       void OpenAnimation(char *file);
       
       void DrawBox();
       
};      


       
#endif
