/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _CRUISER_H_
#define _CRUISER_H_

#include <allegro.h>
#include <global/timer.h>
#include <fmod.h>

#define WATER_SIZE 3
#define DECK_X 0
#define DECK_Y 170
#define SMALL_BOAT_X (SCREEN_WIDTH / 2 - 150)
#define SMALL_BOAT_Y (SCREEN_HEIGHT / 2 - 20)

#include <sound/sound.h>

class Cruiser
{
private:
    int ground;
    
    BITMAP *water_tile[WATER_SIZE];
    BITMAP *water_pic[WATER_SIZE];
    // resulting water
    BITMAP *water_picture;
    
    BITMAP *inzoom;
    
    BITMAP *small_boat;
    
    timing intro_timer;
    
    Sample sounds[2];
    int sound_state;
    timing sound_delay;
    
    // how fast to change water-pics
    timing cruiser_water_speed;
    int cruiser_water_scroller;
    
    int deck_x;
    
    
    int small_boat_x;
    int small_boat_y;
    
    // anv�nds temp ist�llet f�r vscr
    BITMAP *vscr_boat;
    int global_counter;
    
    
    int stage_state;
    
    
    
    int x1;
    int x2;
public:
       int y_variation;
       BITMAP *vscr;
       BITMAP *deck;
       
       int deck_y;
       
       void Load();
       BITMAP *ShowDeck();
       void ShowWater();
       Cruiser();
};



#endif
