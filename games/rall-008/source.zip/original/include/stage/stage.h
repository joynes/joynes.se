/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _STAGE_H_
#define _STAGE_H_

#include <allegro.h>
#include <jpgalleg.h>
#include <stage/cruiser.h>

class Stage 
{
private:
    BITMAP *bitmap;
    Cruiser cruiser;
   
    
    
    
public:      
    int camera_x;
    int length; // length of stage	    
   
    void Init(char *stage);
    
    BITMAP *Foreground();
    BITMAP *Background();
    
    void UpdateCamera(int x);
    
    void Draw(BITMAP *world_bitmap);
    void DrawBackground(BITMAP *background_bitmap);
    int GetYOffset();
    
    
};    

#endif

