/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/////////////////////////////////////////////////////////////////////
/// Program Manager: initilizes and runs the game in a loop
/////////////////////////////////////////////////////////////////////
#ifndef _PROGRAM_MANAGER_H_
#define _PROGRAM_MANAGER_H_

#include <game/GameManager.h>

/////////////////////////////////////////////////////////////////////
/// Is meant to be used for running differnet program in parallel with
/// eachother. Right now only runs the game.
/////////////////////////////////////////////////////////////////////
class ProgramManager 
{
private:
   GameManager gm;
   
public:
   ProgramManager();    
   bool Run();         
};

#endif
