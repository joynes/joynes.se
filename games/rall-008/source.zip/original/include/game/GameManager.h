/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _GAME_MANAGER_H_
#define _GAME_MANAGER_H_

#include <list>
#include <allegro.h>
#include <console/conalleg.h>
#include <global/timer.h>
#include <game/game.h>
#include <global/global.h>


#include <menu/intro.h>
#include <editor/editor.h>
#include <menu/menu.h>

#include <jpgalleg.h>
#include <alfont.h>
#include <sound/sound.h>
#include <sound/music.h>
#include <global/filedata.h>

enum GameManager_state {RUN_VOID, RUN_INTRO, RUN_MENU, RUN_GAME, RUN_EDITOR};

/////////////////////////////////////////////////////////////////////
/// Manages serveral differnt tasks of a game, like intro, menu, console,
/// editor and game
/////////////////////////////////////////////////////////////////////
class GameManager 
{
private:
     // all data that has been loaded from file
  
   
   FileData filedata;
   int mask_color;
   BITMAP *console_part_view;
   //string locsrvport;
       
   Game *game; 
   Editor editor;
   Intro intro;
   Menu menu;
   
   Sound sound;
   Music music;
   string intro_song;
   
   GameManager_state state;
   /// what non-console state we are on
   bool show_console;
   
   int PointsToWin;
   
   bool UpdateLogic();
   bool UpdateDraw();
   bool drawScreen();
   void Exit();
   bool RunRealTime();
   
   bool RunClient(FileData filedata);
   bool RunServer(FileData filedata);
   
   bool LoadDefaultData();
   int InitGraphics(bool full_screen, int color_mode);
   
     // gemensam knapp f�r de olika objekten
   KeyPress keyesc;
   
   BITMAP  *page1,
  *page2,
  *active_page;
   
   
public:
   int Init();    
   bool Run();  
    GameManager();      
      
};

#endif
