/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _SOUND_H_
#define _SOUND_H_
// allm�nna ljud
#include <allegro.h>
#include <console/conalleg.h>

#define LOW_FREQ 700

enum Sound_type { S_NONE = -1, S_BLOCK, S_DUCK_HIT, S_ELBOW, S_HIT, S_JUMP, S_JUMP_LAND,
    	S_KICK, S_KNEE, S_HIT_AIR, S_HIT_GROUND, NR_SOUNDS};


/////////////////////////////////////////////////////////////////////
/// A class for playing and loading separate sounds
/////////////////////////////////////////////////////////////////////
struct Sample
{
 	SAMPLE *sample;	
	int voice; 
	bool same_freq;  
	bool active;
	
	Sample() { sample = NULL; state = 0; same_freq = false;};
	
	void load(char *filename);
	void play(char *filename, int soundfreq, int vol, int pan);
	int play(int soundfreq, int vol, int pan);
	void play();
	void stop();
	
	int state;
	bool play_loop_once(char *filename, int soundfreq, int vol, int pan);
	
	bool finnished();
	bool finnished_destroy();
	
}; 

/////////////////////////////////////////////////////////////////////
/// A class for playing and loading shared sounds of the fighers
/////////////////////////////////////////////////////////////////////

struct Sound 
{
    static int globalvolume;
    static void SetVolume(int volume);
    
    Sample sample[NR_SOUNDS];
    int voice[NR_SOUNDS];
    int vol;
    int pan;
    int freq;
    int loop;
    bool active;
    
    void init(bool active);
    void load_samples();
    void play(Sound_type snd);
};   



#endif
