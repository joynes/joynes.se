/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/****************************************
* client.h
* part of example source code
*
* This file is part of the "Zoidcom Automated Networking System" application library.
* Copyright (C)2002-2005 by J�rg R�ppel. See documentation for copyright and licensing details.
*****************************************/

#ifndef client_h
#define client_h

#include <zoidcom.h>
#include <fighter/fighter.h>
#include <sound/sound.h>
#include <sound/music.h>
#include <global/filedata.h>
#include <stage/stage.h>

/////////////////////////////////////////////////////////////////////
/// a client in the game
/////////////////////////////////////////////////////////////////////
class Client : public ZCom_Control
{
protected:
  FileData filedata;
  
  ZCom_ConnID m_id;
  int         m_localnode;
  
  int players1;
  Sound *sound;
  Music *music;
  bool music_playing;
  Stage *stage;
  
public:
       	      Fighter *fighters[OBJ_MAX];
  bool m_exitnow;

  Client( int _internalport, int _udpport );
  ~Client();
  

  // draw known objects to screen
  void draw(BITMAP *world_bitmap, int yoffset, int xoffset);

  // handle keyboard input
  void update();
  bool FighterWins();
  int GetLocalX();
  void setGround(int ground);
  void playSound(Sound *sound);
  int ActivePlayers();
  void setPlayerName(string fighter_name);
  
  int worldCollision(int leftbound, int rightbound, int x);
  void worldCollision(int length);
  void updateBodyCollision(int i);
  // add fighters to client
  void add_fighter(ZCom_ConnID _id, ZCom_ClassID _requested_class, eZCom_NodeRole _role, ZCom_NodeID _net_id);
  void Init(FileData filedata);
  void Init(FileData _filedata, Sound *sound, Music *music, Stage *stage);
protected:
  // called when initiated connection process yields a result
  void ZCom_cbConnectResult( ZCom_ConnID _id, eZCom_ConnectResult _result, ZCom_BitStream &_reply );

  // connection has closed
  void Client::ZCom_cbConnectionClosed( ZCom_ConnID _id, eZCom_CloseReason _reason, ZCom_BitStream &_reasondata );

  // zoidlevel transition finished
  void ZCom_cbZoidResult(ZCom_ConnID _id, eZCom_ZoidResult _result, zU8 _new_level, ZCom_BitStream &_reason);

   // server wants to tell us about new node
  void ZCom_cbNodeRequest_Dynamic(ZCom_ConnID _id, ZCom_ClassID _requested_class, ZCom_BitStream *_announcedata, eZCom_NodeRole _role, ZCom_NodeID _net_id);

  virtual bool ZCom_cbConnectionRequest( ZCom_ConnID  _id, ZCom_BitStream &_request, ZCom_BitStream &_reply ){return false;}
  virtual void ZCom_cbConnectionSpawned( ZCom_ConnID _id ) {}
  virtual bool ZCom_cbZoidRequest( ZCom_ConnID _id, zU8 _requested_level, ZCom_BitStream &_reason ) {return false;}
  virtual void ZCom_cbNodeRequest_Tag( ZCom_ConnID _id, ZCom_ClassID _requested_class, ZCom_BitStream *_announcedata, eZCom_NodeRole _role, zU32 _tag ) {}
  virtual void ZCom_cbDataReceived( ZCom_ConnID _id, ZCom_BitStream &_data ) {}
  virtual bool ZCom_cbDiscoverRequest( const ZCom_Address &_addr, ZCom_BitStream &_request, ZCom_BitStream &_reply ) {return false;}
  virtual void ZCom_cbDiscovered( const ZCom_Address & _addr, ZCom_BitStream &_reply )  {}
};

#endif
