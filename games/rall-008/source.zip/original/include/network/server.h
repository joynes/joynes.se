/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/****************************************
* server.h
* part of example source code
*
* This file is part of the "Zoidcom Automated Networking System" application library.
* Copyright (C)2002-2005 by J�rg R�ppel. See documentation for copyright and licensing details.
*****************************************/

#ifndef server_h
#define server_h

#include <zoidcom.h>
#include <string.h>

#include <fighter/fighter.h>
#include <global/filedata.h>
#include <stage/stage.h>

/////////////////////////////////////////////////////////////////////
/// a server for this game
/////////////////////////////////////////////////////////////////////
class Server : public ZCom_Control
{
protected:
  FileData filedata;
  int      conncount;
  Stage *stage;
public:
  Fighter *fighters[OBJ_MAX];     	   
       	   
  bool is_ok;
  
  int bot_energy;
	timing bot_delay;
	int bot_min_delay;
	int bot_max_delay;
	int nr_bots;
	  // max nr of bots
	int bot_max;

  Server( int _internalport, int _udpport );
  ~Server();

  int  getConnCount() { return conncount; }
  bool WaitingFighter(); 
  void SpawnFighter(int time, Point pos);
  bool FighterWins(int points_to_win);
  
  void add_fighter(ZCom_ConnID _id, eZCom_ZoidResult _result, zU8 _new_level, ZCom_BitStream &_reason);
  void update();
  bool draw(BITMAP *world_bitmap, int yoffset, int xoffset);
  void updateBodyCollision(int i);
  void updateHITCollision(int i);
  bool Collide(Fighter *our_fighter, Fighter *opp_fighter, int our_part, int opp_part);
  int  worldCollision(int leftbound, int rightbound, int x);
  void Server::worldCollision(int length);
  bool CollideHit(Fighter *hitfighter, Fighter *fighter);
  bool CollideKick(Fighter *hitfighter, Fighter *fighter);
  void setGround(int ground);
  void Addbot();
  void updateBot(Fighter *fighter);
  void Interaction(Fighter *enemy, Fighter *victim);
  void Init(FileData filedata, Stage *stage);

protected:
  // called on incoming connections
  bool ZCom_cbConnectionRequest( ZCom_ConnID _id, ZCom_BitStream &_request, ZCom_BitStream &_reply );
  // called when incoming connection has been established
  void ZCom_cbConnectionSpawned( ZCom_ConnID _id );
  // called when a connection closed
  void ZCom_cbConnectionClosed( ZCom_ConnID _id, eZCom_CloseReason _reason, ZCom_BitStream &_reasondata );
  // called when a connection wants to enter a zoidlevel
  bool ZCom_cbZoidRequest( ZCom_ConnID _id, zU8 _requested_level, ZCom_BitStream &_reason);
  // called when a connection entered a zoidlevel
  void ZCom_cbZoidResult(ZCom_ConnID _id, eZCom_ZoidResult _result, zU8 _new_level, ZCom_BitStream &_reason);
  // called when broadcast has been received
  bool ZCom_cbDiscoverRequest(const ZCom_Address &_addr, ZCom_BitStream &_request, ZCom_BitStream &_reply);

  virtual void ZCom_cbConnectResult( ZCom_ConnID _id, eZCom_ConnectResult _result, ZCom_BitStream &_reply ) {}
  virtual void ZCom_cbNodeRequest_Dynamic( ZCom_ConnID _id, ZCom_ClassID _requested_class, ZCom_BitStream *_announcedata, eZCom_NodeRole _role, ZCom_NodeID _net_id ) {}
  virtual void ZCom_cbNodeRequest_Tag( ZCom_ConnID _id, ZCom_ClassID _requested_class, ZCom_BitStream *_announcedata, eZCom_NodeRole _role, zU32 _tag ) {}
  void ZCom_cbDataReceived( ZCom_ConnID _id, ZCom_BitStream &_data)
{
     int testdata = _data.getInt(10);  
     
     con->printf("server received %d\n", testdata);
} 
  virtual void ZCom_cbDiscovered( const ZCom_Address & _addr, ZCom_BitStream &_reply )  {}
};


#endif
