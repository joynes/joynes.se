/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/****************************************
* common.h
* part of example source code
*
* This file is part of the "Zoidcom Automated Networking System" application library.
* Copyright (C)2002-2005 by J�rg R�ppel. See documentation for copyright and licensing details.
*****************************************/

#ifndef _common_h_
#define _common_h_

#include <allegro.h>

extern volatile long timer;

#define BROADCAST_PORT 9987

#define CONTROL_ID_SIZE 0
#define CONTROL_ID      0


#define UPDATE_RATE 50                              // hz
#define SIMULATION_TIME_PER_UPDATE 1000/UPDATE_RATE // msecs per update

void sys_init();
void sys_config();
void sys_exit();
//void sys_draw();
//void sys_draw_console();
void sys_print(const char *msg, ...);
//void sys_rest(int x);

#endif

