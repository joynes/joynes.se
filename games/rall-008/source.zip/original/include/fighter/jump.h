/*
    This file is part of Rall.

    Rall is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Rall is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Rall; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

enum Jump_state { J_START, J_UP, J_DOWN, J_END };

/////////////////////////////////////////////////////////////////////
/// class for performing a jump
/////////////////////////////////////////////////////////////////////
struct Jump_data {
    Jump_state state;
    int counter, update;
    int end;
    // this is for keeping track of our direction
    // in the jump for keeping it if the opp is
    // changing side during jump
    int start_dir;
    
    // anv�nds n�r man blir slagen i luften och ska starta om ett hopp i luften
    int restarts_jump;
    
    int ground, top;
    
    Jump_data();
    bool check();
    void reset();
};
