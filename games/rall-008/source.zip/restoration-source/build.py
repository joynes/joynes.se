#!/usr/bin/env python3
"""Compile archived C++ without modifying original/."""
from pathlib import Path
import subprocess,os,re,hashlib,json
root=Path(__file__).resolve().parent.parent
src=root/'original';compat=root/'restoration-source/compat';work=root/'restoration-source/build';out=root/'web-release/games/rall-008'
work.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
sdk=Path(os.environ.get('RALL008_EMSDK','/Users/joka/.cache/game-web-tools/emsdk'))
env=os.environ.copy();env['EMSDK_PYTHON']=str(sdk/'python/3.13.3_64bit/bin/python3');env['EM_CONFIG']=str(sdk/'.emscripten')
files=['fighter/fighter.cpp','fighter/fighter_states.cpp','fighter/jump.cpp','fighter/physics.cpp','game/controls.cpp','game/state.cpp','game/servergame.cpp','editor/part.cpp','editor/anim.cpp','global/global.cpp','global/timer.cpp','stage/stage.cpp','stage/cruiser.cpp','sound/sound.cpp']
inputs=[];manifest={'originalSources':{},'originalHeaders':{}}
for p in sorted((src/'include').rglob('*.h')):
 dest=work/'include'/p.relative_to(src/'include');dest.parent.mkdir(parents=True,exist_ok=True);s=p.read_text(encoding='cp1252');s=re.sub(r'\bfixed\b', '::fixed', s).replace('Velocity Fighter::jump(', 'Velocity jump(').replace('int operator<(Draw_orders other) {','int operator<(Draw_orders other) const {');s=re.sub(r'(#include[^\n]+)',lambda m:m[0].replace('\\','/'),s);dest.write_text(s);manifest['originalHeaders'][str(p.relative_to(src))]=hashlib.sha256(p.read_bytes()).hexdigest()
for n in files:
 p=src/'src'/n;manifest['originalSources']['src/'+n]=hashlib.sha256(p.read_bytes()).hexdigest();s=p.read_text(encoding='cp1252');s=re.sub(r'(#include[^\n]+)',lambda m:m[0].replace('\\','/'),s);s=re.sub(r'\bfixed\b', '::fixed', s);
 if n=='editor/part.cpp':
  start=s.index('list<Part>::iterator Part::Collision(');end=s.index('bool Part::connect_to',start);s=s[:start]+s[start:end].replace('ret != 0','ret != list<Part>::iterator{}').replace('return 0;', 'return list<Part>::iterator{};')+s[end:]
 if n=='editor/anim.cpp':
  start=s.index('list<Anim>::iterator MultiAnim::EditBlocks');end=s.index('void MultiAnim::Open',start);s=s[:start]+s[end:]
 copy=work/n;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_text(s);inputs.append(str(copy))
p=src/'src/game/clientgame.cpp';s=p.read_text(encoding='cp1252');s='#include <network/server.h>\n'+s[s.index('void Client::playSound'):s.index('int Client::ActivePlayers')].replace('Client::playSound','Server::playSound');p=work/'client-audio.cpp';p.write_text(s);inputs.append(str(p));manifest['derivedSources']={'src/game/clientgame.cpp':{'sha256':hashlib.sha256((src/'src/game/clientgame.cpp').read_bytes()).hexdigest(),'extraction':'Client::playSound only, renamed Server::playSound for the shared local world'}}
args=[env['EMSDK_PYTHON'],str(sdk/'upstream/emscripten/em++.py'),'-std=c++17','-O2','-Wno-writable-strings','-Wno-return-type','-ffunction-sections','-fdata-sections','-I'+str(compat),'-I'+str(work/'include'),*inputs,str(compat/'compat.cpp'),str(compat/'entry.cpp'),'--no-entry','-sMODULARIZE=1','-sEXPORT_ES6=1','-sENVIRONMENT=web','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sMAXIMUM_MEMORY=134217728','-sSTACK_SIZE=2097152','-sASSERTIONS=1','-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","stringToNewUTF8"]','-o',str(out/'engine.mjs')]
subprocess.run(args,env=env,check=True)
(out/'engine.wasm').chmod(0o644)
manifest['sdk']='Emscripten 6.0.13';manifest['compatibilityChanges']=['Normalize Windows include separators','Qualify Allegro fixed to avoid std::fixed ambiguity','Remove extra class qualification on jump declaration','Mark draw-order comparator const','Replace unused editor iterator null sentinel with a default iterator','Omit unused legacy animation-editor methods'];manifest['browserAdapter']=['One local authoritative world replaces Windows Zoidcom transport; online play not implemented','Original native server update at 50 Hz; original combat, scoring, bot logic and respawns','Original client sound dispatcher applied to the shared local world','Browser Canvas/WebAudio/configuration/font adapter','Short host replaces native menus and animation editor'];manifest['adapterSources']={str(p.relative_to(compat)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(compat.rglob('*')) if p.is_file()}
manifest['files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'engine.mjs',out/'engine.wasm']} 
(out/'source-compile-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest['files'])
