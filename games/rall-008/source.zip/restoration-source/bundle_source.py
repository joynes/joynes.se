#!/usr/bin/env python3
"""Publish corresponding source for the compiled GPL restoration; omit Windows binaries."""
from pathlib import Path
import json,zipfile
root=Path(__file__).resolve().parent.parent;out=root/'web-release/games/rall-008';manifest=json.loads((out/'source-compile-manifest.json').read_text());paths=set()
for rel in list(manifest['originalSources'])+list(manifest['derivedSources'])+list(manifest['originalHeaders']):paths.add('original/'+rel)
for folder in ['graph','sound','music','data']:
 for p in (root/'original'/folder).rglob('*'):
  if p.is_file():paths.add(str(p.relative_to(root)))
paths.add('original/config/stage1.txt')
for p in (root/'restoration-source').rglob('*'):
 if p.is_file() and 'build' not in p.relative_to(root/'restoration-source').parts:paths.add(str(p.relative_to(root)))
for n in ['app.mjs','bridge.mjs','styles.css','index.html','source-notes.md']:paths.add('web-release/games/rall-008/'+n)
for p in (out/'vendor').glob('*'):paths.add(str(p.relative_to(root)))
for n in ['game-view.mjs','game-frame-view.mjs']:paths.add('web-release/assets/'+n)
with zipfile.ZipFile(out/'source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in sorted(paths):
  i=zipfile.ZipInfo(rel,date_time=(2026,11,4,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,(root/rel).read_bytes())
print('Corresponding source:',len(paths),'files,',(out/'source.zip').stat().st_size,'bytes')
