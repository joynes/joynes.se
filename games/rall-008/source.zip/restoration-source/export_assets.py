#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,wave
from PIL import Image
root=Path(__file__).resolve().parent.parent;source=root/'original';out=root/'web-release/games/rall-008/assets';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={'unavailableUnusedImages':['graph/stage/cruiser/boat.bmp','graph/stage/cruiser/inzoom.bmp'],'images':{},'samples':{},'config':{},'font':'graph/font/Godzilla.ttf','music':'music/03 - joynes - Cyborg Hybrid.mp3'};assets={}
for p in sorted((source/'graph').rglob('*')):
 if p.suffix.lower() not in ['.bmp','.jpg','.jpeg']:continue
 n=str(p.relative_to(source));dest=out/(n+'.png');dest.parent.mkdir(parents=True,exist_ok=True)
 im=Image.open(p).convert('RGBA');im.putdata([(r,g,b,0 if(r,g,b)==(255,0,255) else a) for r,g,b,a in im.getdata()]);im.save(dest,optimize=True);manifest['images'][n]={'url':str(dest.relative_to(out)),'width':im.width,'height':im.height};assets[str(dest.relative_to(out))]={'sha256':sha(dest),'original':n,'originalSha256':sha(p),'export':'Lossless PNG; exact magenta key becomes alpha. Yellow/cyan skeleton markers retained for native point discovery.'}
for p in sorted((source/'sound').rglob('*')):
 if p.suffix.lower()!='.wav':continue
 n=str(p.relative_to(source));dest=out/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 with wave.open(str(p)) as w:meta={'duration':w.getnframes()/w.getframerate(),'channels':w.getnchannels(),'sampleRate':w.getframerate()}
 manifest['samples'][n]={'url':n,**meta};assets[n]={'sha256':sha(dest),'original':n,'originalSha256':sha(p),'export':'Unchanged original WAV.'}
for folder in ['config','data']:
 for p in sorted((source/folder).glob('*')):
  if p.is_file():manifest['config'][str(p.relative_to(source))]=p.read_text(encoding='cp1252')
for n in ['graph/font/Godzilla.ttf']+[str(p.relative_to(source)) for p in (source/'music').glob('*.mp3')]:
 p=source/n;dest=out/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);assets[n]={'sha256':sha(dest),'original':n,'originalSha256':sha(p),'export':'Unchanged original file.'}
manifest['songs']=[str(p.relative_to(source)) for p in sorted((source/'music').glob('*.mp3'))]
p=out/'manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=True,separators=(',',':'))+'\n');assets['manifest.json']={'sha256':sha(p),'export':'Original configuration/structure/animation text decoded from Windows-1252 plus image/sample metadata.'}
(out.parent/'provenance.json').write_text(json.dumps({'game':'Rall008 2006 network fighter','originalFiles':{str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file()},'webAssets':assets},indent=2)+'\n');print('Exported',len(manifest['images']),'images,',len(manifest['samples']),'WAVs,',len(manifest['songs']),'full MP3s')
