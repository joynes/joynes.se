#pragma once
#include "allegro.h"
using ALFONT_FONT=FONT;
constexpr int ALFONT_OK=0;
inline int alfont_init(){return 0;}inline void alfont_exit(){}
ALFONT_FONT*alfont_load_font(const char*);void alfont_destroy_font(ALFONT_FONT*);void alfont_set_font_size(ALFONT_FONT*,int);int alfont_get_font_height(ALFONT_FONT*);void alfont_textout_centre_aa_ex(BITMAP*,ALFONT_FONT*,const char*,int,int,int,int);

void alfont_textout_aa(BITMAP*,FONT*,const char*,int,int,int);
void alfont_textout(BITMAP*,FONT*,const char*,int,int,int);
void alfont_textout_centre_aa(BITMAP*,FONT*,const char*,int,int,int);
void alfont_textout_centre(BITMAP*,FONT*,const char*,int,int,int);
