#pragma once
#include <fighter/fighter.h>
#include <global/filedata.h>
#include <stage/stage.h>
class Server { public:
 FileData filedata; Stage*stage=nullptr; Fighter*fighters[OBJ_MAX]={};
 int bot_energy,nr_bots,bot_max,bot_min_delay,bot_max_delay; timing bot_delay;
 Server(int,int){} ~Server();
 void playSound(Sound*); void Init(FileData,Stage*); int worldCollision(int,int,int); void worldCollision(int); void setGround(int); void updateBodyCollision(int); void updateHITCollision(int); bool Collide(Fighter*,Fighter*,int,int); void updateBot(Fighter*); void update(); bool CollideHit(Fighter*,Fighter*); bool CollideKick(Fighter*,Fighter*); bool WaitingFighter(); void SpawnFighter(int,Point); bool FighterWins(int); void Interaction(Fighter*,Fighter*); void Addbot();
};
