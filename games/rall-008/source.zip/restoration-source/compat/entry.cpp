#include <network/server.h>
#include <emscripten.h>
#include <sstream>
#include <string>
#include <new>
void compat_reset();
Server::~Server(){for(auto*f:fighters)delete f;}
void Server::Addbot(){for(int i=0;i<OBJ_MAX;i++)if(!fighters[i]){auto*f=new Fighter();fighters[i]=f;f->slot=i;f->data.ai=true;strcpy(f->data.name,"bot");return;}}
Fighter::~Fighter(){}
void Fighter::update(){if(!data.ai)SetControlsNet();}
void Fighter::inPostUpdate(ZCom_Node*,ZCom_ConnID,eZCom_NodeRole,zU32,zU32,zU32){}
void Fighter::outPostUpdate(ZCom_Node*,ZCom_ConnID,eZCom_NodeRole,zU32,zU32,zU32){}
void sys_print(const char*,...){}
static Server*server=nullptr;static Stage*stage=nullptr;static BITMAP*frame=nullptr;static int steps=0,winner=-1;static Sound sounds;static int mode=0;static std::string phase="menu";
extern char*movement_state_name[];
extern "C" {
EMSCRIPTEN_KEEPALIVE void rall008_end(){delete server;server=nullptr;delete stage;stage=nullptr;compat_reset();frame=nullptr;phase="menu";}
EMSCRIPTEN_KEEPALIVE void rall008_init(int requestedMode,unsigned seed,int first,int second){rall008_end();mode=requestedMode;srand(seed?seed:1);steps=0;winner=-1;frame=screen=create_bitmap(640,480);stage=new Stage();stage->Init((char*)"config/stage1.txt");server=new Server(0,0);FileData config{};config.MaxBots=mode?0:1;config.SpawnTime=2;config.PointsToWin=500;config.stage_length=stage->length;server->Init(config,stage);Sound::SetVolume(80);sounds.init(true);sounds.load_samples();const char*roster[]={"black_samurai","joynes","elgreco","marre","peeta","tiger_my"};first=std::max(0,std::min(5,first));second=std::max(0,std::min(5,second));for(int i=0;i<2;i++){auto*f=new Fighter();server->fighters[i]=f;f->slot=i;strcpy(f->data.name,i?(mode?roster[second]:"bot"):roster[first]);if(!mode&&i==1){f->data.ai=true;server->nr_bots=1;}f->data.game_state=f->TryInit();f->SetKeyboard(i?KEY_Z:KEY_LEFT,i?KEY_C:KEY_RIGHT,i?KEY_D:KEY_UP,i?KEY_X:KEY_DOWN,i?KEY_B:KEY_O,i?KEY_V:KEY_I,i?KEY_H:KEY_U,i?KEY_N:KEY_P);f->physics.ground=430;}phase="active";}
EMSCRIPTEN_KEEPALIVE void rall008_set_key(int code,int down){if(code>=0&&code<256)key[code]=down;}
EMSCRIPTEN_KEEPALIVE void rall008_step(){if(!server||phase!="active")return;server->update();server->playSound(&sounds);stage->UpdateCamera(server->fighters[0]->GetX());stage->DrawBackground(frame);stage->Draw(frame);for(auto*f:server->fighters)if(f)f->Draw(frame,stage->GetYOffset(),-stage->camera_x+320);steps++;if(mode&&server->FighterWins(500)){for(int i=0;i<OBJ_MAX;i++)if(server->fighters[i]&&server->fighters[i]->data.points>=500)winner=i;phase="won";}}
EMSCRIPTEN_KEEPALIVE int rall008_canvas(){return frame?frame->id:0;}
EMSCRIPTEN_KEEPALIVE const char*rall008_state(){static std::string s;std::ostringstream o;o<<"{\"phase\":\""<<phase<<"\",\"steps\":"<<steps<<",\"winner\":"<<winner<<",\"mode\":\""<<(mode?"duel":"practice")<<"\",\"width\":"<<(stage?stage->length:0)<<",\"camera\":"<<(stage?stage->camera_x:0)<<",\"fighters\":[";if(server)for(int i=0;i<2;i++){auto*f=server->fighters[i];if(i)o<<',';o<<"{\"x\":"<<f->GetX()<<",\"y\":"<<f->GetY()<<",\"direction\":"<<f->data.direction_state<<",\"energy\":"<<f->data.energy<<",\"points\":"<<f->data.points<<",\"kills\":"<<f->data.kills<<",\"state\":"<<f->data.movement_state<<",\"stateName\":\""<<movement_state_name[f->data.movement_state]<<"\",\"gameState\":"<<f->data.game_state<<"}";}o<<"]}";s=o.str();return s.c_str();}
}
