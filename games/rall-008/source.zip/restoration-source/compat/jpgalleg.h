#pragma once
inline void jpgalleg_init(){}
