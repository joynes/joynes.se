#include "allegro.h"
#include "alfont.h"
#include "console-stub.h"
#include <emscripten.h>
#include <algorithm>
#include <string>
#include <map>
#include <set>
#include <sstream>
#include <vector>
BITMAP*screen=nullptr;FONT defaultFont{10};FONT*font=&defaultFont;int key[256]={};
static conalleg_c console;conalleg_c*con=&console;
static std::set<BITMAP*>bitmaps;static std::set<SAMPLE*>samples;static std::set<FONT*>fonts;
static std::map<std::string,std::map<std::string,std::string>>config;
EM_JS(int,js_create,(int w,int h),{return Module.bridge.create(w,h);});
EM_JS(int,js_image,(const char *p),{return Module.bridge.image(UTF8ToString(p));});
EM_JS(int,js_width,(int id),{return Module.bridge.bitmaps.get(id).width;});
EM_JS(int,js_height,(int id),{return Module.bridge.bitmaps.get(id).height;});
EM_JS(void,js_delete,(int id),{Module.bridge.bitmaps.delete(id);});
EM_JS(void,js_clear,(int id,int color),{Module.bridge.clear(id,color);});
EM_JS(void,js_blit,(int s,int d,int sx,int sy,int dx,int dy,int w,int h),{Module.bridge.blit(s,d,sx,sy,dx,dy,w,h);});
EM_JS(void,js_sprite,(int d,int s,int x,int y,int cx,int cy,int angle,int scale,int flip),{Module.bridge.sprite(d,s,x,y,cx,cy,angle/65536,scale/65536,flip);});
EM_JS(void,js_shape,(int d,int kind,int x,int y,int x2,int y2,int color),{Module.bridge.shape(d,kind,x,y,x2,y2,color);});
EM_JS(void,js_text,(int d,int size,const char *s,int x,int y,int color,int center),{Module.bridge.text(d,size,UTF8ToString(s),x,y,color,center);});
EM_JS(char*,js_config,(const char *p),{return stringToNewUTF8(Module.bridge.config(UTF8ToString(p)));});
EM_JS(int,js_sample,(const char *p),{return Module.bridge.sample(UTF8ToString(p));});
EM_JS(double,js_duration,(int id),{return Module.bridge.samples[id].duration;});
EM_JS(int,js_play,(int id,int vol,int pan,int freq,int loop),{return Module.bridge.play(id,vol,pan,freq,loop);});
EM_JS(int,js_position,(int id),{return Module.bridge.position(id);});
EM_JS(void,js_stop,(int id),{Module.bridge.stop(id);});
EM_JS(void,js_music,(const char *p,int volume,int stop),{Module.bridge.music(UTF8ToString(p),volume,stop);});
EM_JS(void,js_error,(const char *s),{throw Error(UTF8ToString(s));});
BITMAP*create_bitmap(int w,int h){auto*b=new BITMAP{js_create(w,h),w,h};bitmaps.insert(b);return b;}
BITMAP*load_bitmap(const char *p,PALETTE){int id=js_image(p);if(!id)return nullptr;auto*b=new BITMAP{id,js_width(id),js_height(id)};bitmaps.insert(b);return b;}
void destroy_bitmap(BITMAP*b){if(!b||!bitmaps.erase(b))return;js_delete(b->id);delete b;}
void clear_to_color(BITMAP*b,int c){if(b)js_clear(b->id,c);}
void blit(BITMAP*s,BITMAP*d,int sx,int sy,int dx,int dy,int w,int h){if(s&&d&&w>0&&h>0)js_blit(s->id,d->id,sx,sy,dx,dy,w,h);}
void draw_sprite(BITMAP*d,BITMAP*s,int x,int y){if(d&&s)js_sprite(d->id,s->id,x,y,0,0,0,65536,0);}
void pivot_sprite(BITMAP*d,BITMAP*s,int x,int y,int cx,int cy,fixed a){if(d&&s)js_sprite(d->id,s->id,x,y,cx,cy,a,65536,0);}
void pivot_sprite_v_flip(BITMAP*d,BITMAP*s,int x,int y,int cx,int cy,fixed a){if(d&&s)js_sprite(d->id,s->id,x,y,cx,cy,a,65536,1);}
void pivot_scaled_sprite(BITMAP*d,BITMAP*s,int x,int y,int cx,int cy,fixed a,fixed scale){if(d&&s)js_sprite(d->id,s->id,x,y,cx,cy,a,scale,0);}
void rect(BITMAP*d,int x,int y,int x2,int y2,int c){if(d)js_shape(d->id,0,x,y,x2,y2,c);}void rectfill(BITMAP*d,int x,int y,int x2,int y2,int c){if(d)js_shape(d->id,1,x,y,x2,y2,c);}void circlefill(BITMAP*d,int x,int y,int r,int c){if(d)js_shape(d->id,2,x,y,r,0,c);}void hline(BITMAP*d,int x,int y,int x2,int c){if(d)js_shape(d->id,3,x,y,x2,y,c);}void putpixel(BITMAP*d,int x,int y,int c){rectfill(d,x,y,x,y,c);}
void textprintf(BITMAP*d,FONT*f,int x,int y,int color,const char*fmt,...){if(std::strcmp(fmt,"fps %d")==0)return;char buf[2000];va_list a;va_start(a,fmt);vsnprintf(buf,sizeof(buf),fmt,a);va_end(a);if(d)js_text(d->id,f?f->size:10,buf,x,y,color,0);}
void text_mode(int){}void clear_keybuf(){}void save_bmp(const char*,BITMAP*,PALETTE){}
void allegro_message(const char*fmt,...){char buf[2000];va_list a;va_start(a,fmt);vsnprintf(buf,sizeof(buf),fmt,a);va_end(a);js_error(buf);}void allegro_exit(){}
FONT*alfont_load_font(const char*){auto*f=new FONT{20};fonts.insert(f);return f;}void alfont_destroy_font(FONT*f){if(fonts.erase(f))delete f;}void alfont_set_font_size(FONT*f,int s){if(f)f->size=s;}int alfont_get_font_height(FONT*f){return f?f->size:10;}void alfont_textout_centre_aa_ex(BITMAP*d,FONT*f,const char *s,int x,int y,int color,int){if(d)js_text(d->id,f?f->size:20,s,x,y,color,1);}
static std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r\n");if(a==std::string::npos)return{};return s.substr(a,s.find_last_not_of(" \t\r\n;")-a+1);}static std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return std::tolower(c);});return s;}
void set_config_file(const char *p){config.clear();char*data=js_config(p);std::istringstream in(data?data:"");free(data);std::string line,section;while(std::getline(in,line)){line=trim(line);if(line.empty()||line[0]=='#'||line[0]==';'||line.rfind("//",0)==0)continue;if(line[0]=='['){section=lower(trim(line.substr(1,line.find(']')-1)));continue;}auto n=line.find('=');if(n!=std::string::npos)config[section][lower(trim(line.substr(0,n)))]=trim(line.substr(n+1));}}
const char*get_config_string(const char *s,const char*k,const char*def){auto i=config.find(lower(s?s:""));if(i==config.end())return def;auto j=i->second.find(lower(k?k:""));return j==i->second.end()?def:j->second.c_str();}int get_config_int(const char *s,const char*k,int def){auto*p=get_config_string(s,k,nullptr);return p?strtol(p,nullptr,(*p=='0'&&p[1]=='x')?16:10):def;}
SAMPLE*load_sample(const char *p){int id=js_sample(p);if(!id)return nullptr;auto*s=new SAMPLE{id,js_duration(id)};samples.insert(s);return s;}void destroy_sample(SAMPLE*s){if(samples.erase(s))delete s;}int play_sample(SAMPLE*s,int v,int p,int f,int l){return s?js_play(s->id,v,p,f,l):-1;}int voice_get_position(int v){return v<0?-1:js_position(v);}void stop_sample(SAMPLE*s){if(s)js_stop(s->id);}void adjust_sample(SAMPLE*,int,int,int,int){}
void compat_reset(){for(auto*b:bitmaps){js_delete(b->id);delete b;}bitmaps.clear();for(auto*s:samples)delete s;samples.clear();for(auto*f:fonts)delete f;fonts.clear();std::memset(key,0,sizeof(key));screen=nullptr;}

int mouse_x=0,mouse_y=0,mouse_b=0,mouse_z=0;
EM_JS(int,js_pixel,(int id,int x,int y),{return Module.bridge.pixel(id,x,y);});
int getpixel(BITMAP*b,int x,int y){return b?js_pixel(b->id,x,y):-1;}
void textprintf_ex(BITMAP*d,FONT*f,int x,int y,int color,int,const char*fmt,...){char buf[2000];va_list a;va_start(a,fmt);vsnprintf(buf,sizeof(buf),fmt,a);va_end(a);if(d)js_text(d->id,f?f->size:10,buf,x,y,color,0);}
void alfont_textout_aa(BITMAP*d,FONT*f,const char*s,int x,int y,int color){if(d)js_text(d->id,f?f->size:20,s,x,y,color,0);}
void alfont_textout(BITMAP*d,FONT*f,const char*s,int x,int y,int color){alfont_textout_aa(d,f,s,x,y,color);}
void alfont_textout_centre_aa(BITMAP*d,FONT*f,const char*s,int x,int y,int color){if(d)js_text(d->id,f?f->size:20,s,x,y,color,1);}
void alfont_textout_centre(BITMAP*d,FONT*f,const char*s,int x,int y,int color){alfont_textout_centre_aa(d,f,s,x,y,color);}
void set_config_int(const char*,const char*,int){} void set_config_string(const char*,const char*,const char*){}
