#pragma once
#include "console-stub.h"
