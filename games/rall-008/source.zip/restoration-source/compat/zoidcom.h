#pragma once
#include <cstdint>
using zS32=int32_t;using zU32=uint32_t;using zU8=uint8_t;using zFloat=float;using ZCom_ConnID=int;
constexpr int ZCom_Invalid_ID=-1,ZCOM_REPRULE_OWNER_2_AUTH=0,eZCom_ReliableUnordered=0;
using eZCom_NodeRole=int;
struct ZCom_BitStream { ZCom_BitStream(int=0){} void addBool(bool){} bool getBool(){return false;} };
struct ZCom_Control {};struct ZCom_NodeReplicationInterceptor {};template<class T>struct ZCom_MoveUpdateListener {};template<class T,int N>struct ZCom_Replicate_Movement {};struct ZCom_Replicator {};
struct ZCom_Node {void sendEvent(int,int,ZCom_BitStream*p){delete p;}};
