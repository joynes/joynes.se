#pragma once
#include "allegro.h"
// The browser host replaces the developer console, leaving game call sites intact.
#define _CONALLEG_H_
class conalleg_c{public:void printf(const char*,...){}void set_bitmap(BITMAP*){}void draw_page(bool=false){}};
extern conalleg_c*con;
