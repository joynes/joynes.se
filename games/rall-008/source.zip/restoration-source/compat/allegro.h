#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <algorithm>
struct BITMAP{int id,w,h;};
struct SAMPLE{int id;double duration;};
struct FONT{int size;};
using PACKFILE=FILE;using PALETTE=void*;using fixed=int32_t;
extern BITMAP*screen;extern FONT*font;extern int key[256];
constexpr int KEY_J=74,KEY_L=76,KEY_K=75,KEY_R=82,KEY_T=84,KEY_Y=89;
constexpr int SCREEN_W=640,SCREEN_H=480,MIDI_NONE=0,DIGI_AUTODETECT=0;
constexpr int KEY_LEFT=37,KEY_RIGHT=39,KEY_UP=38,KEY_DOWN=40,KEY_I=73,KEY_O=79,KEY_P=80,KEY_Z=90,KEY_C=67,KEY_D=68,KEY_X=88,KEY_V=86,KEY_B=66,KEY_N=78,KEY_ENTER=13,KEY_ESC=27,KEY_Q=81,KEY_W=87,KEY_F12=123,KEY_1=49;
#define TRUE 1
#define FALSE 0
#define END_OF_FUNCTION(x)
#define END_OF_MAIN()
#define LOCK_FUNCTION(x)
#define LOCK_VARIABLE(x)
#define BPS_TO_TIMER(x) (x)
#define ABS(x) std::abs(x)
inline int itofix(int n){return n*65536;}inline int ftofix(double n){return int(n*65536);}inline int makecol(int r,int g,int b){return(r<<16)|(g<<8)|b;}
inline char*itoa(int n,char*out,int base){if(base==16)std::sprintf(out,"%x",n);else std::sprintf(out,"%d",n);return out;}
BITMAP*create_bitmap(int w,int h);BITMAP*load_bitmap(const char*,PALETTE);void destroy_bitmap(BITMAP*);
void clear_to_color(BITMAP*,int);inline void clear(BITMAP*b){clear_to_color(b,0);}inline void clear_bitmap(BITMAP*b){clear(b);}
void blit(BITMAP*,BITMAP*,int,int,int,int,int,int);void draw_sprite(BITMAP*,BITMAP*,int,int);
void pivot_sprite(BITMAP*,BITMAP*,int,int,int,int,fixed);void pivot_sprite_v_flip(BITMAP*,BITMAP*,int,int,int,int,fixed);void pivot_scaled_sprite(BITMAP*,BITMAP*,int,int,int,int,fixed,fixed);
void rect(BITMAP*,int,int,int,int,int);void rectfill(BITMAP*,int,int,int,int,int);void circlefill(BITMAP*,int,int,int,int);void hline(BITMAP*,int,int,int,int);void putpixel(BITMAP*,int,int,int);
void textprintf(BITMAP*,FONT*,int,int,int,const char*,...);void text_mode(int);void clear_keybuf();void save_bmp(const char*,BITMAP*,PALETTE);void allegro_message(const char*,...);void allegro_exit();
void set_config_file(const char*);int get_config_int(const char*,const char*,int);const char*get_config_string(const char*,const char*,const char*);
SAMPLE*load_sample(const char*);void destroy_sample(SAMPLE*);int play_sample(SAMPLE*,int,int,int,int);int voice_get_position(int);void stop_sample(SAMPLE*);void adjust_sample(SAMPLE*,int,int,int,int);
inline void set_volume_per_voice(int){}inline int install_sound(int,int,const char*){return 0;}inline int install_timer(){return 0;}inline int install_int(void(*)(),int){return 0;}inline int install_int_ex(void(*)(),int){return 0;}inline void acquire_screen(){}inline void release_screen(){}

constexpr int KEY_A=65,KEY_E=69,KEY_F=70,KEY_G=71,KEY_H=72,KEY_S=83,KEY_LCONTROL=17,KEY_LSHIFT=16,KEY_DEL=46,GFX_TEXT=0;
extern int mouse_x,mouse_y,mouse_b,mouse_z;
inline int fixtoi(fixed x){return int(std::floor(double(x)/65536+.5));}
inline fixed fixmul(fixed a,fixed b){return int64_t(a)*b/65536;}
inline fixed fixdiv(fixed a,fixed b){return b?fixed(std::max(-2147483647.,std::min(2147483647.,double(a)*65536/b))):2147483647;}
inline fixed fixsin(fixed a){return ftofix(std::sin(double(a)/65536*3.141592653589793/128));}
inline fixed fixcos(fixed a){return ftofix(std::cos(double(a)/65536*3.141592653589793/128));}
inline fixed fixatan(fixed a){return ftofix(std::atan(double(a)/65536)*128/3.141592653589793);}
inline fixed fixhypot(fixed a,fixed b){return ftofix(std::hypot(double(a)/65536,double(b)/65536));}
inline int bitmap_mask_color(BITMAP*){return 0xff00ff;}
inline int exists(const char*){return 1;}
inline int set_gfx_mode(int,int,int,int,int){return 0;}
int getpixel(BITMAP*,int,int);
void textprintf_ex(BITMAP*,FONT*,int,int,int,int,const char*,...);
void set_config_int(const char*,const char*,int);void set_config_string(const char*,const char*,const char*);

constexpr int KEY_U=85;
inline int keypressed(){return 0;}
