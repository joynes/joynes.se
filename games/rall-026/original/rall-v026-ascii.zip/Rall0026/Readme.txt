Rall 0.026 installing comments:

unzip and place it anywhere, but don't move or change any files or folders
report any errors to joynes@hotmail.com

you can visit my home-site at home.bip.net/joynes (always updated)

This version (9/12-1998):
* one-player game removed (sorry, will soon be included again)
* new aiming  system
* players cannot fall from roof
* new midi-song created and inserted (Druno)
* some options will work (the sound options)
* new color-oriented meny
* reduced program size
* changed the stage "Arena" so you can see where you shoot
* fixed some bugs I have forgotten

Some days later:
* one-player game option
* com-opponent reacts on your commands
* new structure

Fixed since 0.025:
* barrel sprite collision
* player2 aiming

News:
* digital sound
* midi music
* 16 color
* 80 x 40 Text Mode 3
* same-time movement
* two-player deathmatch
* fast and instant action

