import { createReadStream, existsSync, mkdirSync, rmSync, statSync, writeFileSync } from "fs";
import { createServer, IncomingMessage, Server, ServerResponse } from "http";
import { AddressInfo } from "net";
import { extname, join, resolve, sep } from "path";
import { chromium, Page } from "playwright";
import { runCiv2 } from "./civ2";
import { runD3DTunnel } from "./d3dtunnel";
import { runTomb3dfx } from "./tomb3dfx";
import { runWorkerWebGL } from "./worker-webgl";

interface BrowserLog {
    type: string;
    text: string;
    location: string;
}

interface BrowserMochaFailure {
    title: string;
    message: string;
    stack: string;
}

interface MochaResult {
    failureCount: number;
    failures: BrowserMochaFailure[];
}

interface BrowserTestMode {
    name: string;
    createTestsFunction: string;
    timeoutMs: number;
}

const repoRoot = resolve(__dirname, "../..");
const distRoot = join(repoRoot, "dist");
const testMode = getBrowserTestMode();
const tomb3dfx = process.argv.includes("--tomb3dfx");
const d3dtunnel = process.argv.includes("--d3dtunnel");
const civ2 = process.argv.includes("--civ2");
const artifactsName = tomb3dfx ? "tomb3dfx" : d3dtunnel ? "d3dtunnel" : civ2 ? "civ2" : "";
const artifactsDir = join(distRoot, "test-artifacts", artifactsName);
const maxBrowserLogs = Number(process.env.BROWSER_TEST_MAX_CONSOLE_LOGS ?? 200);
const civ2Bundle = resolve(repoRoot, process.env.CIV2_BUNDLE ?? "test/dosbox-x/civiliaztion2rusupd.jsdos");

const requiredArtifacts = tomb3dfx ? [
    "test/tomb3dfx.html", "test/dosbox-x/tomb3dfx.jsdos",
    "emulators.js", "wlibzip.js", "wlibzip.wasm", "wdosbox-x.js", "wdosbox-x.wasm",
] : d3dtunnel ? [
    "test/d3dtunnel.html", "test/dosbox-x/d3d_tunnel.jsdos",
    "emulators.js", "wlibzip.js", "wlibzip.wasm", "wdosbox-x.js", "wdosbox-x.wasm",
] : civ2 ? [
    "test/civ2.html", "emulators.js", "wlibzip.js", "wlibzip.wasm", "wdosbox-x.js", "wdosbox-x.wasm",
] : [
    "test/test.html",
    "test/test.js",
    "test/mocha.js",
    "test/chai.js",
    "test/mocha.css",
    "test/humblenet/jsapi.mjs",
    "test/humblenet/jsapi.wasm",
    "emulators.js",
    "wlibzip.js",
    "wlibzip.wasm",
    "wdosbox.js",
    "wdosbox.wasm",
    "wdosbox-x.js",
    "wdosbox-x.wasm",
    "wdosbox-x-jspi.js",
    "wdosbox-x-jspi.wasm",
];

const mimeTypes: Record<string, string> = {
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".jsdos": "application/octet-stream",
    ".mjs": "application/javascript; charset=utf-8",
    ".png": "image/png",
    ".wasm": "application/wasm",
    ".zip": "application/zip",
};

async function main() {
    assertRequiredArtifacts();
    if (tomb3dfx || d3dtunnel || civ2) {
        mkdirSync(artifactsDir, { recursive: true });
        const screenshots = tomb3dfx ? [
            "menu", "passport", "level", "menu-waiting", "passport-waiting", "level-waiting",
            "level-before-f4", "level-between-f4", "level-after-f4", "failure",
            ...Array.from({ length: 8 }, (_, i) => "boot-" + (i + 1)),
        ] : d3dtunnel ? [
            "waiting", "failure",
            ...Array.from({ length: 12 }, (_, i) => "boot-" + (i + 1)),
            ...Array.from({ length: 20 }, (_, i) => "tunnel-" + (i + 1).toString().padStart(2, "0")),
        ] : [
            "desktop", "game", "desktop-waiting", "game-waiting", "failure",
            ...Array.from({ length: 12 }, (_, i) => "boot-" + (i + 1)),
        ];
        for (const name of [...screenshots.map((name) => name + ".png"), "failure.txt", "browser.log.json"]) {
            rmSync(join(artifactsDir, name), { force: true });
        }
        if (tomb3dfx) {
            writeFileSync(join(artifactsDir, "keys.jsonl"), "");
        }
    }
    const abort = new AbortController();

    const server = await startStaticServer();
    const baseUrl = getServerBaseUrl(server);
    let browser;
    let page: Page | undefined;
    const browserLogs: BrowserLog[] = [];
    let omittedBrowserLogs = 0;
    const pageErrors: string[] = [];
    const requestFailures: string[] = [];

    try {
        browser = await chromium.launch({
            headless: true,
            args: civ2 ? ["--disable-dev-shm-usage", "--js-flags=--max-old-space-size=8192"] : [],
        });
        page = await browser.newPage(tomb3dfx || d3dtunnel || civ2 ? {
            viewport: { width: 640, height: 480 }, deviceScaleFactor: 1,
        } : {});

        await runWorkerWebGL(page);

        if (civ2) {
            await page.context().route("https://br.cdn.dos.zone/**", async (route) => {
                const response = await route.fetch();
                await route.fulfill({
                    response,
                    headers: { ...response.headers(), "access-control-allow-origin": "*" },
                });
            });
        }

        page.on("console", (message) => {
            const text = message.text();

            if (text.startsWith("[mocha] ")) {
                console.log(text);
            }

            if (browserLogs.length >= maxBrowserLogs) {
                browserLogs.shift();
                omittedBrowserLogs++;
            }

            browserLogs.push({
                type: message.type(),
                text,
                location: formatConsoleLocation(message.location()),
            });
        });
        page.on("pageerror", (error) => {
            const formattedError = formatError(error).trim();

            if (formattedError.length > 0) {
                pageErrors.push(formattedError);
            }
        });
        page.on("requestfailed", (request) => {
            const failure = request.failure();
            requestFailures.push(request.url() + " " + (failure?.errorText ?? "failed"));
        });
        page.on("response", (response) => {
            if (civ2 && response.status() === 403 && response.url().endsWith("/preload_ranges.metaj")) {
                return;
            }
            if (response.status() >= 400) {
                requestFailures.push(response.status() + " " + response.url());
            }
        });

        if (tomb3dfx) {
            await withTimeout((async () => {
                await page!.goto(baseUrl + "/test/tomb3dfx.html", { waitUntil: "load" });
                await runTomb3dfx(page!, artifactsDir, abort.signal);
            })(), testMode.timeoutMs, testMode.name);
            if (pageErrors.length > 0 || requestFailures.length > 0) {
                throw new Error("Tomb Raider browser errors; see browser.log.json");
            }
            console.log("Tomb Raider screenshots saved to " + artifactsDir);
            return;
        }
        if (d3dtunnel) {
            await withTimeout((async () => {
                await page!.goto(baseUrl + "/test/d3dtunnel.html", { waitUntil: "load" });
                await runD3DTunnel(page!, artifactsDir, abort.signal);
            })(), testMode.timeoutMs, testMode.name);
            const hasVoodooOpenGl = browserLogs.some((log) =>
                log.text.includes("opengl: I am able to use OpenGL to emulate Voodoo graphics"));
            if (!hasVoodooOpenGl) {
                throw new Error("D3DTunnel did not initialize Voodoo OpenGL; see browser.log.json");
            }
            const hasWebGlFeedbackLoop = browserLogs.some((log) =>
                log.text.includes("Feedback loop formed between Framebuffer and active Texture"));
            if (hasWebGlFeedbackLoop) {
                throw new Error("D3DTunnel triggered a WebGL feedback loop; see browser.log.json");
            }
            if (pageErrors.length > 0 || requestFailures.length > 0) {
                throw new Error("D3DTunnel browser errors; see browser.log.json");
            }
            console.log("D3DTunnel screenshots saved to " + artifactsDir);
            return;
        }
        if (civ2) {
            await withTimeout((async () => {
                await page!.goto(baseUrl + "/test/civ2.html", { waitUntil: "load" });
                await runCiv2(page!, artifactsDir, abort.signal);
            })(), testMode.timeoutMs, testMode.name);
            if (pageErrors.length > 0 || requestFailures.length > 0) {
                throw new Error("Civilization II browser errors; see browser.log.json");
            }
            console.log("Civilization II screenshots saved to " + artifactsDir);
            return;
        }
        await page.goto(baseUrl + "/test/test.html", { waitUntil: "load" });
        const mochaResult = await withTimeout(runBrowserTests(page, testMode), testMode.timeoutMs, testMode.name);
        const hasFailures = mochaResult.failureCount > 0 || pageErrors.length > 0;

        if (hasFailures) {
            printDiagnostics(testMode.name, mochaResult, pageErrors, requestFailures, browserLogs, omittedBrowserLogs);
            process.exitCode = 1;
            return;
        }

        console.log(testMode.name + " passed.");
        if (browserLogs.length > 0) {
            console.log("Browser console messages collected: " + (browserLogs.length + omittedBrowserLogs));
        }
    } catch (error) {
        abort.abort();
        if ((tomb3dfx || d3dtunnel || civ2) && page !== undefined) {
            if (d3dtunnel) {
                await page.screenshot({ path: join(artifactsDir, "failure.png"),
                    timeout: 5000 }).catch(() => undefined);
            } else {
                await page.locator("canvas").screenshot({ path: join(artifactsDir, "failure.png"),
                    timeout: 5000 }).catch(() => undefined);
            }
            writeFileSync(join(artifactsDir, "failure.txt"), formatError(error));
        }
        console.error("Browser test runner failed:");
        console.error(formatError(error));
        printDiagnostics(testMode.name, { failureCount: 0, failures: [] },
            pageErrors, requestFailures, browserLogs, omittedBrowserLogs);
        process.exitCode = 1;
    } finally {
        try {
            if (tomb3dfx || d3dtunnel || civ2) {
                writeFileSync(join(artifactsDir, "browser.log.json"), JSON.stringify({
                    browserLogs, omittedBrowserLogs, pageErrors, requestFailures,
                }, null, 2));
            }
        } finally {
            try {
                await browser?.close();
            } finally {
                await closeServer(server);
            }
        }
    }
}

function getBrowserTestMode(): BrowserTestMode {
    if (process.argv.includes("--tomb3dfx")) {
        return { name: "Tomb Raider 3dfx", createTestsFunction: "",
            timeoutMs: Number(process.env.BROWSER_TEST_TIMEOUT_MS ?? 180000) };
    }
    if (process.argv.includes("--d3dtunnel")) {
        return { name: "D3DTunnel", createTestsFunction: "",
            timeoutMs: Number(process.env.BROWSER_TEST_TIMEOUT_MS ?? 240000) };
    }
    if (process.argv.includes("--civ2")) {
        return { name: "Civilization II", createTestsFunction: "",
            timeoutMs: Number(process.env.BROWSER_TEST_TIMEOUT_MS ?? 305000) };
    }
    if (process.argv.includes("--net")) {
        return {
            name: "Browser network tests",
            createTestsFunction: "createNetworkTests",
            timeoutMs: Number(process.env.BROWSER_NET_TEST_TIMEOUT_MS ??
                process.env.BROWSER_TEST_TIMEOUT_MS ??
                15 * 60 * 1000),
        };
    }

    return {
        name: "Browser tests",
        createTestsFunction: "createTests",
        timeoutMs: Number(process.env.BROWSER_TEST_TIMEOUT_MS ?? 15 * 60 * 1000),
    };
}

function assertRequiredArtifacts() {
    const missingArtifacts = requiredArtifacts.filter((artifact) => !existsSync(join(distRoot, artifact)));

    if (missingArtifacts.length > 0) {
        throw new Error("Missing browser test artifacts in dist: " + missingArtifacts.join(", ") +
            ". Run yarn run gulp production before yarn test:browser.");
    }

    if (civ2 && !existsSync(civ2Bundle)) {
        throw new Error("Missing Civilization II bundle: " + civ2Bundle);
    }
}

function startStaticServer(): Promise<Server> {
    const server = createServer((request, response) => serveStaticFile(request, response));

    return new Promise((resolveServer, reject) => {
        server.once("error", reject);
        server.listen(0, "127.0.0.1", () => {
            server.off("error", reject);
            resolveServer(server);
        });
    });
}

function serveStaticFile(request: IncomingMessage, response: ServerResponse) {
    try {
        const requestUrl = new URL(request.url ?? "/", "http://127.0.0.1");
        const requestedPath = decodeURIComponent(requestUrl.pathname);
        let filePath = resolve(distRoot, "." + requestedPath);

        if (filePath !== distRoot && !filePath.startsWith(distRoot + sep)) {
            sendStatus(response, 403, "Forbidden");
            return;
        }

        if (civ2 && requestedPath === "/test/dosbox-x/civ2.jsdos") {
            filePath = civ2Bundle;
        } else if (!existsSync(filePath)) {
            sendStatus(response, 404, "Not found");
            return;
        }

        if (statSync(filePath).isDirectory()) {
            filePath = join(filePath, "index.html");
        }

        if (!existsSync(filePath) || !statSync(filePath).isFile()) {
            sendStatus(response, 404, "Not found");
            return;
        }

        const fileStat = statSync(filePath);

        response.writeHead(200, {
            "Content-Type": mimeTypes[extname(filePath)] ?? "application/octet-stream",
            "Content-Length": fileStat.size,
        });
        createReadStream(filePath, {
            highWaterMark: civ2 && filePath === civ2Bundle ? 4 * 1024 * 1024 : undefined,
        }).pipe(response);
    } catch (error) {
        sendStatus(response, 500, formatError(error));
    }
}

function sendStatus(response: ServerResponse, statusCode: number, message: string) {
    response.writeHead(statusCode, {
        "Content-Type": "text/plain; charset=utf-8",
    });
    response.end(message);
}

function getServerBaseUrl(server: Server) {
    const address = server.address() as AddressInfo | null;

    if (address === null) {
        throw new Error("Static server did not start.");
    }

    return "http://127.0.0.1:" + address.port;
}

function closeServer(server: Server): Promise<void> {
    return new Promise((resolveClose, reject) => {
        server.close((error) => {
            if (error !== undefined) {
                reject(error);
                return;
            }

            resolveClose();
        });
    });
}

async function runBrowserTests(page: Page, mode: BrowserTestMode): Promise<MochaResult> {
    return await page.evaluate(async (createTestsFunction) => {
        const browserWindow = window as any;
        const testConfig = document.getElementById("test-config");

        if (typeof browserWindow[createTestsFunction] !== "function") {
            throw new Error("window." + createTestsFunction + " is not available.");
        }

        if (typeof browserWindow.mocha?.run !== "function") {
            throw new Error("mocha.run is not available.");
        }

        if (testConfig !== null) {
            testConfig.style.display = "none";
        }

        browserWindow[createTestsFunction]();

        return await new Promise((resolve) => {
            const failures: Array<{ title: string; message: string; stack: string }> = [];
            const runner = browserWindow.mocha.run((failureCount: number) => {
                resolve({ failureCount, failures });
            });

            runner.on("fail", (test: any, error: any) => failures.push({
                title: typeof test?.fullTitle === "function" ? test.fullTitle() : String(test?.title ?? "unknown test"),
                message: String(error?.message ?? error),
                stack: String(error?.stack ?? ""),
            }));
            runner.on("test", (test: any) => {
                const title = typeof test?.fullTitle === "function" ?
                    test.fullTitle() : String(test?.title ?? "unknown test");
                console.log("[mocha] start: " + title);
            });
            runner.on("test end", (test: any) => {
                const title = typeof test?.fullTitle === "function" ?
                    test.fullTitle() : String(test?.title ?? "unknown test");
                console.log("[mocha] end: " + title);
            });
        });
    }, mode.createTestsFunction) as MochaResult;
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
    return new Promise((resolvePromise, reject) => {
        const timer = setTimeout(() => reject(new Error(label + " timed out after " + ms + "ms.")), ms);

        promise.then(resolvePromise, reject).finally(() => clearTimeout(timer));
    });
}

function printDiagnostics(
    title: string,
    mochaResult: MochaResult,
    pageErrors: string[],
    requestFailures: string[],
    browserLogs: BrowserLog[],
    omittedBrowserLogs: number) {
    console.error(title + " failed.");

    if (mochaResult.failures.length > 0) {
        console.error("\nMocha failures:");
        for (const failure of mochaResult.failures) {
            console.error("- " + failure.title);
            console.error("  " + failure.message);
            if (failure.stack.length > 0) {
                console.error(failure.stack);
            }
        }
    } else if (mochaResult.failureCount > 0) {
        console.error("\nMocha reported " + mochaResult.failureCount + " failures without failure details.");
    }

    if (pageErrors.length > 0) {
        console.error("\nPage errors:");
        for (const error of pageErrors) {
            console.error(error);
        }
    }

    if (requestFailures.length > 0) {
        console.error("\nRequest failures:");
        for (const failure of requestFailures) {
            console.error(failure);
        }
    }

    if (browserLogs.length > 0) {
        console.error("\nBrowser console:");
        if (omittedBrowserLogs > 0) {
            console.error("Showing last " + browserLogs.length + " messages; omitted " + omittedBrowserLogs + ".");
        }

        for (const log of browserLogs) {
            console.error("[" + log.type + "] " + log.text + log.location);
        }
    }
}

function formatConsoleLocation(location: { url: string; lineNumber: number; columnNumber: number }) {
    if (location.url.length === 0) {
        return "";
    }

    return " (" + location.url + ":" + location.lineNumber + ":" + location.columnNumber + ")";
}

function formatError(error: unknown) {
    if (error instanceof Error) {
        return error.stack ?? error.message;
    }

    return String(error);
}

main().catch((error) => {
    console.error(formatError(error));
    process.exitCode = 1;
});
